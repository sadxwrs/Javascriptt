document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Перечисли все примитивные типы данных в JavaScript.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Примитивные типы в JavaScript:
// string, number, boolean, undefined, null, Symbol, BigInt
console.log(typeof 'hello');    // string
console.log(typeof 42);         // number
console.log(typeof true);       // boolean
console.log(typeof undefined);  // undefined
console.log(typeof null);       // object (историческая ошибка)
console.log(typeof Symbol());   // symbol
console.log(typeof 10n);        // bigint`;

document.getElementById('output').textContent = `Примитивные типы (7 штук):\nstring, number, boolean, undefined, null, Symbol, BigInt`;
