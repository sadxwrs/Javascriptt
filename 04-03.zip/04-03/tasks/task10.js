document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию, которая принимает любое значение и возвращает строку с его типом в человекочитаемом виде.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function humanType(val) {
  if (val === null) return 'null';
  if (val === undefined) return 'undefined';
  if (Array.isArray(val)) return 'array';
  if (typeof val === 'function') return 'function';
  if (val instanceof Date) return 'date';
  if (val instanceof RegExp) return 'regexp';
  return typeof val;
}

console.log(humanType(null));       // 'null'
console.log(humanType([]));         // 'array'
console.log(humanType(new Date())); // 'date'
console.log(humanType(/abc/));      // 'regexp'
console.log(humanType('hi'));       // 'string'`;

document.getElementById('output').textContent = `humanType(null)       => 'null'\nhumanType([])         => 'array'\nhumanType(new Date()) => 'date'\nhumanType(/abc/)      => 'regexp'\nhumanType('hi')       => 'string'`;
