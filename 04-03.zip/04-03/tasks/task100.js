document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Создай собственный итерируемый объект с диапазоном чисел от from до to.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const range = {
  from: 1,
  to: 5,
  [Symbol.iterator]() {
    let current = this.from;
    const last = this.to;
    return {
      next() {
        if (current <= last) {
          return { value: current++, done: false };
        }
        return { value: undefined, done: true };
      }
    };
  }
};

for (const n of range) {
  console.log(n);
}
// 1, 2, 3, 4, 5

console.log([...range]); // [1,2,3,4,5]`;

document.getElementById('output').textContent = `range = { from:1, to:5, [Symbol.iterator]() { ... } }\nfor (const n of range) => 1, 2, 3, 4, 5\n[...range] => [1,2,3,4,5]\nИтератор возвращает {value, done} из next()`;
