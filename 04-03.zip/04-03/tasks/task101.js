document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй spread-оператор для разворота итерируемого объекта в массив.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Строка в массив символов:
const chars = [...'hello'];
console.log(chars); // ['h','e','l','l','o']

// Set в массив:
const arr = [...new Set([1,2,2,3])];
console.log(arr); // [1,2,3]

// Map в массив пар:
const pairs = [...new Map([['a',1],['b',2]])];
console.log(pairs); // [['a',1],['b',2]]

// Аргументы функции:
function sum(...args) {
  return [...args].reduce((a,b) => a+b, 0);
}
console.log(sum(1,2,3,4,5)); // 15`;

document.getElementById('output').textContent = `[...'hello']                 => ['h','e','l','l','o']\n[...new Set([1,2,2,3])]     => [1,2,3]\n[...new Map([['a',1]])]     => [['a',1]]\nSpread работает с любым итерируемым объектом`;
