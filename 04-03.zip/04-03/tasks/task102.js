document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Преобразуй строку в массив символов через итерирование.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const str = 'Привет';

// 1. Spread:
const chars1 = [...str];
console.log(chars1); // ['П','р','и','в','е','т']

// 2. Array.from():
const chars2 = Array.from(str);
console.log(chars2); // ['П','р','и','в','е','т']

// 3. for...of:
const chars3 = [];
for (const ch of str) chars3.push(ch);
console.log(chars3); // ['П','р','и','в','е','т']

// 4. split (но не итерирование):
console.log(str.split('')); // ['П','р','и','в','е','т']`;

document.getElementById('output').textContent = `[...'Привет']          => ['П','р','и','в','е','т']\nArray.from('Привет')   => ['П','р','и','в','е','т']\nfor...of + push        => ['П','р','и','в','е','т']\n'Привет'.split('')     => ['П','р','и','в','е','т']`;
