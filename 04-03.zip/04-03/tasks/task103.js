document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Чем итерируемый объект отличается от array-like объекта?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Array-like — есть length и числовые индексы
const arrayLike = { 0: 'a', 1: 'b', 2: 'c', length: 3 };
console.log(arrayLike[0]); // 'a'
// for (const x of arrayLike) {} — ОШИБКА! Не итерируемый!

// Итерируемый — есть Symbol.iterator
const iterable = new Set([1,2,3]);
for (const n of iterable) console.log(n); // 1,2,3
// iterable.length — undefined (нет length!)

// Array — и то и другое:
const arr = [1,2,3];
console.log(arr[0], arr.length); // array-like
for (const n of arr) console.log(n); // iterable

// Array.from работает с обоими:
console.log(Array.from(arrayLike)); // ['a','b','c']`;

document.getElementById('output').textContent = `Array-like: есть length и числовые индексы, НО нет for...of\nIterable: есть Symbol.iterator, НО может не быть length\nArray: и то и другое одновременно\nArray.from работает с обоими типами`;
