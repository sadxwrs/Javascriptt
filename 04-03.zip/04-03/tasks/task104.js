document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши объект, который поддерживает деструктуризацию массива через свой итератор.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const point = {
  x: 10,
  y: 20,
  z: 30,
  [Symbol.iterator]() {
    const values = [this.x, this.y, this.z];
    let i = 0;
    return {
      next: () => i < values.length
        ? { value: values[i++], done: false }
        : { value: undefined, done: true }
    };
  }
};

const [x, y, z] = point;
console.log(x, y, z); // 10 20 30

console.log([...point]); // [10, 20, 30]`;

document.getElementById('output').textContent = `const [x,y,z] = point => x=10, y=20, z=30\n[...point] => [10,20,30]\nДеструктуризация массива использует Symbol.iterator`;
