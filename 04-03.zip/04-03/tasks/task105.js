document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй объект, который бесконечно генерирует возрастающие числа через итератор.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `const counter = {
  [Symbol.iterator]() {
    let n = 0;
    return {
      next() {
        return { value: n++, done: false }; // никогда done:true!
      }
    };
  }
};

// Берём только первые 5 чисел:
const iter = counter[Symbol.iterator]();
for (let i = 0; i < 5; i++) {
  console.log(iter.next().value);
}
// 0, 1, 2, 3, 4

// Осторожно: [...counter] — бесконечный цикл!`;

document.getElementById('output').textContent = `Бесконечный итератор: done всегда false\niter.next().value => 0, 1, 2, 3, 4, 5...\n[...counter] => бесконечный цикл! Осторожно\nИспользовать только с ограничением по количеству итераций`;
