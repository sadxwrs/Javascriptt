document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши собственный итератор для объекта, который перебирает только его числовые значения.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function numericIterator(obj) {
  const numericValues = Object.values(obj).filter(v => typeof v === 'number');
  let index = 0;
  return {
    [Symbol.iterator]() { return this; },
    next() {
      if (index < numericValues.length) {
        return { value: numericValues[index++], done: false };
      }
      return { value: undefined, done: true };
    }
  };
}

const obj = { a: 1, b: 'hello', c: 3, d: true, e: 5 };
const iter = numericIterator(obj);
for (const n of iter) console.log(n);
// 1, 3, 5`;

document.getElementById('output').textContent = `numericIterator({a:1, b:'hello', c:3, d:true, e:5})\nfor...of => 1, 3, 5 (только числовые значения)\nФильтрует по typeof v === 'number'`;
