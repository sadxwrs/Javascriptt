document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Сделай итерируемый объект, который при переборе пропускает элементы по условию.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function filteredIterable(arr, predicate) {
  return {
    [Symbol.iterator]() {
      let i = 0;
      return {
        next() {
          while (i < arr.length) {
            const val = arr[i++];
            if (predicate(val)) {
              return { value: val, done: false };
            }
          }
          return { value: undefined, done: true };
        }
      };
    }
  };
}

const evens = filteredIterable([1,2,3,4,5,6], n => n % 2 === 0);
for (const n of evens) console.log(n);
// 2, 4, 6

console.log([...filteredIterable(['a','bb','ccc','d'], s => s.length > 1)]);
// ['bb', 'ccc']`;

document.getElementById('output').textContent = `filteredIterable([1..6], n=>n%2===0) => for...of выводит: 2,4,6\nfilteredIterable(['a','bb','ccc','d'], s=>s.length>1) => ['bb','ccc']\nИтератор пропускает элементы, не подходящие под predicate`;
