document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Создай Map с тремя парами ключ-значение.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Создание Map:
const map = new Map();
map.set('name', 'Анна');
map.set('age', 25);
map.set('city', 'Москва');

console.log(map);
// Map(3) { 'name' => 'Анна', 'age' => 25, 'city' => 'Москва' }

// Или сразу с данными:
const map2 = new Map([['a', 1], ['b', 2], ['c', 3]]);
console.log(map2.size); // 3`;

document.getElementById('output').textContent = `new Map([['name','Анна'],['age',25],['city','Москва']])\nmap.set('name','Анна') — добавить\nmap.size => 3\nmap.get('name') => 'Анна'`;
