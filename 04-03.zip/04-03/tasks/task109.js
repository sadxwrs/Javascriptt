document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> В чём отличие Map от обычного объекта?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// 1. Ключи Map могут быть любого типа:
const map = new Map();
const objKey = { id: 1 };
map.set(objKey, 'значение');
map.set(42, 'число как ключ');
map.set(true, 'булево как ключ');
console.log(map.get(objKey)); // 'значение'

// 2. Map сохраняет порядок вставки
// 3. Map имеет .size, объект — нет напрямую
console.log(map.size); // 3

// 4. Объект имеет прототип (лишние ключи)
const obj = {};
console.log('toString' in obj); // true (из прототипа!)
console.log(map.has('toString')); // false`;

document.getElementById('output').textContent = `Map: ключи любого типа (объект, число, функция...)\nObject: ключи только string или Symbol\nMap: .size для размера, Object: Object.keys().length\nMap: порядок вставки гарантирован\nMap: нет лишних ключей из прототипа`;
