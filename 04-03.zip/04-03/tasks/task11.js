document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое truthy и falsy значения? Составь таблицу из 10 примеров.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// FALSY значения (всего 8 в JS):
console.log(Boolean(false));     // false
console.log(Boolean(0));         // false
console.log(Boolean(-0));        // false
console.log(Boolean(''));        // false
console.log(Boolean(null));      // false
console.log(Boolean(undefined)); // false
console.log(Boolean(NaN));       // false
console.log(Boolean(0n));        // false

// TRUTHY значения:
console.log(Boolean(1));         // true
console.log(Boolean('hello'));   // true
console.log(Boolean([]));        // true (пустой массив!)
console.log(Boolean({}));        // true (пустой объект!)`;

document.getElementById('output').textContent = `FALSY: false, 0, -0, '', null, undefined, NaN, 0n\nTRUTHY: любое другое значение\nBoolean(false)     => false\nBoolean(0)         => false\nBoolean('')        => false\nBoolean(null)      => false\nBoolean(undefined) => false\nBoolean(NaN)       => false\nBoolean(1)         => true\nBoolean('hello')   => true\nBoolean([])        => true (!)\nBoolean({})        => true (!)`;
