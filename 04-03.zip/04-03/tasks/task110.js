document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Добавь, получи, проверь и удали значение в Map.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const map = new Map();

// Добавить:
map.set('ключ', 'значение');
map.set('число', 42);

// Получить:
console.log(map.get('ключ'));   // 'значение'
console.log(map.get('нет'));    // undefined

// Проверить наличие:
console.log(map.has('ключ'));   // true
console.log(map.has('нет'));    // false

// Удалить:
map.delete('ключ');
console.log(map.has('ключ'));   // false
console.log(map.size);          // 1

// Очистить всё:
map.clear();
console.log(map.size);          // 0`;

document.getElementById('output').textContent = `map.set('ключ','значение') — добавить\nmap.get('ключ')  => 'значение'\nmap.get('нет')   => undefined\nmap.has('ключ')  => true\nmap.delete('ключ') — удалить\nmap.clear() — очистить всё\nmap.size — количество элементов`;
