document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Создай Set и добавь в него несколько значений, включая дубликаты.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const set = new Set();

set.add(1);
set.add(2);
set.add(3);
set.add(2); // дубликат — проигнорируется!
set.add(1); // дубликат — проигнорируется!

console.log(set);      // Set(3) {1, 2, 3}
console.log(set.size); // 3

// Или сразу с данными:
const set2 = new Set([1, 2, 2, 3, 3, 4]);
console.log(set2); // Set(4) {1, 2, 3, 4}`;

document.getElementById('output').textContent = `set.add(1); set.add(2); set.add(2) — дубликат игнорируется\nSet {1, 2, 3} — только уникальные\nnew Set([1,2,2,3,3,4]) => Set {1,2,3,4}\nset.size => 4`;
