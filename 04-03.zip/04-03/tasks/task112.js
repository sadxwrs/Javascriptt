document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Покажи, что Set хранит только уникальные значения.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const nums = [1, 2, 2, 3, 3, 3, 4, 4, 4, 4];
const unique = new Set(nums);

console.log(unique); // Set(4) {1, 2, 3, 4}
console.log(unique.size); // 4

// Строки тоже уникальны:
const words = new Set(['apple', 'banana', 'apple', 'cherry']);
console.log(words.size); // 3

// Объекты всегда уникальны (разные ссылки):
const s = new Set();
s.add({a: 1});
s.add({a: 1}); // другой объект!
console.log(s.size); // 2`;

document.getElementById('output').textContent = `new Set([1,2,2,3,3]) => Set{1,2,3} (только уникальные)\nnew Set(['a','b','a']) => Set{'a','b'}\nОбъекты: s.add({a:1}); s.add({a:1}) => size=2 (разные ссылки!)\nSet сравнивает по ===`;
