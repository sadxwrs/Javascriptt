document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как получить размер Map и Set?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const map = new Map([['a',1],['b',2],['c',3]]);
console.log(map.size); // 3

const set = new Set([1, 2, 3, 4, 5]);
console.log(set.size); // 5

// В отличие от массива и объекта:
const arr = [1, 2, 3];
console.log(arr.length); // 3 (length, не size)

const obj = { a: 1, b: 2 };
console.log(Object.keys(obj).length); // 2 (через Object.keys)`;

document.getElementById('output').textContent = `map.size => 3 (свойство size, не метод)\nset.size => 5\nВ отличие от: Array — length, Object — Object.keys().length\nsize обновляется автоматически`;
