document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Перебери Map через for...of с деструктуризацией.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const map = new Map([
  ['name', 'Анна'],
  ['age', 25],
  ['city', 'Москва'],
]);

// for...of с деструктуризацией:
for (const [key, value] of map) {
  console.log(\`\${key}: \${value}\`);
}
// name: Анна, age: 25, city: Москва

// Только ключи:
for (const key of map.keys()) console.log(key);

// Только значения:
for (const val of map.values()) console.log(val);

// forEach:
map.forEach((val, key) => console.log(key, val));`;

document.getElementById('output').textContent = `for (const [key,val] of map) => name:Анна, age:25, city:Москва\nmap.keys()   => итератор по ключам\nmap.values() => итератор по значениям\nmap.entries()=> итератор по парам [ключ,значение]\nmap.forEach((val,key) => ...) — обратите порядок аргументов!`;
