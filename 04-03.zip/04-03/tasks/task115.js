document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Преобразуй объект в Map через Object.entries().<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const obj = { name: 'Борис', age: 30, city: 'Питер' };

// Объект => Map:
const map = new Map(Object.entries(obj));
console.log(map);
// Map(3) { 'name'=>'Борис', 'age'=>30, 'city'=>'Питер' }

console.log(map.get('name')); // 'Борис'
console.log(map.size);        // 3

// Можно изменить Map независимо от объекта:
map.set('email', 'boris@mail.ru');
console.log(map.size); // 4
console.log(obj.email); // undefined (объект не изменился)`;

document.getElementById('output').textContent = `const map = new Map(Object.entries(obj))\nmap.get('name') => 'Борис'\nmap.size        => 3\nИзменения Map не затрагивают исходный объект`;
