document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Преобразуй Map обратно в обычный объект.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const map = new Map([
  ['name', 'Вера'],
  ['age', 28],
  ['city', 'Казань'],
]);

// Map => объект:
const obj = Object.fromEntries(map);
console.log(obj);
// { name: 'Вера', age: 28, city: 'Казань' }

// Или через Object.fromEntries + entries():
const obj2 = Object.fromEntries(map.entries());
console.log(obj2); // { name: 'Вера', age: 28, city: 'Казань' }

// Работает только если ключи — строки!`;

document.getElementById('output').textContent = `Object.fromEntries(map) => { name:'Вера', age:28, city:'Казань' }\nAlt: Object.fromEntries(map.entries())\nОсторожно: работает корректно только если ключи — строки`;
