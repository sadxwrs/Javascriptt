document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй Set, чтобы убрать дубликаты из массива.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const arr = [1, 2, 2, 3, 3, 3, 4, 4, 4, 4];

// Через Set + spread:
const unique = [...new Set(arr)];
console.log(unique); // [1, 2, 3, 4]

// Или через Array.from:
const unique2 = Array.from(new Set(arr));
console.log(unique2); // [1, 2, 3, 4]

// Строки:
const words = ['cat', 'dog', 'cat', 'bird', 'dog'];
console.log([...new Set(words)]); // ['cat','dog','bird']`;

document.getElementById('output').textContent = `[...new Set([1,2,2,3,3])]       => [1,2,3]\nArray.from(new Set([1,2,2,3]))  => [1,2,3]\n[...new Set(['cat','dog','cat'])] => ['cat','dog']\nСамый краткий способ удалить дубликаты`;
