document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши пересечение двух массивов через Set.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function intersection(a, b) {
  const setB = new Set(b);
  return a.filter(item => setB.has(item));
}

console.log(intersection([1,2,3,4], [2,4,6]));     // [2,4]
console.log(intersection(['a','b','c'], ['b','c','d'])); // ['b','c']
console.log(intersection([1,2,3], [4,5,6]));       // []`;

document.getElementById('output').textContent = `intersection([1,2,3,4], [2,4,6])     => [2,4]\nintersection(['a','b','c'],['b','c','d']) => ['b','c']\nintersection([1,2,3], [4,5,6])       => []\nАлгоритм: Set из b, filter a по наличию в Set`;
