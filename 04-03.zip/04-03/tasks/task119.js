document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши разность двух множеств через Set.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function difference(a, b) {
  const setB = new Set(b);
  return a.filter(item => !setB.has(item));
}

// a - b (элементы в a, но не в b):
console.log(difference([1,2,3,4,5], [2,4])); // [1,3,5]

// Симметричная разность (элементы только в одном):
function symDiff(a, b) {
  return [
    ...difference(a, b),
    ...difference(b, a)
  ];
}
console.log(symDiff([1,2,3], [2,3,4])); // [1,4]`;

document.getElementById('output').textContent = `difference([1,2,3,4,5], [2,4]) => [1,3,5] (в a, но не в b)\nsymDiff([1,2,3], [2,3,4])      => [1,4] (только в одном)\nАлгоритм: filter + !setB.has(item)`;
