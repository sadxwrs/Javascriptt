document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Почему функция в JavaScript тоже считается объектом? Покажи это на примере свойств функции.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function greet(name) {
  return \`Hello, \${name}!\`;
}

console.log(typeof greet);            // 'function'
console.log(greet instanceof Object); // true

console.log(greet.name);   // 'greet'
console.log(greet.length); // 1 (кол-во параметров)

greet.author = 'Ivan';
console.log(greet.author); // 'Ivan'`;

document.getElementById('output').textContent = `typeof greet            => 'function'\ngreet instanceof Object => true\ngreet.name              => 'greet'\ngreet.length            => 1 (число параметров)\ngreet.author = 'Ivan'  => можно добавлять свойства`;
