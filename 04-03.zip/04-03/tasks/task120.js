document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Сделай словарь частот слов строки через Map.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function wordFreq(text) {
  const words = text.toLowerCase().split(/\\s+/);
  const freq = new Map();
  for (const word of words) {
    freq.set(word, (freq.get(word) || 0) + 1);
  }
  return freq;
}

const text = 'кот сидел на ковре кот смотрел на кота';
const freq = wordFreq(text);
for (const [word, count] of freq) {
  console.log(\`\${word}: \${count}\`);
}
// кот: 2, сидел: 1, на: 2, ковре: 1, смотрел: 1, кота: 1`;

document.getElementById('output').textContent = `wordFreq('кот сидел на ковре кот смотрел на кота')\n=> Map { кот:2, сидел:1, на:2, ковре:1, смотрел:1, кота:1 }\nMap идеален для счётчиков`;
