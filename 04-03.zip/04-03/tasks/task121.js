document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию groupBy(arr, keyFn), которая возвращает Map групп.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function groupBy(arr, keyFn) {
  const map = new Map();
  for (const item of arr) {
    const key = keyFn(item);
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(item);
  }
  return map;
}

const words = ['one','two','three','four','five','six'];
const grouped = groupBy(words, w => w.length);
for (const [len, ws] of grouped) {
  console.log(\`\${len}: \${ws.join(', ')}\`);
}
// 3: one, two, six
// 5: three
// 4: four, five`;

document.getElementById('output').textContent = `groupBy(['one','two','three','four','five','six'], w=>w.length)\n=> Map { 3=>['one','two','six'], 5=>['three'], 4=>['four','five'] }\nMap группирует по ключу из keyFn`;
