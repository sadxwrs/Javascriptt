document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй кеш результатов функции через Map.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function memoize(fn) {
  const cache = new Map();
  return function(...args) {
    const key = JSON.stringify(args);
    if (cache.has(key)) {
      console.log('из кеша');
      return cache.get(key);
    }
    const result = fn.apply(this, args);
    cache.set(key, result);
    return result;
  };
}

const slow = memoize(n => {
  console.log('вычисляю', n);
  return n * n;
});

console.log(slow(5));  // вычисляю 5 => 25
console.log(slow(5));  // из кеша   => 25
console.log(slow(10)); // вычисляю 10 => 100`;

document.getElementById('output').textContent = `slow(5)  => вычисляю 5 => 25\nslow(5)  => из кеша => 25 (не вычислялось!)\nslow(10) => вычисляю 10 => 100\nMap хранит key=JSON(args), value=результат`;
