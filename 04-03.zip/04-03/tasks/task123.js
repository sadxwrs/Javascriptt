document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Сделай сравнение сценариев, где лучше использовать объект, а где Map.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Объект предпочтителен:
// 1. Фиксированная структура данных
const user = { name: 'Иван', age: 30 };

// 2. JSON-совместимость
const json = JSON.stringify(user); // работает

// Map предпочтителен:
// 1. Динамические ключи неизвестных типов
const objKeys = new Map();
const key = { id: 1 };
objKeys.set(key, 'данные');

// 2. Частые добавления/удаления
const cache = new Map(); // оптимальнее объекта

// 3. Когда нужен порядок + размер
console.log(cache.size); // O(1)
console.log(Object.keys(user).length); // O(n)

console.log('Объект — для структур данных');
console.log('Map — для динамических коллекций');`;

document.getElementById('output').textContent = `Объект лучше когда: фиксированная структура, JSON, деструктуризация, прототипы\nMap лучше когда: ключи любых типов, частые add/delete, нужен size, порядок важен\nПроизводительность: Map.size => O(1), Object.keys().length => O(n)`;
