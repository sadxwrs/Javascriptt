document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое WeakMap? Чем он отличается от обычного Map?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// WeakMap — Map, в котором ключи слабо удерживаются (weak reference)

// 1. Только объекты в качестве ключей:
const wm = new WeakMap();
const obj = {};
wm.set(obj, 'данные'); // OK
// wm.set('строка', 'данные'); // TypeError!

// 2. Нельзя перебирать и нет .size:
// wm.forEach(...) — нет
// wm.size — undefined

console.log(wm.get(obj));    // 'данные'
console.log(wm.has(obj));    // true
wm.delete(obj);
console.log(wm.has(obj));    // false`;

document.getElementById('output').textContent = `WeakMap: только объекты в качестве ключей\nWeakMap: нет forEach, keys(), values(), size\nWeakMap: ключи слабо удерживаются (GC может удалить)\nwm.set(obj,'данные') — OK\nwm.set('строка',...)  — TypeError!`;
