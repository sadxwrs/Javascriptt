document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Почему ключами WeakMap могут быть только объекты?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Причина: WeakMap использует слабые ссылки (weak references)
// Слабая ссылка НЕ препятствует сборщику мусора

const wm = new WeakMap();

// Если объект-ключ больше не доступен, он будет удалён GC
let user = { name: 'Анна' };
wm.set(user, { visits: 10 });

// user стал недоступен:
user = null;
// GC может удалить и ключ, и связанные данные из WeakMap

// Примитивы нельзя использовать — они не являются объектами,
// и нет смысла в слабых ссылках на них (примитивы копируются по значению)
console.log('Ключи WeakMap — только объекты (и регистрированные Symbol в нов. стандартах)');`;

document.getElementById('output').textContent = `WeakMap хранит СЛАБЫЕ ссылки на ключи-объекты\nСлабая ссылка не мешает GC удалить объект\nКогда объект-ключ удаляется GC — запись из WeakMap тоже исчезает\nПримитивы не подходят: они копируются по значению, слабая ссылка бессмысленна`;
