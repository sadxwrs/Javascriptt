document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое WeakSet? Чем он отличается от обычного Set?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// WeakSet — Set, в котором элементы слабо удерживаются

const ws = new WeakSet();
const obj1 = { id: 1 };
const obj2 = { id: 2 };

ws.add(obj1);
ws.add(obj2);
// ws.add(42); // TypeError — только объекты!

console.log(ws.has(obj1)); // true
console.log(ws.has(obj2)); // true

ws.delete(obj1);
console.log(ws.has(obj1)); // false

// Нет: ws.size, ws.forEach(), ws[Symbol.iterator]()`;

document.getElementById('output').textContent = `WeakSet: только объекты в качестве элементов\nWeakSet: нет forEach, size, Symbol.iterator\nWeakSet: слабые ссылки (GC может удалить)\nws.add(obj) — OK\nws.add(42)  — TypeError\nМетоды: add, has, delete`;
