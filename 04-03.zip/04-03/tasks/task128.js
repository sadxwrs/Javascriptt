document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Почему у WeakMap и WeakSet нет перебора через for...of?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Причина: слабые ссылки + сборщик мусора
// Если разрешить перебор, нужно поддерживать список ключей
// Это означало бы СИЛЬНЫЕ ссылки — противоречие!

// WeakMap/WeakSet не знают, когда GC удалит ключ
// Итерация могла бы вернуть уже удалённые объекты

// Что ЕСТЬ у WeakMap:
// .get(), .set(), .has(), .delete()

// Что ЕСТЬ у WeakSet:
// .add(), .has(), .delete()

// Чего НЕТ:
// .size, .keys(), .values(), .entries(), forEach, for...of

console.log('Нет итерации = нет сильных ссылок = настоящий weak');`;

document.getElementById('output').textContent = `Итерация требует хранения списка ключей => сильные ссылки\nСильные ссылки противоречат идее WeakMap/WeakSet\nGC не обязан сообщать о удалении объектов\nПоэтому: нет size, keys(), values(), forEach, for...of`;
