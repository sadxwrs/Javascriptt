document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Сделай пример приватного хранилища данных экземпляров через WeakMap.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const _private = new WeakMap();

class User {
  constructor(name, password) {
    // Публичные данные:
    this.name = name;
    // Приватные данные (не видны снаружи):
    _private.set(this, { password });
  }

  checkPassword(input) {
    return _private.get(this).password === input;
  }
}

const user = new User('Анна', 'secret123');
console.log(user.name);           // 'Анна'
console.log(user.password);       // undefined (приватно!)
console.log(user.checkPassword('wrong'));   // false
console.log(user.checkPassword('secret123')); // true`;

document.getElementById('output').textContent = `user.name     => 'Анна' (публично)\nuser.password => undefined (приватно, в WeakMap!)\nuser.checkPassword('secret123') => true\nWeakMap хранит приватные данные: не видны, не перечисляются`;
