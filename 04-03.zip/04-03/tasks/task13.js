document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию isPlainObject(value), которая возвращает true только для обычных объектов.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function isPlainObject(value) {
  if (typeof value !== 'object' || value === null) return false;
  const proto = Object.getPrototypeOf(value);
  return proto === Object.prototype || proto === null;
}

console.log(isPlainObject({}));           // true
console.log(isPlainObject({ a: 1 }));     // true
console.log(isPlainObject([]));           // false
console.log(isPlainObject(new Date()));   // false
console.log(isPlainObject(null));         // false
console.log(isPlainObject(Object.create(null))); // true`;

document.getElementById('output').textContent = `isPlainObject({})                  => true\nisPlainObject({ a: 1 })            => true\nisPlainObject([])                  => false\nisPlainObject(new Date())          => false\nisPlainObject(null)                => false\nisPlainObject(Object.create(null)) => true`;
