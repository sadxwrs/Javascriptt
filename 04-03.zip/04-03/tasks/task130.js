document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй WeakSet для хранения набора уже обработанных объектов.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const processed = new WeakSet();

function process(obj) {
  if (processed.has(obj)) {
    console.log('Уже обработан:', obj.id);
    return;
  }
  console.log('Обрабатываю:', obj.id);
  // ... обработка ...
  processed.add(obj);
}

const task1 = { id: 1, data: 'abc' };
const task2 = { id: 2, data: 'def' };

process(task1); // Обрабатываю: 1
process(task2); // Обрабатываю: 2
process(task1); // Уже обработан: 1
process(task2); // Уже обработан: 2`;

document.getElementById('output').textContent = `process(task1) => 'Обрабатываю: 1'\nprocess(task2) => 'Обрабатываю: 2'\nprocess(task1) => 'Уже обработан: 1' (WeakSet помнит)\nWeakSet идеален для пометки «уже обработанных» объектов`;
