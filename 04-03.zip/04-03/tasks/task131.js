document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Объясни, как WeakMap помогает избегать утечек памяти.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// С обычным Map — утечка памяти:
const cache = new Map();
function processWithMap(obj) {
  cache.set(obj, heavyData(obj));
  // obj удалён снаружи, но Map всё ещё держит ссылку!
  // => утечка памяти!
}

function heavyData(obj) { return { ...obj, computed: true }; }

// С WeakMap — нет утечки:
const wcache = new WeakMap();
function processWithWeakMap(obj) {
  wcache.set(obj, heavyData(obj));
  // Когда obj удаляется GC, запись в wcache тоже удаляется!
}

let obj = { id: 1 };
processWithWeakMap(obj);
obj = null; // GC удалит и obj, и его запись в wcache
console.log('Утечки нет!');`;

document.getElementById('output').textContent = `Map хранит СИЛЬНУЮ ссылку: obj=null не освобождает память\nWeakMap хранит СЛАБУЮ ссылку: obj=null => GC удаляет запись\nИспользуй WeakMap для кешей, метаданных DOM-элементов\nΗе используй обычный Map для временных данных по объектам`;
