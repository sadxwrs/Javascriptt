document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй кэш метаданных DOM-элементов через WeakMap.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Симуляция DOM-элементов:
const metadata = new WeakMap();

function setMeta(element, data) {
  metadata.set(element, { ...metadata.get(element), ...data });
}

function getMeta(element) {
  return metadata.get(element) || {};
}

// Использование:
const btn = { tagName: 'BUTTON', id: 'submit' }; // симуляция DOM
const div = { tagName: 'DIV', id: 'container' };

setMeta(btn, { clicks: 0, lastClicked: null });
setMeta(btn, { clicks: 1, lastClicked: '2026-01-01' });
setMeta(div, { visible: true });

console.log(getMeta(btn)); // {clicks:1, lastClicked:'2026-01-01'}
console.log(getMeta(div)); // {visible:true}
console.log(getMeta({ id: 'other' })); // {}`;

document.getElementById('output').textContent = `setMeta(btn, {clicks:1, lastClicked:'2026-01-01'})\ngetMeta(btn) => {clicks:1, lastClicked:'2026-01-01'}\ngetMeta(div) => {visible:true}\ngetMeta({id:'other'}) => {}\nWeakMap не мешает GC удалить элементы DOM`;
