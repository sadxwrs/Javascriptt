document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши задачу-сравнение: когда выбрать Map, а когда WeakMap.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// WeakMap — когда:
const domMeta = new WeakMap(); // метаданные DOM
const privateProp = new WeakMap(); // приватные свойства класса
const cache = new WeakMap(); // кеш вычислений по объекту

// Map — когда:
const settings = new Map(); // настройки приложения
const users = new Map();    // список пользователей
const freq = new Map();     // счётчики, нужен перебор

const conclusions = [
  'WeakMap: данные живут ровно столько, сколько объект-ключ',
  'WeakMap: нет итерации, нет размера',
  'Map: полный контроль, итерация, сериализация',
  'Map: для долгоживущих данных со строковыми ключами',
];
conclusions.forEach(c => console.log(c));`;

document.getElementById('output').textContent = `WeakMap выбирай когда:\n- метаданные DOM-элементов\n- приватные поля класса\n- кеш вычислений по объектам (без утечек)\nMap выбирай когда:\n- нужен перебор (forEach/for...of)\n- нужен size\n- ключи — примитивы\n- долгоживущие данные`;
