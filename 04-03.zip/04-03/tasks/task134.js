document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй Object.keys() для получения всех ключей объекта.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const user = { name: 'Анна', age: 25, city: 'Москва' };

const keys = Object.keys(user);
console.log(keys); // ['name', 'age', 'city']

// Количество свойств:
console.log(keys.length); // 3

// Проверить наличие ключа:
console.log(keys.includes('name')); // true

// Только собственные (не унаследованные) ключи:
const child = Object.create(user);
child.extra = 'test';
console.log(Object.keys(child)); // ['extra'] — только своё!`;

document.getElementById('output').textContent = `Object.keys({name:'Анна',age:25,city:'Москва'}) => ['name','age','city']\nkeys.length => 3\nВозвращает только собственные (не унаследованные) перечисляемые ключи`;
