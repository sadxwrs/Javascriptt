document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй Object.values() для получения всех значений объекта.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const product = { name: 'Ноутбук', price: 50000, inStock: true };

const values = Object.values(product);
console.log(values); // ['Ноутбук', 50000, true]

// Сумма числовых значений:
const prices = { apple: 50, banana: 30, cherry: 80 };
const total = Object.values(prices).reduce((sum, p) => sum + p, 0);
console.log(total); // 160

// Проверка значений:
const scores = { alice: 95, bob: 72, carol: 88 };
const allPass = Object.values(scores).every(s => s >= 70);
console.log(allPass); // true`;

document.getElementById('output').textContent = `Object.values({name:'Ноутбук',price:50000}) => ['Ноутбук',50000,true]\nObject.values({a:50,b:30,c:80}).reduce(sum) => 160\nObject.values(scores).every(s=>s>=70)       => true`;
