document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй Object.entries() для получения всех пар ключ-значение.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const person = { name: 'Борис', age: 30 };

const entries = Object.entries(person);
console.log(entries);
// [['name','Борис'],['age',30]]

// Создать Map из объекта:
const map = new Map(Object.entries(person));
console.log(map.get('name')); // 'Борис'

// Обратно через fromEntries:
const obj = Object.fromEntries(entries);
console.log(obj); // { name:'Борис', age:30 }`;

document.getElementById('output').textContent = `Object.entries({name:'Борис',age:30}) => [['name','Борис'],['age',30]]\nnew Map(Object.entries(obj)) => Map с теми же парами\nObject.fromEntries(entries)  => обратно в объект`;
