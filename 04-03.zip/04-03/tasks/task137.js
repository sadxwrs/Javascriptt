document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Перебери объект через Object.entries() и for...of.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const prices = { яблоко: 50, банан: 30, вишня: 80 };

for (const [fruit, price] of Object.entries(prices)) {
  console.log(\`\${fruit}: \${price} руб.\`);
}
// яблоко: 50 руб.
// банан: 30 руб.
// вишня: 80 руб.

// С деструктуризацией и фильтрацией:
Object.entries(prices)
  .filter(([, price]) => price > 40)
  .forEach(([fruit, price]) => console.log(\`\${fruit}: \${price}\`));`;

document.getElementById('output').textContent = `for (const [fruit,price] of Object.entries(prices)):\nяблоко: 50 руб.\nбанан: 30 руб.\nвишня: 80 руб.\nМожно сразу: Object.entries(prices).filter().forEach()`;
