document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Сравни результат for...in и Object.keys().<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const parent = { inherited: true };
const child = Object.create(parent);
child.own1 = 'a';
child.own2 = 'b';

// for...in — обходит ВСЕ перечисляемые, включая унаследованные:
console.log('for...in:');
for (const key in child) {
  console.log(key); // own1, own2, inherited
}

// Object.keys() — только СОБСТВЕННЫЕ:
console.log('Object.keys():', Object.keys(child));
// ['own1', 'own2']`;

document.getElementById('output').textContent = `for...in: own1, own2, inherited (включая из прототипа!)\nObject.keys(): ['own1','own2'] (только собственные)\nОсторожно: for...in может обойти лишние ключи\nОбычно Object.keys() предпочтительнее for...in`;
