document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Преобразуй объект цен в массив строк вида 'apple: 100' через Object.entries().<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const prices = { apple: 100, banana: 50, cherry: 200 };

const strings = Object.entries(prices)
  .map(([fruit, price]) => \`\${fruit}: \${price}\`);

console.log(strings);
// ['apple: 100', 'banana: 50', 'cherry: 200']

// Отсортированный список:
const sorted = Object.entries(prices)
  .sort(([, a], [, b]) => a - b)
  .map(([f, p]) => \`\${f}: \${p}\`);
console.log(sorted);
// ['banana: 50', 'apple: 100', 'cherry: 200']`;

document.getElementById('output').textContent = `Object.entries(prices).map(([f,p])=>\`\${f}: \${p}\`)\n=> ['apple: 100', 'banana: 50', 'cherry: 200']\nС сортировкой по цене:\n=> ['banana: 50', 'apple: 100', 'cherry: 200']`;
