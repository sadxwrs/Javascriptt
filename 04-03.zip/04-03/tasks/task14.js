document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Сравни поведение typeof, Object.prototype.toString.call() и Array.isArray() на разных значениях.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `const values = [42, 'hi', true, null, undefined, [], {}, new Date()];

values.forEach(val => {
  const t1 = typeof val;
  const t2 = Object.prototype.toString.call(val);
  const t3 = Array.isArray(val);
  console.log(t1, '|', t2, '| isArray:', t3);
});`;

document.getElementById('output').textContent = `42        | number    | [object Number]    | isArray: false\nhi        | string    | [object String]    | isArray: false\ntrue      | boolean   | [object Boolean]   | isArray: false\nnull      | object    | [object Null]      | isArray: false\nundefined | undefined | [object Undefined] | isArray: false\n[]        | object    | [object Array]     | isArray: true\n{}        | object    | [object Object]    | isArray: false\nDate      | object    | [object Date]      | isArray: false`;
