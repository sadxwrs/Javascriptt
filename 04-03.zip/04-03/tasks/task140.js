document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию, которая считает сумму всех числовых значений объекта через Object.values().<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function sumValues(obj) {
  return Object.values(obj)
    .filter(v => typeof v === 'number')
    .reduce((sum, v) => sum + v, 0);
}

console.log(sumValues({ a: 1, b: 2, c: 3 }));           // 6
console.log(sumValues({ x: 10, name: 'test', y: 5 }));  // 15
console.log(sumValues({ a: 'hello', b: true }));         // 0 (нет чисел)
console.log(sumValues({}));                              // 0`;

document.getElementById('output').textContent = `sumValues({ a:1, b:2, c:3 })          => 6\nsumValues({ x:10, name:'test', y:5 }) => 15 (только числа)\nsumValues({ a:'hello', b:true })       => 0\nАлгоритм: Object.values + filter(number) + reduce(sum)`;
