document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Отфильтруй объект по значениям и собери новый объект через Object.fromEntries().<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const scores = { alice: 95, bob: 45, carol: 88, dan: 60, eve: 72 };

// Оставить только тех, кто набрал >= 70:
const passed = Object.fromEntries(
  Object.entries(scores).filter(([, score]) => score >= 70)
);
console.log(passed);
// { alice: 95, carol: 88, eve: 72 }

// Оставить только строковые значения:
const mixed = { a: 1, b: 'hello', c: true, d: 'world' };
const strings = Object.fromEntries(
  Object.entries(mixed).filter(([, v]) => typeof v === 'string')
);
console.log(strings); // { b: 'hello', d: 'world' }`;

document.getElementById('output').textContent = `Object.fromEntries(Object.entries(scores).filter(([,s])=>s>=70))\n=> { alice:95, carol:88, eve:72 }\nObject.entries + filter + Object.fromEntries — стандартный паттерн фильтрации объекта`;
