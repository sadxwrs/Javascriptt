document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Отсортируй объект по ключам через Object.entries() и Object.fromEntries().<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const unordered = { banana: 2, apple: 5, cherry: 1, date: 3 };

// Сортировка по ключам (алфавитно):
const sortedByKey = Object.fromEntries(
  Object.entries(unordered).sort(([a], [b]) => a.localeCompare(b))
);
console.log(sortedByKey);
// { apple:5, banana:2, cherry:1, date:3 }

// Сортировка по значениям:
const sortedByVal = Object.fromEntries(
  Object.entries(unordered).sort(([, a], [, b]) => a - b)
);
console.log(sortedByVal);
// { cherry:1, banana:2, date:3, apple:5 }`;

document.getElementById('output').textContent = `Сортировка по ключам: Object.entries().sort(([a],[b])=>a.localeCompare(b))\n=> { apple:5, banana:2, cherry:1, date:3 }\nСортировка по значениям: .sort(([,a],[,b])=>a-b)\n=> { cherry:1, banana:2, date:3, apple:5 }`;
