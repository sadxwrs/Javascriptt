document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Сделай функцию invert(obj), которая меняет местами ключи и значения.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function invert(obj) {
  return Object.fromEntries(
    Object.entries(obj).map(([key, value]) => [value, key])
  );
}

console.log(invert({ a: 1, b: 2, c: 3 }));
// { 1:'a', 2:'b', 3:'c' }

console.log(invert({ ru: 'Россия', us: 'США', de: 'Германия' }));
// { Россия:'ru', США:'us', Германия:'de' }

// Осторожно: дубликаты значений перезапишут ключи!
console.log(invert({ a: 1, b: 1 }));
// { 1: 'b' } — 'a' потеряно!`;

document.getElementById('output').textContent = `invert({ a:1, b:2, c:3 })                     => { 1:'a', 2:'b', 3:'c' }\ninvert({ ru:'Россия', us:'США' })              => { Россия:'ru', США:'us' }\ninvert({ a:1, b:1 })                          => { 1:'b' } (дубликат перезаписал!)`;
