document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию mapObject(obj, fn), которая изменяет значения объекта.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function mapObject(obj, fn) {
  return Object.fromEntries(
    Object.entries(obj).map(([key, value]) => [key, fn(value, key)])
  );
}

const prices = { apple: 100, banana: 50, cherry: 200 };

// Поднять цены на 10%:
const raised = mapObject(prices, v => Math.round(v * 1.1));
console.log(raised); // { apple:110, banana:55, cherry:220 }

// Добавить ключ к значению:
const withKeys = mapObject(prices, (v, k) => \`\${k}: \${v} руб.\`);
console.log(withKeys);
// { apple:'apple: 100 руб.', ... }`;

document.getElementById('output').textContent = `mapObject(prices, v=>Math.round(v*1.1))\n=> { apple:110, banana:55, cherry:220 }\nmapObject(prices, (v,k)=>\`\${k}: \${v} руб.\`)\n=> { apple:'apple: 100 руб.', banana:'banana: 50 руб.', ... }`;
