document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй функцию глубокой фильтрации объекта через рекурсию и Object.entries().<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function deepFilter(obj, predicate) {
  return Object.fromEntries(
    Object.entries(obj)
      .filter(([key, value]) => {
        if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
          return true; // оставляем вложенные объекты
        }
        return predicate(value, key);
      })
      .map(([key, value]) => {
        if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
          return [key, deepFilter(value, predicate)];
        }
        return [key, value];
      })
  );
}

const data = { a: 1, b: 'hello', c: { d: 2, e: 'world' }, f: 3 };
const onlyNumbers = deepFilter(data, v => typeof v === 'number');
console.log(onlyNumbers);
// { a:1, c:{ d:2 }, f:3 }`;

document.getElementById('output').textContent = `deepFilter({a:1, b:'hello', c:{d:2, e:'world'}, f:3}, v=>typeof v==='number')\n=> { a:1, c:{ d:2 }, f:3 }\nРекурсивно обходит вложенные объекты`;
