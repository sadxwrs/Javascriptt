document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Сделай деструктуризацию массива [1,2,3] в переменные a, b, c.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const [a, b, c] = [1, 2, 3];
console.log(a); // 1
console.log(b); // 2
console.log(c); // 3

// Несколько способов:
const arr = [10, 20, 30];
const [x, y, z] = arr;
console.log(x, y, z); // 10 20 30`;

document.getElementById('output').textContent = `const [a,b,c] = [1,2,3]\na => 1, b => 2, c => 3\nconst [x,y,z] = [10,20,30]\nx => 10, y => 20, z => 30`;
