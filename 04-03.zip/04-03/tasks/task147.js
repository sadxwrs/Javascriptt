document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Сделай деструктуризацию объекта {name:'Ann', age:20}.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const { name, age } = { name: 'Ann', age: 20 };
console.log(name); // 'Ann'
console.log(age);  // 20

// Из переменной:
const person = { name: 'Борис', age: 30, city: 'Москва' };
const { name: n, age: a } = person; // с переименованием
console.log(n, a); // 'Борис' 30`;

document.getElementById('output').textContent = `const { name, age } = { name:'Ann', age:20 }\nname => 'Ann', age => 20\nconst { name: n, age: a } = person — переименование\nn => 'Борис', a => 30`;
