document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как переименовать переменную при деструктуризации объекта?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const user = { firstName: 'Иван', lastName: 'Петров', age: 25 };

// Синтаксис: { ключ: новоеИмя }
const { firstName: first, lastName: last, age: years } = user;
console.log(first); // 'Иван'
console.log(last);  // 'Петров'
console.log(years); // 25

// Исходные ключи firstName, lastName теперь НЕ определены как переменные:
// console.log(firstName); // ReferenceError!`;

document.getElementById('output').textContent = `const { firstName: first, lastName: last } = user\nfirst => 'Иван', last => 'Петров'\nСинтаксис: { ключОбъекта: имяПеременной }\nИсходное имя firstName как переменная не создаётся`;
