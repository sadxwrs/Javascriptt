document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как задать значения по умолчанию в деструктуризации массива и объекта?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Массив — значение по умолчанию если элемент undefined:
const [a = 10, b = 20, c = 30] = [1, 2];
console.log(a, b, c); // 1 2 30 (c = 30 по умолчанию)

// Объект — значение по умолчанию:
const { name = 'Аноним', age = 0, city = 'Неизвестно' } = { name: 'Анна', age: 25 };
console.log(name);  // 'Анна'
console.log(age);   // 25
console.log(city);  // 'Неизвестно' (по умолчанию)`;

document.getElementById('output').textContent = `const [a=10,b=20,c=30] = [1,2] => a=1, b=2, c=30 (дефолт)\nconst {name='Аноним', city='Неизвестно'} = {name:'Анна'}\nname => 'Анна', city => 'Неизвестно' (дефолт)\nДефолт применяется только если значение === undefined`;
