document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй утилиту typeStats(arr), которая по массиву значений возвращает объект со счётчиками типов.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function typeStats(arr) {
  return arr.reduce((stats, val) => {
    let type;
    if (val === null) type = 'null';
    else if (Array.isArray(val)) type = 'array';
    else type = typeof val;
    stats[type] = (stats[type] || 0) + 1;
    return stats;
  }, {});
}

const data = [1, 'a', true, null, undefined, [], {}, 2, 'b', null];
console.log(typeStats(data));
// { number: 2, string: 2, boolean: 1, null: 2, undefined: 1, array: 1, object: 1 }`;

document.getElementById('output').textContent = `typeStats([1,'a',true,null,undefined,[],{},2,'b',null])\n=> { number:2, string:2, boolean:1, null:2, undefined:1, array:1, object:1 }`;
