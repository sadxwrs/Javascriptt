document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как пропустить ненужные элементы массива при деструктуризации?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const arr = [1, 2, 3, 4, 5];

// Пропустить через запятую:
const [first, , third] = arr;
console.log(first, third); // 1 3

// Пропустить несколько:
const [, , , fourth, fifth] = arr;
console.log(fourth, fifth); // 4 5

// Взять только первый и остальные:
const [head, ...tail] = arr;
console.log(head); // 1
console.log(tail); // [2, 3, 4, 5]`;

document.getElementById('output').textContent = `const [first,,third] = [1,2,3,4,5] => first=1, third=3\nconst [,,,fourth] = arr            => fourth=4\nconst [head,...tail] = arr         => head=1, tail=[2,3,4,5]`;
