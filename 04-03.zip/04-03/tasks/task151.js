document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как поменять местами две переменные через деструктуризацию?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `let a = 1;
let b = 2;

// Старый способ (через temp):
// let temp = a; a = b; b = temp;

// Новый способ (деструктуризация):
[a, b] = [b, a];
console.log(a); // 2
console.log(b); // 1

// Тоже работает со строками:
let x = 'hello';
let y = 'world';
[x, y] = [y, x];
console.log(x, y); // 'world' 'hello'`;

document.getElementById('output').textContent = `let a=1, b=2\n[a,b] = [b,a] => a=2, b=1\nОдна строка вместо трёх со временной переменной!\nРаботает с любыми значениями`;
