document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй rest-элемент в деструктуризации массива.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const [first, second, ...rest] = [1, 2, 3, 4, 5];
console.log(first);  // 1
console.log(second); // 2
console.log(rest);   // [3, 4, 5]

// rest всегда последний!
const [head, ...tail] = ['a', 'b', 'c', 'd'];
console.log(head); // 'a'
console.log(tail); // ['b','c','d']

// Пропустить и собрать остаток:
const [, , ...fromThird] = [10, 20, 30, 40, 50];
console.log(fromThird); // [30, 40, 50]`;

document.getElementById('output').textContent = `const [first,second,...rest] = [1,2,3,4,5]\nfirst=1, second=2, rest=[3,4,5]\nconst [head,...tail] = ['a','b','c','d']\nhead='a', tail=['b','c','d']\n...rest всегда последним!`;
