document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй rest-свойство в деструктуризации объекта.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const user = { name: 'Анна', age: 25, city: 'Москва', role: 'admin' };

const { name, age, ...rest } = user;
console.log(name);  // 'Анна'
console.log(age);   // 25
console.log(rest);  // { city:'Москва', role:'admin' }

// Убрать одно поле и получить остаток:
const { password, ...safeUser } = { name: 'Иван', password: 'secret', age: 30 };
console.log(safeUser); // { name:'Иван', age:30 } — без пароля!`;

document.getElementById('output').textContent = `const {name, age, ...rest} = user\nname='Анна', age=25, rest={city:'Москва',role:'admin'}\nconst {password, ...safeUser} = userData\nsafeUser => { name:'Иван', age:30 } (пароль убран!)`;
