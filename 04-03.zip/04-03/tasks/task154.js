document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Сделай вложенную деструктуризацию объекта с адресом пользователя.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const user = {
  name: 'Вера',
  address: {
    city: 'Питер',
    street: 'Невский пр.',
    zip: '190000'
  }
};

// Вложенная деструктуризация:
const { name, address: { city, street, zip } } = user;
console.log(name);   // 'Вера'
console.log(city);   // 'Питер'
console.log(street); // 'Невский пр.'
console.log(zip);    // '190000'

// address как переменная не создаётся!
// console.log(address); // ReferenceError`;

document.getElementById('output').textContent = `const {name, address:{city,street,zip}} = user\nname='Вера', city='Питер', street='Невский пр.', zip='190000'\nПеременная address НЕ создаётся при вложенной деструктуризации`;
