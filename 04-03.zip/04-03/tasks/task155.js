document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию, принимающую объект и сразу деструктурирующую параметры в сигнатуре.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function greetUser({ name, age = 0, city = 'Неизвестно' }) {
  return \`\${name}, \${age} лет, г. \${city}\`;
}

console.log(greetUser({ name: 'Анна', age: 25, city: 'Москва' }));
// 'Анна, 25 лет, г. Москва'

console.log(greetUser({ name: 'Борис' }));
// 'Борис, 0 лет, г. Неизвестно'

// Удобно для настроек:
function createServer({ host = 'localhost', port = 3000, debug = false } = {}) {
  console.log(\`\${host}:\${port}, debug:\${debug}\`);
}
createServer({ port: 8080 }); // 'localhost:8080, debug:false'`;

document.getElementById('output').textContent = `greetUser({name:'Анна',age:25,city:'Москва'}) => 'Анна, 25 лет, г. Москва'\ngreetUser({name:'Борис'}) => 'Борис, 0 лет, г. Неизвестно' (дефолты!)\ncreateServer({port:8080}) => 'localhost:8080, debug:false'`;
