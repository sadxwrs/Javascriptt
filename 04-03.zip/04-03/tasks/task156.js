document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию, принимающую массив координат и деструктурирующую их в параметрах.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function distance([x1, y1], [x2, y2]) {
  return Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
}

console.log(distance([0, 0], [3, 4]));   // 5
console.log(distance([1, 1], [4, 5]));   // 5

function translate([x, y], [dx, dy]) {
  return [x + dx, y + dy];
}
console.log(translate([1, 2], [3, 4]));  // [4, 6]`;

document.getElementById('output').textContent = `distance([0,0], [3,4])    => 5 (теорема Пифагора)\ndistance([1,1], [4,5])    => 5\ntranslate([1,2], [3,4])   => [4,6]\nДеструктуризация в параметрах: function f([x,y]) {}`;
