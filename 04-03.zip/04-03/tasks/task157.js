document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Преобразуй массив пар из Object.entries() в переменные через деструктуризацию в цикле.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const inventory = { яблоки: 50, бананы: 30, вишня: 80 };

for (const [product, qty] of Object.entries(inventory)) {
  console.log(\`\${product}: \${qty} шт.\`);
}
// яблоки: 50 шт.
// бананы: 30 шт.
// вишня: 80 шт.

// С фильтрацией:
const lowStock = Object.entries(inventory)
  .filter(([, qty]) => qty < 50)
  .map(([product]) => product);
console.log(lowStock); // ['бананы']`;

document.getElementById('output').textContent = `for (const [product,qty] of Object.entries(inventory)):\nяблоки: 50 шт.\nбананы: 30 шт.\nвишня: 80 шт.\nОтфильтровать <50: ['бананы']`;
