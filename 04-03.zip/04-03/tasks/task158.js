document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Сделай сложную деструктуризацию объекта с вложенными массивами и дефолтными значениями.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `const config = {
  server: {
    hosts: ['primary.com', 'backup.com'],
    ports: [80, 443]
  },
  timeout: 5000
};

const {
  server: {
    hosts: [primary, backup = 'fallback.com'],
    ports: [httpPort, httpsPort = 8443]
  },
  timeout = 3000,
  retries = 3
} = config;

console.log(primary);    // 'primary.com'
console.log(backup);     // 'backup.com'
console.log(httpPort);   // 80
console.log(httpsPort);  // 443
console.log(timeout);    // 5000
console.log(retries);    // 3 (по умолчанию)`;

document.getElementById('output').textContent = `primary    => 'primary.com'\nbackup     => 'backup.com'\nhttpPort   => 80\nhttpsPort  => 443\ntimeout    => 5000 (из объекта)\nretries    => 3 (по умолчанию, нет в объекте)`;
