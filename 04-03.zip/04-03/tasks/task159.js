document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию normalizeUser(), которая принимает объект с пропущенными полями и нормализует его.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function normalizeUser({
  id = null,
  name = 'Аноним',
  email = '',
  age = null,
  role = 'user',
  address: {
    city = 'Неизвестно',
    country = 'RU'
  } = {}
} = {}) {
  return { id, name, email, age, role, city, country };
}

console.log(normalizeUser({ name: 'Анна', email: 'a@b.com', age: 25 }));
// {id:null, name:'Анна', email:'a@b.com', age:25, role:'user', city:'Неизвестно', country:'RU'}

console.log(normalizeUser());
// {id:null, name:'Аноним', email:'', age:null, role:'user', city:'Неизвестно', country:'RU'}`;

document.getElementById('output').textContent = `normalizeUser({name:'Анна',email:'a@b.com',age:25})\n=> {id:null,name:'Анна',email:'a@b.com',age:25,role:'user',city:'Неизвестно',country:'RU'}\nnormalizeUser()\n=> все поля по умолчанию`;
