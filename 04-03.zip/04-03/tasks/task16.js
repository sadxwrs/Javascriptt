document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Почему у примитивов можно вызывать методы, если они не являются объектами?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// JavaScript автоматически создаёт временный объект-обёртку
// при вызове метода на примитиве

const str = 'hello';
console.log(str.toUpperCase()); // 'HELLO'
// Происходит: new String('hello').toUpperCase() — временно!

console.log((42).toString());   // '42'
// Происходит: new Number(42).toString()`;

document.getElementById('output').textContent = `JavaScript создаёт временный объект-обёртку:\n'hello'.toUpperCase() => new String('hello').toUpperCase() => 'HELLO'\n(42).toString()       => new Number(42).toString()       => '42'\nОбъект уничтожается сразу после вызова метода`;
