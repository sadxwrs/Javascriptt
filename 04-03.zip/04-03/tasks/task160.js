document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй деструктуризацию с итерируемым объектом, который не является массивом.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Деструктуризация работает с любым итерируемым!

// Строка:
const [a, b, c] = 'abc';
console.log(a, b, c); // 'a' 'b' 'c'

// Set:
const [first, second] = new Set([10, 20, 30]);
console.log(first, second); // 10 20

// Map:
const [[key1, val1], [key2, val2]] = new Map([['x', 1], ['y', 2]]);
console.log(key1, val1); // 'x' 1
console.log(key2, val2); // 'y' 2

// Генератор:
function* gen() { yield 1; yield 2; yield 3; }
const [g1, g2] = gen();
console.log(g1, g2); // 1 2`;

document.getElementById('output').textContent = `const [a,b,c] = 'abc'         => a='a', b='b', c='c'\nconst [x,y] = new Set([10,20]) => x=10, y=20\nconst [[k,v]] = new Map([['x',1]]) => k='x', v=1\nДеструктуризация массива работает с любым итерируемым`;
