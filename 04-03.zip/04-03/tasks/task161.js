document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши набор упражнений, где деструктуризация заменяет длинные цепочки обращения к полям.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `const response = {
  status: 200,
  data: {
    users: [
      { id: 1, profile: { name: 'Анна', scores: [85, 92, 78] } },
      { id: 2, profile: { name: 'Борис', scores: [70, 88, 95] } }
    ],
    total: 2
  }
};

// Без деструктуризации (длинные цепочки):
// const name = response.data.users[0].profile.name;

// С деструктуризацией:
const { status, data: { users: [{ profile: { name, scores: [s1, s2, s3] } }], total } } = response;
console.log(status);       // 200
console.log(name);         // 'Анна'
console.log(s1, s2, s3);   // 85 92 78
console.log(total);        // 2`;

document.getElementById('output').textContent = `status => 200\nname   => 'Анна' (было: response.data.users[0].profile.name)\ns1,s2,s3 => 85,92,78\ntotal  => 2\nДеструктуризация убирает длинные цепочки доступа`;
