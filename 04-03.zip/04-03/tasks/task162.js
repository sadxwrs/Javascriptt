document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Создай объект Date с текущей датой и временем.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const now = new Date();
console.log(now);         // текущая дата и время
console.log(typeof now);  // 'object'

// Timestamp (миллисекунды с 1970-01-01):
console.log(now.getTime()); // например 1710000000000

// Быстрый способ получить timestamp:
console.log(Date.now());    // то же самое
console.log(+new Date());   // то же через унарный плюс`;

document.getElementById('output').textContent = `new Date()       => текущая дата и время\nnow.getTime()    => миллисекунды с 1970-01-01 (timestamp)\nDate.now()       => то же самое, быстрее\n+new Date()      => timestamp через унарный плюс`;
