document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Создай дату по строке и по набору числовых аргументов.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// По строке:
const d1 = new Date('2026-03-18');
console.log(d1); // 2026-03-18T00:00:00.000Z

const d2 = new Date('2026-03-18T20:30:00');
console.log(d2);

// По аргументам: (год, месяц, день, ч, мин, сек)
// ВАЖНО: месяцы 0-11 (0 = январь!)
const d3 = new Date(2026, 2, 18, 20, 30, 0);
// 2 = март (0-индексация!)
console.log(d3);

// По timestamp:
const d4 = new Date(0);
console.log(d4); // 1970-01-01T00:00:00.000Z`;

document.getElementById('output').textContent = `new Date('2026-03-18')           => 18 марта 2026\nnew Date(2026, 2, 18, 20, 30, 0)  => 18 марта 2026, 20:30 (месяц 2 = март!)\nnew Date(0)                       => 1970-01-01 (Unix epoch)\nВажно: месяцы 0-11, не 1-12!`;
