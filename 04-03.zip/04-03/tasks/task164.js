document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Получи год, месяц, день, часы, минуты и секунды из даты.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const d = new Date(2026, 2, 18, 20, 30, 45);
// 18 марта 2026, 20:30:45

console.log(d.getFullYear()); // 2026
console.log(d.getMonth());    // 2 (март = индекс 2!)
console.log(d.getDate());     // 18
console.log(d.getHours());    // 20
console.log(d.getMinutes());  // 30
console.log(d.getSeconds());  // 45
console.log(d.getDay());      // день недели: 0=вс, 1=пн...3=ср`;

document.getElementById('output').textContent = `d.getFullYear() => 2026\nd.getMonth()    => 2 (март, 0-индексация!)\nd.getDate()     => 18 (число месяца)\nd.getHours()    => 20\nd.getMinutes()  => 30\nd.getSeconds()  => 45\nd.getDay()      => день недели (0=вс, 1=пн, 6=сб)`;
