document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Чем getDay() отличается от getDate()?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const d = new Date(2026, 2, 18); // 18 марта 2026, среда

console.log(d.getDate()); // 18 — ЧИСЛО МЕСЯЦА
console.log(d.getDay());  // 3  — ДЕНЬ НЕДЕЛИ (0=вс, 1=пн, 2=вт, 3=ср)

// Пример:
const days = ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'];
console.log(days[d.getDay()]); // 'Ср'

// getDate() — от 1 до 31
// getDay()  — от 0 до 6`;

document.getElementById('output').textContent = `getDate() => 18 (число месяца: 1-31)\ngetDay()  => 3  (день недели: 0=вс, 1=пн, ..., 6=сб)\n18 марта 2026 — среда, поэтому getDay() = 3\ndays[getDay()] => 'Ср'`;
