document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Установи у даты новый год, месяц и день через сеттеры.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const d = new Date(2026, 2, 18);
console.log(d.getFullYear()); // 2026

d.setFullYear(2027);
console.log(d.getFullYear()); // 2027

d.setMonth(11); // декабрь (0-индексация)
console.log(d.getMonth()); // 11

d.setDate(31);
console.log(d.getDate()); // 31

// Все вместе:
d.setFullYear(2030, 0, 1); // 1 января 2030
console.log(d.toDateString()); // 'Tue Jan 01 2030'`;

document.getElementById('output').textContent = `d.setFullYear(2027) => getFullYear() = 2027\nd.setMonth(11)      => getMonth() = 11 (декабрь)\nd.setDate(31)       => getDate() = 31\nd.setFullYear(2030,0,1) => 1 января 2030`;
