document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое timestamp? Получи его через Date.now().<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Timestamp — количество миллисекунд с 1 января 1970 00:00:00 UTC

const ts = Date.now();
console.log(ts); // например 1742300000000

// Из объекта Date:
const d = new Date();
console.log(d.getTime()); // то же
console.log(+d);           // то же

// Измерение времени выполнения:
const start = Date.now();
for (let i = 0; i < 1000000; i++) {}
const end = Date.now();
console.log(\`Время: \${end - start} мс\`);`;

document.getElementById('output').textContent = `Timestamp — миллисекунды с 1 января 1970 00:00:00 UTC\nDate.now()      => текущий timestamp (самый быстрый способ)\nd.getTime()     => timestamp из Date объекта\n+new Date()     => то же через унарный плюс\nИспользуется для измерения времени: end - start`;
