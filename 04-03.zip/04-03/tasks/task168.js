document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Преобразуй дату в строку через toString(), toDateString(), toTimeString().<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const d = new Date(2026, 2, 18, 20, 30, 45);

console.log(d.toString());
// 'Wed Mar 18 2026 20:30:45 GMT+0000'

console.log(d.toDateString());
// 'Wed Mar 18 2026'

console.log(d.toTimeString());
// '20:30:45 GMT+0000'

console.log(d.toISOString());
// '2026-03-18T20:30:45.000Z'

console.log(d.toLocaleDateString('ru-RU'));
// '18.03.2026' (зависит от локали)`;

document.getElementById('output').textContent = `toString()          => 'Wed Mar 18 2026 20:30:45 GMT+...'\ntoDateString()      => 'Wed Mar 18 2026'\ntoTimeString()      => '20:30:45 GMT+...'\ntoISOString()       => '2026-03-18T20:30:45.000Z'\ntoLocaleDateString('ru-RU') => '18.03.2026'`;
