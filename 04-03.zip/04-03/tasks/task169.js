document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Посчитай разницу в днях между двумя датами.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function daysBetween(date1, date2) {
  const msPerDay = 1000 * 60 * 60 * 24;
  const diff = Math.abs(date2.getTime() - date1.getTime());
  return Math.round(diff / msPerDay);
}

const d1 = new Date(2026, 0, 1);  // 1 января 2026
const d2 = new Date(2026, 11, 31); // 31 декабря 2026

console.log(daysBetween(d1, d2)); // 364

const today = new Date(2026, 2, 18);
const newYear = new Date(2027, 0, 1);
console.log(daysBetween(today, newYear)); // 288`;

document.getElementById('output').textContent = `daysBetween(1 янв 2026, 31 дек 2026) => 364\ndaysBetween(18 мар 2026, 1 янв 2027) => 288\nФормула: Math.abs(d2-d1) / (1000*60*60*24)`;
