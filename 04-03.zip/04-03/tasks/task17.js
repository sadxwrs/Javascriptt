document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Проверь работу 'hello'.toUpperCase() и объясни, что происходит 'под капотом'.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const result = 'hello'.toUpperCase();
console.log(result); // 'HELLO'

// Под капотом:
// 1. Создаётся временный объект: new String('hello')
// 2. Вызывается метод .toUpperCase()
// 3. Временный объект уничтожается
// 4. Возвращается примитивная строка 'HELLO'

console.log(typeof 'hello');             // 'string'
console.log(typeof new String('hello')); // 'object'`;

document.getElementById('output').textContent = `'hello'.toUpperCase() => 'HELLO'\nПод капотом: new String('hello').toUpperCase()\ntypeof 'hello'             => 'string'\ntypeof new String('hello') => 'object'`;
