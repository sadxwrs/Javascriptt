document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию formatDate(date) в формате DD.MM.YYYY.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function formatDate(date) {
  const day   = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year  = date.getFullYear();
  return \`\${day}.\${month}.\${year}\`;
}

console.log(formatDate(new Date(2026, 2, 18)));  // '18.03.2026'
console.log(formatDate(new Date(2026, 0, 5)));   // '05.01.2026'
console.log(formatDate(new Date(2026, 11, 31))); // '31.12.2026'`;

document.getElementById('output').textContent = `formatDate(new Date(2026,2,18))  => '18.03.2026'\nformatDate(new Date(2026,0,5))   => '05.01.2026'\nformatDate(new Date(2026,11,31)) => '31.12.2026'\npadStart(2,'0') — добавляет ведущий ноль`;
