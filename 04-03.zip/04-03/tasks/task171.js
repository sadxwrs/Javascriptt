document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию, которая показывает сколько минут прошло с заданного момента.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function minutesAgo(pastDate) {
  const diff = Date.now() - pastDate.getTime();
  return Math.floor(diff / (1000 * 60));
}

// Симуляция:
const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
console.log(minutesAgo(oneHourAgo)); // ~60

const tenMinAgo = new Date(Date.now() - 10 * 60 * 1000);
console.log(minutesAgo(tenMinAgo));  // ~10

const twoDaysAgo = new Date(Date.now() - 2 * 24 * 60 * 60 * 1000);
console.log(minutesAgo(twoDaysAgo)); // ~2880`;

document.getElementById('output').textContent = `minutesAgo(1 час назад)   => ~60\nminutesAgo(10 мин назад)  => ~10\nminutesAgo(2 дня назад)   => ~2880\nФормула: Math.floor((Date.now() - date.getTime()) / 60000)`;
