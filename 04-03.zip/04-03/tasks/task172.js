document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Создай дату 'через 7 дней' от текущего момента.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const today = new Date();

// Способ 1: через setDate
const in7days = new Date(today);
in7days.setDate(in7days.getDate() + 7);
console.log(in7days.toDateString());

// Способ 2: через timestamp
const in7days2 = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
console.log(in7days2.toDateString());

// Через месяц:
const nextMonth = new Date(today);
nextMonth.setMonth(nextMonth.getMonth() + 1);
console.log(nextMonth.toDateString());`;

document.getElementById('output').textContent = `new Date(today); date.setDate(date.getDate()+7) => +7 дней\nnew Date(Date.now() + 7*24*60*60*1000) => то же\nnextMonth.setMonth(month+1) => через месяц\nsetDate автоматически переходит на следующий месяц при переполнении`;
