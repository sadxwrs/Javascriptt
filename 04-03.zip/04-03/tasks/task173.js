document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое UTC-методы у даты? Сравни их с локальными методами.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const d = new Date('2026-03-18T20:30:00Z'); // UTC время

// Локальные методы (зависят от часового пояса):
console.log(d.getHours());    // зависит от вашего часового пояса
console.log(d.getDate());     // может отличаться!

// UTC методы (всегда UTC, не зависят от зоны):
console.log(d.getUTCHours()); // 20 (UTC)
console.log(d.getUTCDate());  // 18
console.log(d.getUTCMonth()); // 2 (март)

// Для серверного кода лучше UTC!
console.log(d.toISOString()); // '2026-03-18T20:30:00.000Z'`;

document.getElementById('output').textContent = `getHours()    => локальное время (зависит от часового пояса)\ngetUTCHours() => UTC время (всегда стабильно)\nДля '2026-03-18T20:30:00Z': getUTCHours()=20\nДля серверного кода используй UTC-методы!`;
