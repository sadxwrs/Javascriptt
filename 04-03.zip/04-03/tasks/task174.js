document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй toISOString() и объясни формат результата.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const d = new Date(2026, 2, 18, 20, 30, 45, 123);
console.log(d.toISOString());
// '2026-03-18T17:30:45.123Z' (конвертирует в UTC!)

// Формат: YYYY-MM-DDTHH:MM:SS.mmmZ
// YYYY — год
// MM   — месяц (01-12)
// DD   — день (01-31)
// T    — разделитель дата/время
// HH   — часы UTC (00-23)
// MM   — минуты (00-59)
// SS   — секунды (00-59)
// mmm  — миллисекунды (000-999)
// Z    — UTC (Zero offset)

// ISO используется для хранения и передачи дат!
console.log(new Date('2026-03-18T20:30:45.000Z'));
// Парсится обратно в Date`;

document.getElementById('output').textContent = `toISOString() => '2026-03-18T17:30:45.123Z'\nФормат: YYYY-MM-DDTHH:MM:SS.mmmZ\nZ означает UTC (нулевое смещение)\nISO-строка — стандарт для хранения/передачи дат`;
