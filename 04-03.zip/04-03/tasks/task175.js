document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию проверки: является ли дата выходным днём.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function isWeekend(date) {
  const day = date.getDay(); // 0=вс, 6=сб
  return day === 0 || day === 6;
}

console.log(isWeekend(new Date(2026, 2, 14))); // суббота => true
console.log(isWeekend(new Date(2026, 2, 15))); // воскресенье => true
console.log(isWeekend(new Date(2026, 2, 16))); // понедельник => false
console.log(isWeekend(new Date(2026, 2, 18))); // среда => false`;

document.getElementById('output').textContent = `isWeekend(14 марта 2026 — суббота)   => true\nisWeekend(15 марта 2026 — воскресенье) => true\nisWeekend(16 марта 2026 — понедельник) => false\nisWeekend(18 марта 2026 — среда)       => false\ngetDay(): 0=вс, 6=сб => выходные`;
