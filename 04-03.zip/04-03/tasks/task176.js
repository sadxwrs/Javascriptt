document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию, которая возвращает номер недели месяца для заданной даты.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function weekOfMonth(date) {
  const firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
  const dayOfMonth = date.getDate();
  const firstWeekday = firstDay.getDay() || 7; // пн=1, вс=7
  return Math.ceil((dayOfMonth + firstWeekday - 1) / 7);
}

console.log(weekOfMonth(new Date(2026, 2, 1)));  // 1 (1-я неделя)
console.log(weekOfMonth(new Date(2026, 2, 7)));  // 1 или 2
console.log(weekOfMonth(new Date(2026, 2, 18))); // 3
console.log(weekOfMonth(new Date(2026, 2, 31))); // 5`;

document.getElementById('output').textContent = `weekOfMonth(1 марта 2026)  => 1\nweekOfMonth(18 марта 2026) => 3\nweekOfMonth(31 марта 2026) => 5\nФормула: Math.ceil((dayOfMonth + firstWeekday - 1) / 7)`;
