document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Сделай таймер обратного отсчёта до определённой даты.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function countdown(targetDate) {
  const diff = targetDate.getTime() - Date.now();
  if (diff <= 0) return 'Время вышло!';

  const days    = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours   = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((diff % (1000 * 60)) / 1000);

  return \`\${days}д \${hours}ч \${minutes}м \${seconds}с\`;
}

const newYear = new Date(2027, 0, 1);
console.log(countdown(newYear)); // например '288д 3ч 29м 15с'

const past = new Date(2020, 0, 1);
console.log(countdown(past)); // 'Время вышло!'`;

document.getElementById('output').textContent = `countdown(1 января 2027) => '288д 3ч 29м 15с' (приблизительно)\ncountdown(прошлая дата)   => 'Время вышло!'\nФормула: Math.floor(diff / единица_в_мс)`;
