document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию, которая корректно добавляет месяцы к дате с учётом переполнения.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function addMonths(date, months) {
  const result = new Date(date);
  const day = result.getDate();
  result.setMonth(result.getMonth() + months);
  // Если setMonth перешёл на следующий месяц (напр. 31 янв + 1 мес),
  // откатываемся на последний день нужного месяца
  if (result.getDate() !== day) {
    result.setDate(0); // 0 = последний день предыдущего месяца
  }
  return result;
}

console.log(addMonths(new Date(2026, 0, 31), 1).toDateString());
// '28 Feb 2026' (31 января + 1 мес = последний день февраля)

console.log(addMonths(new Date(2026, 0, 15), 3).toDateString());
// '15 Apr 2026'`;

document.getElementById('output').textContent = `addMonths(31 января 2026, 1) => 28 февраля 2026 (корректно!)\naddMonths(15 января 2026, 3) => 15 апреля 2026\nПроблема: 31 + 1 месяц в JS даёт 3 марта (переполнение)\nРешение: сравниваем getDate() до и после setMonth`;
