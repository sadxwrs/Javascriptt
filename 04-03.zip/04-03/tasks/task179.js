document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Сравни способы форматирования даты: вручную, через Intl.DateTimeFormat и через ISO-строку.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `const d = new Date(2026, 2, 18, 20, 30, 45);

// 1. Вручную:
const manual = \`\${d.getDate().toString().padStart(2,'0')}.\${(d.getMonth()+1).toString().padStart(2,'0')}.\${d.getFullYear()}\`;
console.log(manual); // '18.03.2026'

// 2. Intl.DateTimeFormat (локализованный):
const intl = new Intl.DateTimeFormat('ru-RU', {
  day: '2-digit', month: '2-digit', year: 'numeric'
}).format(d);
console.log(intl); // '18.03.2026'

// 3. ISO строка (UTC!):
console.log(d.toISOString().split('T')[0]);
// '2026-03-18' (только дата, формат YYYY-MM-DD)

// 4. toLocaleDateString:
console.log(d.toLocaleDateString('ru-RU'));
// '18.03.2026'`;

document.getElementById('output').textContent = `Вручную:          '18.03.2026' (полный контроль)\nIntl.DateTimeFormat: '18.03.2026' (локализация из коробки)\ntoISOString().split('T')[0]: '2026-03-18' (формат YYYY-MM-DD, UTC!)\ntoLocaleDateString('ru-RU'): '18.03.2026' (краткий способ)`;
