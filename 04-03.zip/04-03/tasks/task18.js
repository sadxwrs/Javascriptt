document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что вернёт (123.456).toFixed(2)?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `console.log((123.456).toFixed(2));    // '123.46'
console.log((1.005).toFixed(2));      // '1.00' (погрешность float)
console.log((0).toFixed(3));          // '0.000'
console.log(typeof (1.5).toFixed(1)); // 'string' — возвращает строку!`;

document.getElementById('output').textContent = `(123.456).toFixed(2)  => '123.46'\n(1.005).toFixed(2)    => '1.00' (погрешность float!)\n(0).toFixed(3)        => '0.000'\ntypeof: возвращает строку, не число!`;
