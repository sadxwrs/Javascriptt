document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй функцию парсинга строки вида '15.03.2026 20:30' в объект Date.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function parseDate(str) {
  const [datePart, timePart = '00:00'] = str.split(' ');
  const [day, month, year] = datePart.split('.').map(Number);
  const [hours, minutes] = timePart.split(':').map(Number);
  // Месяц 0-индексированный!
  const date = new Date(year, month - 1, day, hours, minutes);
  if (isNaN(date.getTime())) throw new Error('Неверный формат');
  return date;
}

console.log(parseDate('15.03.2026 20:30'));
// Date: 2026-03-15T17:30:00.000Z

console.log(parseDate('01.01.2027'));
// Date: 2027-01-01T00:00:00.000Z

console.log(parseDate('15.03.2026 20:30').toLocaleDateString('ru-RU'));
// '15.03.2026'`;

document.getElementById('output').textContent = `parseDate('15.03.2026 20:30') => Date(2026-03-15 20:30)\nparseDate('01.01.2027')       => Date(2027-01-01 00:00)\nПарсинг: split(' '), split('.'), split(':'), Number()\nОсторожно: month - 1 (0-индексация!)`;
