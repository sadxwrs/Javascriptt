document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Сделай объект-планировщик событий, который хранит массив дат и умеет находить ближайшее событие.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `class EventScheduler {
  constructor() { this.events = []; }

  add(name, date) {
    this.events.push({ name, date: new Date(date) });
    this.events.sort((a, b) => a.date - b.date);
  }

  next() {
    const future = this.events.filter(e => e.date > new Date());
    return future.length ? future[0] : null;
  }

  upcoming(days = 7) {
    const limit = new Date(Date.now() + days * 86400000);
    return this.events.filter(e => e.date > new Date() && e.date <= limit);
  }
}

const s = new EventScheduler();
s.add('Встреча', '2027-01-15');
s.add('Дедлайн', '2026-12-31');
s.add('Отпуск', '2026-08-01');

console.log(s.next()?.name); // ближайшее событие`;

document.getElementById('output').textContent = `s.add('Отпуск','2026-08-01')\ns.add('Дедлайн','2026-12-31')\ns.add('Встреча','2027-01-15')\ns.next() => { name:'Отпуск', date:... } (ближайшее)\ns.upcoming(7) => события в ближайшие 7 дней`;
