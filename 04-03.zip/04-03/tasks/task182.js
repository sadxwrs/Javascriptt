document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое JSON? Чем он отличается от обычного объекта JavaScript?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// JSON — JavaScript Object Notation, текстовый формат данных

// Объект JS:
const obj = { name: 'Анна', age: 25, active: true };

// JSON (строка!):
const json = '{"name":"Анна","age":25,"active":true}';

// Отличия JSON от JS объекта:
// 1. JSON — это строка, не объект
console.log(typeof obj);  // 'object'
console.log(typeof json); // 'string'

// 2. В JSON ключи ТОЛЬКО в двойных кавычках
// 3. Нет undefined, функций, Symbol
// 4. Нет комментариев
// 5. Числа — только конечные (не NaN, не Infinity)`;

document.getElementById('output').textContent = `JSON — текстовый формат данных (строка!), не объект\ntypeof obj  => 'object'\ntypeof json => 'string'\nОтличия JSON: ключи только в двойных кавычках, нет undefined/function/Symbol/NaN/Infinity, нет комментариев`;
