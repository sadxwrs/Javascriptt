document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Преобразуй объект в JSON-строку через JSON.stringify().<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const user = { name: 'Борис', age: 30, city: 'Москва' };

const json = JSON.stringify(user);
console.log(json);
// '{"name":"Борис","age":30,"city":"Москва"}'

console.log(typeof json); // 'string'

// Массив тоже:
const arr = [1, 2, 3];
console.log(JSON.stringify(arr)); // '[1,2,3]'

// Вложенный объект:
const data = { a: 1, b: { c: 2 } };
console.log(JSON.stringify(data)); // '{"a":1,"b":{"c":2}}'`;

document.getElementById('output').textContent = `JSON.stringify({name:'Борис',age:30}) => '{"name":"Борис","age":30}'\ntypeof JSON.stringify(...) => 'string'\nJSON.stringify([1,2,3]) => '[1,2,3]'\nJSON.stringify({a:1,b:{c:2}}) => '{"a":1,"b":{"c":2}}'`;
