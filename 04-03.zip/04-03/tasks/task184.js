document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Преобразуй JSON-строку обратно в объект через JSON.parse().<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const json = '{"name":"Вера","age":28,"city":"Питер"}';

const obj = JSON.parse(json);
console.log(obj);       // { name:'Вера', age:28, city:'Питер' }
console.log(typeof obj); // 'object'
console.log(obj.name);  // 'Вера'

// Массив:
const arr = JSON.parse('[1,2,3]');
console.log(arr);           // [1, 2, 3]
console.log(Array.isArray(arr)); // true

// Глубокое клонирование (простой способ):
const original = { a: { b: 1 } };
const clone = JSON.parse(JSON.stringify(original));
clone.a.b = 99;
console.log(original.a.b); // 1 — не изменился!`;

document.getElementById('output').textContent = `JSON.parse('{"name":"Вера"}') => { name:'Вера', age:28, city:'Питер' }\ntypeof JSON.parse(...) => 'object'\nJSON.parse('[1,2,3]') => [1,2,3]\nJSON.parse(JSON.stringify(obj)) — глубокое клонирование`;
