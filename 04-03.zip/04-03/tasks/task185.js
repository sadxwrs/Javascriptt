document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Какие типы данных корректно сериализуются в JSON, а какие нет?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Корректно сериализуются:
console.log(JSON.stringify({ n: 42 }));       // {"n":42}
console.log(JSON.stringify({ s: 'hello' })); // {"s":"hello"}
console.log(JSON.stringify({ b: true }));    // {"b":true}
console.log(JSON.stringify({ a: [1,2] }));   // {"a":[1,2]}
console.log(JSON.stringify({ n: null }));    // {"n":null}

// НЕ сериализуются (исчезают или становятся null):
console.log(JSON.stringify({ f: function(){} })); // '{}' (функция исчезла!)
console.log(JSON.stringify({ u: undefined }));    // '{}'
console.log(JSON.stringify({ s: Symbol() }));     // '{}'
console.log(JSON.stringify([undefined, function(){}])); // '[null,null]'`;

document.getElementById('output').textContent = `Сериализуются:  number, string, boolean, null, array, object\nНЕ сериализуются: undefined, function, Symbol\nВ объекте: эти значения ИСЧЕЗАЮТ из JSON\nВ массиве: эти значения становятся null`;
