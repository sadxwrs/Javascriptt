document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что происходит с функциями, undefined и Symbol при JSON.stringify()?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const obj = {
  name: 'Тест',
  fn: function() { return 42; },
  undef: undefined,
  sym: Symbol('id'),
  num: 100
};

console.log(JSON.stringify(obj));
// '{"name":"Тест","num":100}'
// fn, undef, sym — полностью исчезли!

// В массиве — становятся null:
console.log(JSON.stringify([1, undefined, function(){}, Symbol()]));
// '[1,null,null,null]'`;

document.getElementById('output').textContent = `JSON.stringify({name:'Тест', fn:()=>{}, undef:undefined, num:100})\n=> '{"name":"Тест","num":100}' (fn, undef, sym исчезли!)\nВ массиве: JSON.stringify([1, undefined, ()=>{}]) => '[1,null,null]'`;
