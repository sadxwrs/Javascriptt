document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что произойдёт с объектом Date при сериализации в JSON?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const event = {
  name: 'Встреча',
  date: new Date(2026, 2, 18, 20, 30)
};

console.log(JSON.stringify(event));
// '{"name":"Встреча","date":"2026-03-18T17:30:00.000Z"}'

// Date превращается в ISO-строку!
// При JSON.parse не восстанавливается автоматически:
const parsed = JSON.parse(JSON.stringify(event));
console.log(typeof parsed.date); // 'string'!
console.log(parsed.date instanceof Date); // false!

// Чтобы восстановить:
parsed.date = new Date(parsed.date);
console.log(parsed.date instanceof Date); // true`;

document.getElementById('output').textContent = `JSON.stringify({date: new Date()}) => date превращается в ISO-строку\n'{"date":"2026-03-18T17:30:00.000Z"}'\nJSON.parse() НЕ восстанавливает Date автоматически!\ntypeof parsed.date => 'string'\nЧтобы восстановить: new Date(parsed.date)`;
