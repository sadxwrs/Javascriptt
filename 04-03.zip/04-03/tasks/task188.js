document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй второй аргумент JSON.stringify() — массив разрешённых ключей.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const user = { id: 1, name: 'Анна', password: 'secret', age: 25 };

// Разрешить только id и name:
const safe = JSON.stringify(user, ['id', 'name']);
console.log(safe);
// '{"id":1,"name":"Анна"}' — password скрыт!

const product = {
  id: 10,
  name: 'Ноутбук',
  price: 50000,
  cost: 30000,  // скрытое поле
  category: 'tech'
};
console.log(JSON.stringify(product, ['id', 'name', 'price']));
// '{"id":10,"name":"Ноутбук","price":50000}'`;

document.getElementById('output').textContent = `JSON.stringify(user, ['id','name'])\n=> '{"id":1,"name":"Анна"}' (password и age скрыты!)\nМассив-replacer задаёт белый список разрешённых ключей`;
