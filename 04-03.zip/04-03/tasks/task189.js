document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй второй аргумент JSON.stringify() как функцию-replacer.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const data = { name: 'Борис', age: 30, password: 'secret', salary: 100000 };

// Скрыть пароль через replacer-функцию:
const json = JSON.stringify(data, (key, value) => {
  if (key === 'password') return undefined; // пропустить
  if (typeof value === 'number') return value * 2; // удвоить числа
  return value;
});
console.log(json);
// '{"name":"Борис","age":60,"salary":200000}'`;

document.getElementById('output').textContent = `JSON.stringify(data, (key,val) => key==='password' ? undefined : val)\n=> password скрыт\nJSON.stringify(data, (key,val) => typeof val==='number' ? val*2 : val)\n=> числа удвоены\nreplacer(key,value): return undefined => пропустить поле`;
