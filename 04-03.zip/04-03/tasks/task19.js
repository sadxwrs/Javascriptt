document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй true.toString() и объясни результат.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `console.log(true.toString());   // 'true'
console.log(false.toString());  // 'false'

// Под капотом: new Boolean(true).toString()
console.log(typeof true.toString()); // 'string'
console.log(String(true));           // 'true' — другой способ`;

document.getElementById('output').textContent = `true.toString()        => 'true'\nfalse.toString()       => 'false'\ntypeof true.toString() => 'string'\nПод капотом: new Boolean(true).toString()`;
