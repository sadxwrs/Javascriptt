document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй третий аргумент JSON.stringify() для красивого форматирования.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const user = { name: 'Вера', age: 28, address: { city: 'Казань', zip: '420000' } };

// Без форматирования:
console.log(JSON.stringify(user));
// '{"name":"Вера","age":28,"address":{"city":"Казань","zip":"420000"}}'

// С отступом 2 пробела:
console.log(JSON.stringify(user, null, 2));
// {
//   "name": "Вера",
//   "age": 28,
//   "address": {
//     "city": "Казань",
//     "zip": "420000"
//   }
// }

// С табуляцией:
console.log(JSON.stringify(user, null, '\\t'));`;

document.getElementById('output').textContent = `JSON.stringify(obj, null, 2) => красивый JSON с отступами 2 пробела\nJSON.stringify(obj, null, 4) => 4 пробела\nJSON.stringify(obj, null, '\t') => табуляция\nТретий аргумент — количество пробелов или строка`;
