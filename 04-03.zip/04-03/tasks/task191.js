document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй второй аргумент JSON.parse() как функцию-reviver.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const json = '{"name":"Анна","score":100,"bonus":50}';

// Reviver вызывается для каждой пары ключ-значение:
const obj = JSON.parse(json, (key, value) => {
  if (typeof value === 'number') return value * 2; // удвоить числа
  return value;
});
console.log(obj);
// { name:'Анна', score:200, bonus:100 }

// Пустые ключи тоже проходят через reviver:
const data = JSON.parse('{"x":1}', (key, value) => {
  console.log(\`key: '\${key}', value:\`, value);
  return value;
});
// key: 'x', value: 1
// key: '', value: {x:1} (корневой объект!)`;

document.getElementById('output').textContent = `JSON.parse(json, (key,val) => typeof val==='number' ? val*2 : val)\n=> { name:'Анна', score:200, bonus:100 }\nReviver вызывается для КАЖДОЙ пары, включая корневой объект (key='')`;
