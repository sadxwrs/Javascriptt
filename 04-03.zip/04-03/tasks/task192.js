document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши пример, где через reviver строка даты превращается обратно в объект Date.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const event = { name: 'Встреча', date: new Date(2026, 2, 18) };

const json = JSON.stringify(event);
console.log(json);
// '{"name":"Встреча","date":"2026-03-18T...Z"}'

// Reviver восстанавливает Date из строки:
const dateRegex = /^\\d{4}-\\d{2}-\\d{2}T.*Z$/;
const restored = JSON.parse(json, (key, value) => {
  if (typeof value === 'string' && dateRegex.test(value)) {
    return new Date(value);
  }
  return value;
});

console.log(restored.date instanceof Date); // true!
console.log(restored.date.getFullYear());   // 2026`;

document.getElementById('output').textContent = `JSON.stringify({date: new Date()}) => дата превращается в строку\nJSON.parse(json, reviver) с проверкой ISO-формата => восстанавливает Date\nrestored.date instanceof Date => true\nrestored.date.getFullYear()   => 2026`;
