document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что делает метод toJSON()? Напиши объект со своим toJSON().<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const user = {
  name: 'Иван',
  password: 'secret',
  createdAt: new Date(2026, 2, 18),
  toJSON() {
    // Возвращаем только безопасные поля:
    return {
      name: this.name,
      createdAt: this.createdAt.toISOString().split('T')[0]
    };
  }
};

console.log(JSON.stringify(user));
// '{"name":"Иван","createdAt":"2026-03-18"}'
// password скрыт, дата форматирована!

// Именно поэтому Date.toJSON() => ISO-строка:
console.log(new Date(2026, 2, 18).toJSON());
// '2026-03-18T00:00:00.000Z'`;

document.getElementById('output').textContent = `toJSON() вызывается автоматически при JSON.stringify\nJSON.stringify(user) => '{"name":"Иван","createdAt":"2026-03-18"}' (password скрыт!)\nnew Date().toJSON() => ISO-строка (именно так Date сериализуется в JSON)`;
