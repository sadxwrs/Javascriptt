document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Покажи, как toJSON() меняет результат сериализации объекта.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Без toJSON:
const point1 = { x: 3, y: 4 };
console.log(JSON.stringify(point1));
// '{"x":3,"y":4}'

// С toJSON:
const point2 = {
  x: 3,
  y: 4,
  toJSON() {
    return \`(\${this.x}, \${this.y})\`; // строка вместо объекта!
  }
};
console.log(JSON.stringify(point2));
// '"(3, 4)"'

// toJSON в массиве тоже работает:
const arr = [point2, { x: 0, y: 0 }];
console.log(JSON.stringify(arr));
// '["(3, 4)",{"x":0,"y":0}]'`;

document.getElementById('output').textContent = `Без toJSON: JSON.stringify({x:3,y:4}) => '{"x":3,"y":4}'\nС toJSON:   JSON.stringify(point2) => '"(3, 4)"'\ntoJSON может вернуть что угодно: строку, число, объект\nРаботает и при вложении в массивы/объекты`;
