document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Сериализуй Map вручную в JSON и потом восстанови его.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const map = new Map([['name', 'Анна'], ['age', 25], ['city', 'Москва']]);

// Map => JSON (через Array.from):
const json = JSON.stringify(Array.from(map.entries()));
console.log(json);
// '[["name","Анна"],["age",25],["city","Москва"]]'

// JSON => Map:
const restored = new Map(JSON.parse(json));
console.log(restored.get('name')); // 'Анна'
console.log(restored.get('age'));  // 25
console.log(restored.size);        // 3
console.log(restored instanceof Map); // true`;

document.getElementById('output').textContent = `Map => JSON: JSON.stringify(Array.from(map.entries()))\n=> '[["name","Анна"],["age",25],["city","Москва"]]'\nJSON => Map: new Map(JSON.parse(json))\nrestored.get('name') => 'Анна'\nrestored instanceof Map => true`;
