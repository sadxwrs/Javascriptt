document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Сериализуй Set вручную в JSON и потом восстанови его.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const set = new Set([1, 2, 3, 4, 5]);

// Set => JSON (через Array.from или spread):
const json = JSON.stringify([...set]);
console.log(json); // '[1,2,3,4,5]'

// JSON => Set:
const restored = new Set(JSON.parse(json));
console.log(restored.has(3));    // true
console.log(restored.size);      // 5
console.log(restored instanceof Set); // true

// Строки тоже:
const strSet = new Set(['a', 'b', 'c']);
const strJson = JSON.stringify([...strSet]);
const restoredStr = new Set(JSON.parse(strJson));
console.log(restoredStr.has('b')); // true`;

document.getElementById('output').textContent = `Set => JSON: JSON.stringify([...set]) => '[1,2,3,4,5]'\nJSON => Set: new Set(JSON.parse(json))\nrestored.has(3) => true\nrestored.size   => 5`;
