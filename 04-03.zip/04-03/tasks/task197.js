document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Объясни, почему циклические ссылки ломают JSON.stringify().<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Циклическая ссылка: объект ссылается на себя
const a = { name: 'a' };
a.self = a; // a ссылается на a!

try {
  JSON.stringify(a);
} catch (e) {
  console.log(e.message);
  // 'Converting circular structure to JSON'
}

// Реальный пример:
const parent = { name: 'parent' };
const child = { name: 'child', parent: parent };
parent.child = child; // циклическая ссылка!

try {
  JSON.stringify(parent);
} catch (e) {
  console.log('Ошибка:', e.message);
}
// Ошибка: Converting circular structure to JSON`;

document.getElementById('output').textContent = `a.self = a => JSON.stringify(a) => TypeError: Converting circular structure to JSON\nПричина: JSON.stringify пытается обойти бесконечно вложенный объект\nparen.child = child; child.parent = parent => тоже циклическая ссылка`;
