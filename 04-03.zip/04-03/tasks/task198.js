document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй безопасную сериализацию объекта с циклическими ссылками.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function safeStringify(obj, indent = 0) {
  const seen = new Set();
  return JSON.stringify(obj, (key, value) => {
    if (typeof value === 'object' && value !== null) {
      if (seen.has(value)) {
        return '[Circular]';
      }
      seen.add(value);
    }
    return value;
  }, indent);
}

const a = { name: 'a', data: { x: 1 } };
a.self = a;

console.log(safeStringify(a));
// '{"name":"a","data":{"x":1},"self":"[Circular]"}'

const normal = { a: 1, b: { c: 2 } };
console.log(safeStringify(normal, 2));`;

document.getElementById('output').textContent = `safeStringify(a) где a.self=a\n=> '{"name":"a","data":{"x":1},"self":"[Circular]"}'\nАлгоритм: Set seen для отслеживания посещённых объектов\nЦиклическая ссылка заменяется на строку '[Circular]'`;
