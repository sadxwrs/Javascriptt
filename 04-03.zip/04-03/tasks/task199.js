document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Сделай функцию saveState(obj) и loadState(json) для сохранения и восстановления состояния.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function saveState(obj) {
  try {
    return JSON.stringify(obj, (key, value) => {
      if (value instanceof Date) return { __type: 'Date', value: value.toISOString() };
      if (value instanceof Set)  return { __type: 'Set',  value: [...value] };
      if (value instanceof Map)  return { __type: 'Map',  value: [...value.entries()] };
      return value;
    });
  } catch (e) {
    return null;
  }
}

function loadState(json) {
  return JSON.parse(json, (key, value) => {
    if (value?.__type === 'Date') return new Date(value.value);
    if (value?.__type === 'Set')  return new Set(value.value);
    if (value?.__type === 'Map')  return new Map(value.value);
    return value;
  });
}

const state = { name: 'App', date: new Date(2026,2,18), tags: new Set(['js','ts']) };
const json = saveState(state);
const loaded = loadState(json);
console.log(loaded.date instanceof Date); // true
console.log(loaded.tags instanceof Set);  // true
console.log(loaded.tags.has('js'));        // true`;

document.getElementById('output').textContent = `saveState({date:new Date(), tags:new Set(['js'])}) => JSON-строка\nloadState(json) => восстанавливает Date, Set, Map\nloaded.date instanceof Date => true\nloaded.tags instanceof Set  => true\nloaded.tags.has('js')       => true`;
