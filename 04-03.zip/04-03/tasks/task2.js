document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Чем примитивы отличаются от объектов?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Примитивы хранятся по значению, объекты — по ссылке
let a = 5;
let b = a;
b = 10;
console.log(a); // 5 — не изменился

let obj1 = { x: 5 };
let obj2 = obj1;
obj2.x = 10;
console.log(obj1.x); // 10 — изменился!`;

document.getElementById('output').textContent = `Примитив: копируется по значению\nОбъект: копируется по ссылке\na=5, b=a, b=10 => a=5 (не изменился)\nobj1={x:5}, obj2=obj1, obj2.x=10 => obj1.x=10 (изменился)`;
