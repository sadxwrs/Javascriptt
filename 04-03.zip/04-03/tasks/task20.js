document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Почему у null и undefined нельзя вызывать методы?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// null и undefined не имеют объектов-обёрток
try {
  null.toString();
} catch (e) {
  console.log(e.message); // Cannot read properties of null
}

try {
  undefined.toString();
} catch (e) {
  console.log(e.message); // Cannot read properties of undefined
}

// У остальных примитивов есть обёртки: String, Number, Boolean, Symbol, BigInt`;

document.getElementById('output').textContent = `null.toString()      => TypeError\nundefined.toString() => TypeError\nПричина: у null и undefined нет объектов-обёрток\nОстальные примитивы имеют обёртки (String, Number, Boolean...)`;
