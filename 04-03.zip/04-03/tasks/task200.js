document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши объект с несколькими уровнями вложенности и кастомными toJSON() у внутренних объектов.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `class Money {
  constructor(amount, currency) {
    this.amount = amount;
    this.currency = currency;
  }
  toJSON() {
    return \`\${this.amount} \${this.currency}\`;
  }
}

class DateRange {
  constructor(start, end) {
    this.start = new Date(start);
    this.end = new Date(end);
  }
  toJSON() {
    return { from: this.start.toISOString().split('T')[0], to: this.end.toISOString().split('T')[0] };
  }
}

const project = {
  name: 'Разработка сайта',
  budget: new Money(500000, 'RUB'),
  period: new DateRange('2026-03-01', '2026-06-30'),
  team: ['Анна', 'Борис']
};

console.log(JSON.stringify(project, null, 2));
// {
//   "name": "Разработка сайта",
//   "budget": "500000 RUB",
//   "period": { "from": "2026-03-01", "to": "2026-06-30" },
//   "team": ["Анна", "Борис"]
// }`;

document.getElementById('output').textContent = `JSON.stringify(project):\n{\n  name: 'Разработка сайта',\n  budget: '500000 RUB',          (из Money.toJSON)\n  period: {from:'2026-03-01', to:'2026-06-30'}, (из DateRange.toJSON)\n  team: ['Анна','Борис']\n}\ntoJSON вызывается автоматически на каждом вложенном объекте`;
