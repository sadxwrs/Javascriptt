document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши пример, где строка временно оборачивается в объект для вызова метода.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const primitive = 'world';

// Эмуляция того, что делает JS:
const temp = new String(primitive);
const result = temp.toUpperCase();
// temp уничтожается

console.log(result);    // 'WORLD'
console.log(primitive); // 'world' — примитив не изменился

// Попытка добавить свойство:
primitive.custom = 42;
console.log(primitive.custom); // undefined — свойство потеряно!`;

document.getElementById('output').textContent = `primitive = 'world'\nprimitive.toUpperCase() => 'WORLD' (через временный new String)\nprimitive.custom = 42 — свойство НЕ сохраняется!\nprimitive.custom => undefined`;
