document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Покажи разницу между примитивной строкой и объектом new String('abc').<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const prim = 'abc';
const obj  = new String('abc');

console.log(typeof prim); // 'string'
console.log(typeof obj);  // 'object'

console.log(prim == obj);  // true  (нестрогое)
console.log(prim === obj); // false (строгое!)

if (obj) console.log('объект всегда truthy');
if (!prim) console.log('не выведет');`;

document.getElementById('output').textContent = `typeof 'abc'             => 'string'\ntypeof new String('abc') => 'object'\n'abc' == new String('abc')  => true\n'abc' === new String('abc') => false!\nnew String('') — всегда truthy (объект)`;
