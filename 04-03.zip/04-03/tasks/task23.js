document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Сравни поведение new Number(5) и числа 5 в условиях и сравнениях.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const num = 5;
const obj = new Number(5);

console.log(typeof num);  // 'number'
console.log(typeof obj);  // 'object'

console.log(num == obj);  // true
console.log(num === obj); // false

// В условиях:
if (new Number(0)) console.log('new Number(0) — truthy!'); // выведет!
if (!0)            console.log('0 — falsy!');               // выведет!`;

document.getElementById('output').textContent = `typeof 5            => 'number'\ntypeof new Number(5) => 'object'\n5 == new Number(5)   => true\n5 === new Number(5)  => false\nВажно: new Number(0) => truthy (объект), 0 => falsy!`;
