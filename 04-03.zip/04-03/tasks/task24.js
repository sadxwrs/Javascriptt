document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию, которая принимает примитив и вызывает у него подходящий метод.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function callMethod(val) {
  if (val === null || val === undefined)
    return \`\${val} — нет методов\`;

  switch (typeof val) {
    case 'string':  return val.toUpperCase();
    case 'number':  return val.toFixed(2);
    case 'boolean': return val.toString();
    case 'bigint':  return val.toString();
    case 'symbol':  return val.toString();
    default:        return 'неизвестный тип';
  }
}

console.log(callMethod('hello'));  // 'HELLO'
console.log(callMethod(3.14));     // '3.14'
console.log(callMethod(true));     // 'true'
console.log(callMethod(null));     // 'null — нет методов'`;

document.getElementById('output').textContent = `callMethod('hello')   => 'HELLO'\ncallMethod(3.14)      => '3.14'\ncallMethod(true)      => 'true'\ncallMethod(null)      => 'null — нет методов'\ncallMethod(undefined) => 'undefined — нет методов'`;
