document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Объясни, почему 'abc'.x = 10 не сохраняет свойство у строки.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `const str = 'abc';
str.x = 10;
console.log(str.x); // undefined

// Причина:
// 1. JS создаёт: temp = new String('abc')
// 2. Записывает: temp.x = 10
// 3. Уничтожает temp — свойство потеряно!

// Только объект String сохраняет:
const strObj = new String('abc');
strObj.x = 10;
console.log(strObj.x); // 10`;

document.getElementById('output').textContent = `str = 'abc'; str.x = 10; str.x => undefined\nПричина: создаётся временный new String\nСвойство пишется в него, затем объект уничтожается\nnew String('abc').x = 10 => сохраняется`;
