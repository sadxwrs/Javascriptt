document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Покажи на примерах, почему объекты-обёртки String, Number, Boolean обычно не используют.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Проблема 1: всегда truthy
if (new Boolean(false)) {
  console.log('Это неожиданно!'); // выполнится!
}

// Проблема 2: === не работает
console.log(new String('a') === new String('a')); // false!

// Проблема 3: typeof путает
console.log(typeof new Number(1)); // 'object', не 'number'

// Правильно: используй примитивы
console.log(typeof 'hello');       // 'string'
console.log(typeof new String('hello')); // 'object'`;

document.getElementById('output').textContent = `new Boolean(false) => truthy (объект всегда truthy!)\nnew String('a') === new String('a') => false!\ntypeof new Number(1) => 'object' (не 'number'!)\nВывод: использовать примитивы напрямую`;
