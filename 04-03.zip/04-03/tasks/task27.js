document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши мини-статью в кодовых комментариях: как работает временный объект-обёртка у примитивов.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// ===== КАК РАБОТАЕТ ОБЁРТКА ПРИМИТИВОВ =====
//
// Примитивы (string, number, boolean, symbol, bigint)
// имеют классы-обёртки: String, Number, Boolean, Symbol, BigInt
//
// При вызове метода на примитиве JS:
// a) Создаёт временный: tmp = new String(s)
// b) Вызывает: tmp.toUpperCase()
// c) Уничтожает tmp
// d) Возвращает результат

const s = 'hello';
console.log(s.toUpperCase()); // 'HELLO'
console.log(typeof s);        // 'string' — не изменился

// null и undefined — исключение: обёрток нет!`;

document.getElementById('output').textContent = `Примитивы имеют классы-обёртки: String, Number, Boolean, Symbol, BigInt\nПри вызове метода JS автоматически:\n1. Создаёт tmp = new String(s)\n2. Вызывает метод на tmp\n3. Уничтожает tmp\n4. Возвращает результат\nnull/undefined — нет обёрток, методы вызвать нельзя`;
