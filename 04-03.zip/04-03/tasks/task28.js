document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое тип number в JavaScript? Какие числа он хранит?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// number — 64-битный формат с плавающей точкой (IEEE 754)
console.log(typeof 42);        // 'number'
console.log(typeof 3.14);      // 'number'
console.log(typeof Infinity);  // 'number'
console.log(typeof NaN);       // 'number'

console.log(Number.MAX_SAFE_INTEGER); // 9007199254740991
console.log(Number.MIN_SAFE_INTEGER); // -9007199254740991`;

document.getElementById('output').textContent = `number — 64-битный IEEE 754 (double precision)\nХранит целые и дробные числа, Infinity, NaN\nNumber.MAX_SAFE_INTEGER  => 9007199254740991\nNumber.MIN_SAFE_INTEGER  => -9007199254740991`;
