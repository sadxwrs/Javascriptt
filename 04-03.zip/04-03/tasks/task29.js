document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Найди результат выражения 0.1 + 0.2 и объясни особенность.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `console.log(0.1 + 0.2);         // 0.30000000000000004
console.log(0.1 + 0.2 === 0.3); // false!

// Причина: числа в двоичном формате,
// 0.1 и 0.2 не имеют точного двоичного представления

// Решение:
console.log((0.1 + 0.2).toFixed(1)); // '0.3'
console.log(Math.abs(0.1 + 0.2 - 0.3) < Number.EPSILON); // true`;

document.getElementById('output').textContent = `0.1 + 0.2 => 0.30000000000000004\n0.1 + 0.2 === 0.3 => false!\nПричина: двоичное представление чисел с плавающей точкой\nРешение: (0.1+0.2).toFixed(1) => '0.3'`;
