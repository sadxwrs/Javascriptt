document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что возвращает typeof 42, typeof 'hi', typeof true?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `console.log(typeof 42);     // 'number'
console.log(typeof 'hi');   // 'string'
console.log(typeof true);   // 'boolean'`;

document.getElementById('output').textContent = `typeof 42     => 'number'\ntypeof 'hi'   => 'string'\ntypeof true   => 'boolean'`;
