document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Чем отличаются parseInt и parseFloat?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `console.log(parseInt('42px'));      // 42    (целое)
console.log(parseFloat('3.14abc'));  // 3.14  (дробное)

console.log(parseInt('3.9'));        // 3     (отбрасывает дробь)
console.log(parseFloat('3.9'));      // 3.9   (сохраняет дробь)

console.log(parseInt('0xff', 16));   // 255   (с основанием)
console.log(parseInt('abc'));        // NaN`;

document.getElementById('output').textContent = `parseInt('42px')     => 42   (парсит до нечислового символа)\nparseFloat('3.14abc')=> 3.14\nparseInt('3.9')      => 3    (отбрасывает дробь)\nparseFloat('3.9')    => 3.9  (сохраняет дробь)\nparseInt('0xff', 16) => 255`;
