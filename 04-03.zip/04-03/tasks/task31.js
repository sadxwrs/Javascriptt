document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что вернёт Number('123') и Number('123px')?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `console.log(Number('123'));     // 123
console.log(Number('123px'));   // NaN
console.log(Number(''));        // 0
console.log(Number(true));      // 1
console.log(Number(false));     // 0
console.log(Number(null));      // 0
console.log(Number(undefined)); // NaN`;

document.getElementById('output').textContent = `Number('123')     => 123\nNumber('123px')   => NaN (содержит нечисловые символы)\nNumber('')        => 0\nNumber(true)      => 1\nNumber(false)     => 0\nNumber(null)      => 0\nNumber(undefined) => NaN`;
