document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй Math.round, Math.floor и Math.ceil для одного и того же числа.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const num = 4.6;
console.log(Math.round(num)); // 5  — ближайшее
console.log(Math.floor(num)); // 4  — вниз
console.log(Math.ceil(num));  // 5  — вверх

const neg = -4.6;
console.log(Math.round(neg)); // -5
console.log(Math.floor(neg)); // -5
console.log(Math.ceil(neg));  // -4`;

document.getElementById('output').textContent = `Math.round(4.6) => 5  (ближайшее целое)\nMath.floor(4.6) => 4  (вниз)\nMath.ceil(4.6)  => 5  (вверх)\nMath.round(-4.6)=> -5\nMath.floor(-4.6)=> -5\nMath.ceil(-4.6) => -4`;
