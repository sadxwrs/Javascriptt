document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как получить случайное целое число от 1 до 10?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

console.log(randomInt(1, 10)); // случайное от 1 до 10
console.log(randomInt(1, 6));  // имитация кубика

for (let i = 0; i < 5; i++) {
  console.log(randomInt(1, 10));
}`;

document.getElementById('output').textContent = `Math.floor(Math.random() * 10) + 1 => 1..10\nФормула: Math.floor(Math.random() * (max - min + 1)) + min\nMath.random() => [0, 1) случайное дробное`;
