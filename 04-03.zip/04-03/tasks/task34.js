document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое NaN? Как проверить, что значение — именно NaN?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `console.log(NaN);            // NaN
console.log(typeof NaN);     // 'number'!
console.log(NaN === NaN);    // false! — NaN не равен себе!

// Правильная проверка:
console.log(isNaN(NaN));           // true
console.log(Number.isNaN(NaN));    // true (строго)
console.log(Number.isNaN('abc'));  // false
console.log(isNaN('abc'));         // true (с приведением типов)`;

document.getElementById('output').textContent = `typeof NaN  => 'number' (NaN — это тип number!)\nNaN === NaN => false (NaN не равен самому себе!)\nisNaN(NaN)          => true\nNumber.isNaN(NaN)   => true\nNumber.isNaN('abc') => false (без приведения)\nisNaN('abc')        => true (с приведением)`;
