document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию isFiniteNumber(value), которая проверяет, что значение — конечное число.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function isFiniteNumber(value) {
  return typeof value === 'number' && Number.isFinite(value);
}

console.log(isFiniteNumber(42));        // true
console.log(isFiniteNumber(3.14));      // true
console.log(isFiniteNumber(Infinity));  // false
console.log(isFiniteNumber(-Infinity)); // false
console.log(isFiniteNumber(NaN));       // false
console.log(isFiniteNumber('42'));      // false (строка!)`;

document.getElementById('output').textContent = `isFiniteNumber(42)        => true\nisFiniteNumber(3.14)      => true\nisFiniteNumber(Infinity)  => false\nisFiniteNumber(-Infinity) => false\nisFiniteNumber(NaN)       => false\nisFiniteNumber('42')      => false (строка)`;
