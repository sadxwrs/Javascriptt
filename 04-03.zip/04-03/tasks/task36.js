document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Покажи разницу между isNaN() и Number.isNaN().<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// isNaN() — сначала приводит к числу, затем проверяет
console.log(isNaN(NaN));       // true
console.log(isNaN('abc'));     // true  ('abc' => NaN)
console.log(isNaN('123'));     // false ('123' => 123)
console.log(isNaN(undefined)); // true  (undefined => NaN)

// Number.isNaN() — строгая проверка, без приведения
console.log(Number.isNaN(NaN));       // true
console.log(Number.isNaN('abc'));     // false
console.log(Number.isNaN(undefined)); // false`;

document.getElementById('output').textContent = `isNaN('abc')            => true  ('abc' => NaN)\nisNaN(undefined)        => true  (undefined => NaN)\nisNaN('123')            => false ('123' => 123)\nNumber.isNaN('abc')     => false (без приведения)\nNumber.isNaN(undefined) => false\nNumber.isNaN(NaN)       => true`;
