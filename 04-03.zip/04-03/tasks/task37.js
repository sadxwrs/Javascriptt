document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию округления числа до двух знаков после запятой.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function round2(num) {
  return Math.round(num * 100) / 100;
}

console.log(round2(3.14159)); // 3.14
console.log(round2(2.005));   // 2.01
console.log(round2(1.555));   // 1.56
console.log(round2(-3.146));  // -3.15

// Альтернатива:
console.log(Number((3.14159).toFixed(2))); // 3.14`;

document.getElementById('output').textContent = `round2(3.14159) => 3.14\nround2(2.005)   => 2.01\nround2(1.555)   => 1.56\nround2(-3.146)  => -3.15\nФормула: Math.round(num * 100) / 100`;
