document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй toString(2), чтобы перевести число в двоичную запись.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `console.log((10).toString(2));   // '1010'
console.log((255).toString(2));  // '11111111'
console.log((7).toString(2));    // '111'

// Другие основания:
console.log((255).toString(16)); // 'ff'  (hex)
console.log((8).toString(8));    // '10'  (octal)

// Обратно:
console.log(parseInt('1010', 2)); // 10`;

document.getElementById('output').textContent = `(10).toString(2)   => '1010'\n(255).toString(2)  => '11111111'\n(7).toString(2)    => '111'\n(255).toString(16) => 'ff' (hex)\n(8).toString(8)    => '10' (octal)\nparseInt('1010',2) => 10`;
