document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое Infinity и -Infinity? Приведи примеры получения.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `console.log(1 / 0);           // Infinity
console.log(-1 / 0);          // -Infinity
console.log(Infinity + 1);    // Infinity
console.log(Infinity * -1);   // -Infinity
console.log(typeof Infinity); // 'number'
console.log(isFinite(Infinity)); // false
console.log(Number.MAX_VALUE * 2); // Infinity`;

document.getElementById('output').textContent = `1 / 0              => Infinity\n-1 / 0             => -Infinity\nInfinity + 1       => Infinity\ntypeof Infinity    => 'number'\nisFinite(Infinity) => false\nNumber.MAX_VALUE * 2 => Infinity`;
