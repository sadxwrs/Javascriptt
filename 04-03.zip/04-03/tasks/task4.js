document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что возвращает typeof undefined и typeof null? Объясни особенность.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `console.log(typeof undefined); // 'undefined'
console.log(typeof null);      // 'object' — это историческая ошибка JS!
// null — это примитив, но typeof возвращает 'object'
// Для проверки null используй:
console.log(null === null); // true`;

document.getElementById('output').textContent = `typeof undefined => 'undefined'\ntypeof null      => 'object' (историческая ошибка!)\nnull === null    => true`;
