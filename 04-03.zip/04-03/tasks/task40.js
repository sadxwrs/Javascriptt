document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию sumDigits(n), которая считает сумму цифр числа.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function sumDigits(n) {
  return String(Math.abs(n))
    .split('')
    .filter(ch => ch !== '.')
    .reduce((sum, ch) => sum + Number(ch), 0);
}

console.log(sumDigits(123));   // 6  (1+2+3)
console.log(sumDigits(9999));  // 36 (9+9+9+9)
console.log(sumDigits(-456));  // 15 (4+5+6)
console.log(sumDigits(0));     // 0`;

document.getElementById('output').textContent = `sumDigits(123)  => 6  (1+2+3)\nsumDigits(9999) => 36 (9*4)\nsumDigits(-456) => 15 (4+5+6)\nsumDigits(0)    => 0\nАлгоритм: перевод в строку, split, sum`;
