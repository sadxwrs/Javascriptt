document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Объясни, почему 9007199254740991 — особое число в JavaScript.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `console.log(Number.MAX_SAFE_INTEGER); // 9007199254740991
// Это 2^53 - 1 — максимальное точно представимое целое

console.log(9007199254740991 + 1);  // 9007199254740992 (верно)
console.log(9007199254740991 + 2);  // 9007199254740992 (ОШИБКА!)

console.log(Number.isSafeInteger(9007199254740991)); // true
console.log(Number.isSafeInteger(9007199254740992)); // false

// Решение для больших чисел:
console.log(9007199254740991n + 2n); // 9007199254740993n (BigInt!)`;

document.getElementById('output').textContent = `Number.MAX_SAFE_INTEGER => 9007199254740991 (2^53 - 1)\n+1 => 9007199254740992 (верно)\n+2 => 9007199254740992 (ОШИБКА — потеря точности!)\nNumber.isSafeInteger(MAX) => true\nРешение: использовать BigInt`;
