document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Покажи, как использовать BigInt в арифметике и почему его нельзя смешивать с number.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `const big = 9007199254740991n;
console.log(big + 1n);  // 9007199254740992n
console.log(big * 2n);  // 18014398509481982n

// Нельзя смешивать с number:
try {
  console.log(big + 1);
} catch (e) {
  console.log(e.message); // Cannot mix BigInt and other types
}

// Явное преобразование:
console.log(big + BigInt(1));   // ok
console.log(Number(big) + 1);   // ok (но теряет точность!)`;

document.getElementById('output').textContent = `9007199254740991n + 1n => 9007199254740992n (точно!)\n9007199254740991n + 1  => TypeError: Cannot mix BigInt and other types\nРешение: big + BigInt(1) или Number(big) + 1`;
