document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй калькулятор, который принимает строку с числами и операцией и обрабатывает ошибки.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function calculate(expression) {
  const match = expression.trim().match(/^(-?[\d.]+)\s*([+\-*/])\s*(-?[\d.]+)$/);
  if (!match) return 'Неверный формат';

  const [, a, op, b] = match;
  const x = Number(a), y = Number(b);

  if (isNaN(x) || isNaN(y)) return 'Не число';
  if (op === '/' && y === 0) return 'Деление на ноль';

  const ops = { '+': x+y, '-': x-y, '*': x*y, '/': x/y };
  return ops[op];
}

console.log(calculate('10 + 5'));  // 15
console.log(calculate('10 / 0')); // 'Деление на ноль'
console.log(calculate('abc'));     // 'Неверный формат'`;

document.getElementById('output').textContent = `calculate('10 + 5')  => 15\ncalculate('3.5 * 2') => 7\ncalculate('10 / 0')  => 'Деление на ноль'\ncalculate('abc + 1') => 'Неверный формат'`;
