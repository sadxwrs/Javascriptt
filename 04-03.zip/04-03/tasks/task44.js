document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Создай строку тремя разными способами.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const str1 = 'Привет';           // одинарные кавычки
const str2 = "Мир";               // двойные кавычки
const str3 = \`Привет, \${str2}!\`;   // шаблонная строка

console.log(str1); // 'Привет'
console.log(str2); // 'Мир'
console.log(str3); // 'Привет, Мир!'

const str4 = String(42);           // через конструктор
console.log(str4); // '42'`;

document.getElementById('output').textContent = `str1 = 'Привет'          (одинарные кавычки)\nstr2 = "Мир"             (двойные кавычки)\nstr3 = `Привет, ${str2}!` (шаблонная строка) => 'Привет, Мир!'\nString(42) => '42'`;
