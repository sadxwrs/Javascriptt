document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое шаблонные строки? Собери фразу с переменными через \`\${...}\`.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const name = 'Анна';
const age = 25;
const city = 'Москва';

const phrase = \`Меня зовут \${name}, мне \${age} лет, я живу в \${city}.\`;
console.log(phrase);

const a = 5, b = 3;
console.log(\`\${a} + \${b} = \${a + b}\`);
// '5 + 3 = 8'

const multi = \`Строка 1
Строка 2\`;
console.log(multi);`;

document.getElementById('output').textContent = `Шаблонные строки — в обратных кавычках, поддерживают ${выражение}\n`Меня зовут ${name}` => 'Меня зовут Анна'\n`${a} + ${b} = ${a+b}` => '5 + 3 = 8'\nПоддерживают многострочность`;
