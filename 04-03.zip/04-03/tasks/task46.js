document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй методы toUpperCase() и toLowerCase().<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const str = 'Hello World';

console.log(str.toUpperCase()); // 'HELLO WORLD'
console.log(str.toLowerCase()); // 'hello world'

// Применение: регистронезависимое сравнение
const input = 'ANNA';
const target = 'anna';
console.log(input.toLowerCase() === target.toLowerCase()); // true`;

document.getElementById('output').textContent = `'Hello World'.toUpperCase() => 'HELLO WORLD'\n'Hello World'.toLowerCase() => 'hello world'\nПрименение: регистронезависимое сравнение\n'ANNA'.toLowerCase() === 'anna' => true`;
