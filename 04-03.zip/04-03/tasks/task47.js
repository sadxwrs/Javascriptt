document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Найди длину строки через свойство length.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `console.log('Hello'.length);   // 5
console.log(''.length);         // 0
console.log('Привет'.length);   // 6
console.log('a b c'.length);    // 5 (пробелы считаются)

// length — свойство, не метод!
const arr = [1, 2, 3];
console.log(arr.length); // 3 (у массивов тоже есть length)`;

document.getElementById('output').textContent = `'Hello'.length  => 5\n''.length       => 0\n'Привет'.length => 6\n'a b c'.length  => 5 (пробелы считаются)\nlength — свойство, не метод`;
