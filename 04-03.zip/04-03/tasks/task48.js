document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Получить первый и последний символ строки.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const str = 'JavaScript';

// Первый:
console.log(str[0]);        // 'J'
console.log(str.charAt(0)); // 'J'
console.log(str.at(0));     // 'J'

// Последний:
console.log(str[str.length - 1]); // 't'
console.log(str.at(-1));          // 't'

// Второй с конца:
console.log(str.at(-2));    // 'p'`;

document.getElementById('output').textContent = `str = 'JavaScript'\nstr[0]            => 'J' (первый)\nstr.charAt(0)      => 'J'\nstr[str.length-1]  => 't' (последний)\nstr.at(-1)         => 't' (современный способ)\nstr.at(-2)         => 'p'`;
