document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Чем отличаются slice(), substring() и substr()? Проверь на примерах.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const str = 'Hello World';

// slice(start, end) — поддерживает отрицательные индексы
console.log(str.slice(0, 5));   // 'Hello'
console.log(str.slice(-5));     // 'World'

// substring(start, end) — отрицательные => 0
console.log(str.substring(0, 5)); // 'Hello'
console.log(str.substring(6));    // 'World'

// substr(start, length) — устарел!
console.log(str.substr(6, 5));    // 'World'`;

document.getElementById('output').textContent = `slice(0,5)      => 'Hello' (поддерживает отрицательные)\nslice(-5)       => 'World'\nsubstring(0,5)  => 'Hello' (отрицательные => 0)\nsubstring(6)    => 'World'\nsubstr(6,5)     => 'World' (2й аргумент — длина, УСТАРЕЛ)`;
