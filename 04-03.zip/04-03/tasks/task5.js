document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Проверь тип значений: [], {}, Symbol('id'), 10n.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `console.log(typeof []);          // 'object'
console.log(typeof {});          // 'object'
console.log(typeof Symbol('id')); // 'symbol'
console.log(typeof 10n);         // 'bigint'
console.log(Array.isArray([]));  // true — проверка на массив`;

document.getElementById('output').textContent = `typeof []           => 'object'\ntypeof {}           => 'object'\ntypeof Symbol('id') => 'symbol'\ntypeof 10n          => 'bigint'\nArray.isArray([])   => true`;
