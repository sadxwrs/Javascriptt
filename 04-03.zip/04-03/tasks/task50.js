document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй includes(), startsWith() и endsWith() для одной строки.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const str = 'Hello, World!';

console.log(str.includes('World'));    // true
console.log(str.includes('world'));    // false (регистр!)
console.log(str.startsWith('Hello')); // true
console.log(str.startsWith('World')); // false
console.log(str.endsWith('!'));        // true
console.log(str.endsWith('World!'));   // true`;

document.getElementById('output').textContent = `str.includes('World')   => true\nstr.includes('world')   => false (регистр важен!)\nstr.startsWith('Hello') => true\nstr.startsWith('World') => false\nstr.endsWith('!')       => true\nstr.endsWith('Hello')   => false`;
