document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию capitalize(str), которая делает первую букву заглавной.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function capitalize(str) {
  if (!str) return str;
  return str[0].toUpperCase() + str.slice(1).toLowerCase();
}

console.log(capitalize('hello'));      // 'Hello'
console.log(capitalize('WORLD'));      // 'World'
console.log(capitalize('javaScript')); // 'Javascript'
console.log(capitalize(''));           // ''
console.log(capitalize('a'));          // 'A'`;

document.getElementById('output').textContent = `capitalize('hello')       => 'Hello'\ncapitalize('WORLD')       => 'World'\ncapitalize('javaScript')  => 'Javascript'\ncapitalize('')            => ''\ncapitalize('a')           => 'A'`;
