document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Разбей строку на массив слов через split() и собери обратно через join().<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const sentence = 'Я изучаю JavaScript';

const words = sentence.split(' ');
console.log(words);        // ['Я', 'изучаю', 'JavaScript']
console.log(words.length); // 3

const joined = words.join(' ');
console.log(joined); // 'Я изучаю JavaScript'

console.log('a,b,c'.split(','));   // ['a','b','c']
console.log(['a','b','c'].join('-')); // 'a-b-c'`;

document.getElementById('output').textContent = `'Я изучаю JavaScript'.split(' ') => ['Я','изучаю','JavaScript']\n['Я','изучаю','JavaScript'].join(' ') => 'Я изучаю JavaScript'\n'a,b,c'.split(',') => ['a','b','c']\n['a','b','c'].join('-') => 'a-b-c'`;
