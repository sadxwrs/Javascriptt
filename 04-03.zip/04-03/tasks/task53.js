document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию, которая считает количество вхождений буквы в строке.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function countChar(str, char) {
  return str.split(char).length - 1;
}

function countChar2(str, char) {
  return [...str].reduce((count, c) => count + (c === char ? 1 : 0), 0);
}

console.log(countChar('hello world', 'l'));  // 3
console.log(countChar('banana', 'a'));       // 3
console.log(countChar('abc', 'z'));          // 0`;

document.getElementById('output').textContent = `countChar('hello world', 'l') => 3\ncountChar('banana', 'a')      => 3\ncountChar('abc', 'z')         => 0\nАлгоритм: str.split(char).length - 1`;
