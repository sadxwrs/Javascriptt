document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Удали лишние пробелы в начале и конце строки, а потом замени двойные пробелы на одинарные.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const messy = '  Hello   World  ';

const trimmed = messy.trim();
console.log(trimmed); // 'Hello   World'

const clean = trimmed.replace(/\s+/g, ' ');
console.log(clean); // 'Hello World'

const result = messy.trim().replace(/\s+/g, ' ');
console.log(result); // 'Hello World'`;

document.getElementById('output').textContent = `'  Hello   World  '.trim()           => 'Hello   World'\n.replace(/\\s+/g, ' ')                => 'Hello World'\nЦепочкой: trim().replace(/\\s+/g,' ') => 'Hello World'`;
