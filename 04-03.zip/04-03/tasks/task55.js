document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй replace() и replaceAll() на одном примере.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const str = 'I like cats. Cats are great. I love cats!';

// replace — только первое вхождение
console.log(str.replace('cats', 'dogs'));
// 'I like dogs. Cats are great. I love cats!'

// replaceAll — все вхождения
console.log(str.replaceAll('cats', 'dogs'));
// 'I like dogs. Cats are great. I love dogs!'

// С regex /gi — все + регистр
console.log(str.replace(/cats/gi, 'dogs'));
// 'I like dogs. dogs are great. I love dogs!'`;

document.getElementById('output').textContent = `replace('cats','dogs')   => заменяет только первое вхождение\nreplaceAll('cats','dogs') => заменяет все (кроме 'Cats' — регистр)\nreplace(/cats/gi,'dogs')  => заменяет все включая 'Cats'`;
