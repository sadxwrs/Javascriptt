document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию проверки палиндрома для строки.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function isPalindrome(str) {
  const clean = str.toLowerCase().replace(/[^a-zA-Za-яёА-ЯЁ0-9]/g, '');
  return clean === clean.split('').reverse().join('');
}

console.log(isPalindrome('racecar'));   // true
console.log(isPalindrome('level'));     // true
console.log(isPalindrome('hello'));     // false
console.log(isPalindrome('A man a plan a canal Panama')); // true
console.log(isPalindrome('12321'));     // true`;

document.getElementById('output').textContent = `isPalindrome('racecar')  => true\nisPalindrome('level')    => true\nisPalindrome('hello')    => false\nisPalindrome('A man a plan a canal Panama') => true\nАлгоритм: очистить => нижний регистр => сравнить с перевёрнутой`;
