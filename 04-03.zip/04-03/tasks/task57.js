document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй функцию camelToKebab(str) для преобразования myVariableName в my-variable-name.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function camelToKebab(str) {
  return str.replace(/([A-Z])/g, (match) => '-' + match.toLowerCase());
}

console.log(camelToKebab('myVariableName'));   // 'my-variable-name'
console.log(camelToKebab('backgroundColor'));  // 'background-color'
console.log(camelToKebab('fontSize'));         // 'font-size'
console.log(camelToKebab('hello'));            // 'hello'`;

document.getElementById('output').textContent = `camelToKebab('myVariableName')  => 'my-variable-name'\ncamelToKebab('backgroundColor') => 'background-color'\ncamelToKebab('fontSize')        => 'font-size'\ncamelToKebab('hello')           => 'hello'`;
