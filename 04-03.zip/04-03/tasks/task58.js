document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию, которая экранирует спецсимволы HTML в строке.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function escapeHTML(str) {
  return str
    .replace(/&/g,  '&amp;')
    .replace(/</g,  '&lt;')
    .replace(/>/g,  '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g,  '&#039;');
}

console.log(escapeHTML('<h1>Hello & "World"</h1>'));
// '&lt;h1&gt;Hello &amp; &quot;World&quot;&lt;/h1&gt;'

console.log(escapeHTML("It's <b>bold</b>"));
// 'It&#039;s &lt;b&gt;bold&lt;/b&gt;'`;

document.getElementById('output').textContent = `& => &amp;   < => &lt;   > => &gt;\n\" => &quot;  ' => &#039;\n'<h1>Hello & \"World\"</h1>' => '&lt;h1&gt;Hello &amp; &quot;World&quot;&lt;/h1&gt;'`;
