document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Сделай мини-парсер строки запроса вида "name=Ivan&age=20" в объект.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function parseQuery(queryString) {
  if (!queryString) return {};
  return queryString
    .split('&')
    .reduce((obj, pair) => {
      const [key, value] = pair.split('=');
      obj[decodeURIComponent(key)] = decodeURIComponent(value || '');
      return obj;
    }, {});
}

console.log(parseQuery('name=Ivan&age=20'));
// { name: 'Ivan', age: '20' }

console.log(parseQuery('x=1&y=2&z=3'));
// { x: '1', y: '2', z: '3' }

console.log(parseQuery(''));
// {}`;

document.getElementById('output').textContent = `parseQuery('name=Ivan&age=20') => { name: 'Ivan', age: '20' }\nparseQuery('x=1&y=2&z=3')      => { x:'1', y:'2', z:'3' }\nparseQuery('')                 => {}\nАлгоритм: split('&') => split('=') => decode`;
