document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию getType(value), которая корректно определяет null отдельно от объекта.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `function getType(value) {
  if (value === null) return 'null';
  if (Array.isArray(value)) return 'array';
  return typeof value;
}

console.log(getType(null));     // 'null'
console.log(getType([]));       // 'array'
console.log(getType({}));       // 'object'
console.log(getType(42));       // 'number'
console.log(getType('hello'));  // 'string'`;

document.getElementById('output').textContent = `getType(null)    => 'null'\ngetType([])      => 'array'\ngetType({})      => 'object'\ngetType(42)      => 'number'\ngetType('hello') => 'string'`;
