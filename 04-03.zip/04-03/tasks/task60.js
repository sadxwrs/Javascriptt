document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Создай массив чисел, строк и смешанный массив.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const numbers = [1, 2, 3, 4, 5];
console.log(numbers);

const fruits = ['яблоко', 'банан', 'вишня'];
console.log(fruits);

const mixed = [42, 'hello', true, null, { x: 1 }, [1, 2]];
console.log(mixed);
console.log(mixed.length); // 6`;

document.getElementById('output').textContent = `numbers = [1,2,3,4,5]\nfruits  = ['яблоко','банан','вишня']\nmixed   = [42,'hello',true,null,{x:1},[1,2]]\nmixed.length => 6\nМассив может содержать значения любых типов`;
