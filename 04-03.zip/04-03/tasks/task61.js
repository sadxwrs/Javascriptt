document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как получить первый, последний и предпоследний элемент массива?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const arr = [10, 20, 30, 40, 50];

console.log(arr[0]);              // 10 (первый)
console.log(arr.at(0));           // 10
console.log(arr[arr.length - 1]); // 50 (последний)
console.log(arr.at(-1));          // 50
console.log(arr[arr.length - 2]); // 40 (предпоследний)
console.log(arr.at(-2));          // 40`;

document.getElementById('output').textContent = `arr = [10,20,30,40,50]\narr[0]            => 10 (первый)\narr[arr.length-1]  => 50 (последний)\narr.at(-1)         => 50 (современный способ)\narr.at(-2)         => 40 (предпоследний)`;
