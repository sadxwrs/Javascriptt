document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что происходит при обращении к несуществующему индексу массива?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const arr = [1, 2, 3];

console.log(arr[0]);  // 1
console.log(arr[2]);  // 3
console.log(arr[3]);  // undefined
console.log(arr[99]); // undefined
console.log(arr[-1]); // undefined (через [] не работает!)
console.log(arr.at(-1)); // 3 (at() поддерживает отрицательные)`;

document.getElementById('output').textContent = `arr = [1,2,3]\narr[0]   => 1\narr[3]   => undefined (нет элемента)\narr[99]  => undefined\narr[-1]  => undefined (через [] отрицательные не работают!)\narr.at(-1) => 3 (at() поддерживает отрицательные)`;
