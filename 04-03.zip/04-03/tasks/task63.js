document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Добавь элементы в конец массива через push() и в начало через unshift().<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const arr = [1, 2, 3];

arr.push(4);
console.log(arr); // [1, 2, 3, 4]

arr.push(5, 6);
console.log(arr); // [1, 2, 3, 4, 5, 6]

arr.unshift(0);
console.log(arr); // [0, 1, 2, 3, 4, 5, 6]

arr.unshift(-2, -1);
console.log(arr); // [-2, -1, 0, 1, 2, 3, 4, 5, 6]`;

document.getElementById('output').textContent = `arr.push(4)       => arr = [1,2,3,4]\narr.push(5,6)     => arr = [1,2,3,4,5,6]\narr.unshift(0)    => arr = [0,1,2,3,4,5,6]\npush/unshift возвращают новую длину массива`;
