document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Удали элементы из конца и начала массива через pop() и shift().<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const arr = [1, 2, 3, 4, 5];

const last = arr.pop();
console.log(last); // 5
console.log(arr);  // [1, 2, 3, 4]

const first = arr.shift();
console.log(first); // 1
console.log(arr);   // [2, 3, 4]`;

document.getElementById('output').textContent = `arr = [1,2,3,4,5]\narr.pop()   => возвращает 5, arr = [1,2,3,4]\narr.shift() => возвращает 1, arr = [2,3,4]\npop/shift мутируют массив и возвращают удалённый элемент`;
