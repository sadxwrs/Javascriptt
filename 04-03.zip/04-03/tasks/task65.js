document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что хранится в свойстве length? Измени его вручную и посмотри на результат.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const arr = [1, 2, 3, 4, 5];
console.log(arr.length); // 5

arr.length = 3;
console.log(arr); // [1, 2, 3] — обрезан!

arr.length = 6;
console.log(arr);    // [1, 2, 3, empty × 3]
console.log(arr[4]); // undefined

arr.length = 0;
console.log(arr); // [] — очищен`;

document.getElementById('output').textContent = `arr = [1,2,3,4,5]; arr.length => 5\narr.length = 3 => arr = [1,2,3] (обрезан!)\narr.length = 6 => [1,2,3, empty*3]\narr.length = 0 => [] (очистить массив)`;
