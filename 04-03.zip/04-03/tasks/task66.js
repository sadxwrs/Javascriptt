document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Создай пустой массив длиной 5 и объясни, чем он отличается от массива [undefined, ...].<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Разреженный массив:
const sparse = new Array(5);
console.log(sparse);        // [empty × 5]
console.log(sparse.length); // 5
console.log(0 in sparse);   // false (слот не существует!)

// Плотный массив с undefined:
const dense = [undefined, undefined, undefined, undefined, undefined];
console.log(0 in dense);    // true

// Разница при переборе:
sparse.forEach(x => console.log(x)); // ничего!
dense.forEach(x => console.log(x));  // undefined × 5`;

document.getElementById('output').textContent = `new Array(5)  => [empty*5] (разреженный)\n[undefined*5] => плотный\n(0 in new Array(5)) => false (слот не существует!)\n(0 in [undefined]) => true\nforEach на разреженном пропускает пустые слоты`;
