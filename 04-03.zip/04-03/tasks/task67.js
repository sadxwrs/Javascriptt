document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Перебери массив тремя способами: for, for...of, forEach().<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const fruits = ['яблоко', 'банан', 'вишня'];

// 1. for
for (let i = 0; i < fruits.length; i++) {
  console.log(\`[\${i}]: \${fruits[i]}\`);
}

// 2. for...of
for (const fruit of fruits) {
  console.log(fruit);
}

// 3. forEach
fruits.forEach((fruit, index) => {
  console.log(\`\${index}: \${fruit}\`);
});`;

document.getElementById('output').textContent = `for: даёт индекс, поддерживает break\nfor...of: перебирает значения, поддерживает break\nforEach: нельзя break, callback(значение, индекс, массив)\nВсе три вывели: яблоко, банан, вишня`;
