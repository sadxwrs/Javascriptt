document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию, которая разворачивает массив без использования reverse().<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function reverseArray(arr) {
  const result = [];
  for (let i = arr.length - 1; i >= 0; i--) {
    result.push(arr[i]);
  }
  return result;
}

function reverseReduce(arr) {
  return arr.reduce((acc, val) => [val, ...acc], []);
}

console.log(reverseArray([1, 2, 3, 4, 5]));   // [5,4,3,2,1]
console.log(reverseReduce(['a', 'b', 'c']));  // ['c','b','a']`;

document.getElementById('output').textContent = `reverseArray([1,2,3,4,5])   => [5,4,3,2,1]\nreverseReduce(['a','b','c']) => ['c','b','a']\nАлгоритм 1: цикл от конца\nАлгоритм 2: reduce с [val, ...acc]`;
