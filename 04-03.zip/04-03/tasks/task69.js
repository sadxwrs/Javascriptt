document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Объедини два массива через concat() и через spread.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const a = [1, 2, 3];
const b = [4, 5, 6];

const result1 = a.concat(b);
console.log(result1); // [1,2,3,4,5,6]

const result2 = [...a, ...b];
console.log(result2); // [1,2,3,4,5,6]

// spread гибче:
const result3 = [...a, 99, ...b, 100];
console.log(result3); // [1,2,3,99,4,5,6,100]

console.log([].concat(a, b, [7, 8])); // [1,2,3,4,5,6,7,8]`;

document.getElementById('output').textContent = `a.concat(b)    => [1,2,3,4,5,6]\n[...a,...b]    => [1,2,3,4,5,6]\n[...a,99,...b] => [1,2,3,99,4,5,6] (spread гибче)\nОба не мутируют исходные массивы`;
