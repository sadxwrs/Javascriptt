document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое BigInt? Приведи пример создания большого целого числа.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// BigInt — тип для целых чисел любой длины
const big1 = 9007199254740991n; // через литерал n
const big2 = BigInt('12345678901234567890');

console.log(big1);          // 9007199254740991n
console.log(big2);          // 12345678901234567890n
console.log(typeof big1);   // 'bigint'
console.log(big1 + 1n);     // 9007199254740992n`;

document.getElementById('output').textContent = `BigInt — целые числа любой длины\nbig1 = 9007199254740991n\nbig2 = BigInt('12345678901234567890')\ntypeof big1 => 'bigint'\nbig1 + 1n   => 9007199254740992n`;
