document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Скопируй массив разными способами и проверь, что копия не равна исходнику по ссылке.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const original = [1, 2, 3];

const copy1 = [...original];        // spread
const copy2 = original.slice();     // slice
const copy3 = Array.from(original); // Array.from
const copy4 = [].concat(original);  // concat

console.log(copy1 === original); // false — разные ссылки!
copy1.push(99);
console.log(original); // [1, 2, 3] — не изменился
console.log(copy1);    // [1, 2, 3, 99]`;

document.getElementById('output').textContent = `[...original] === original    => false (разные ссылки)\noriginal.slice() === original  => false\nArray.from() === original      => false\n[].concat() === original       => false\nВсе 4 способа создают мелкую копию`;
