document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Найди индекс элемента через indexOf() и includes().<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const arr = [10, 20, 30, 20, 40];

console.log(arr.indexOf(20));     // 1 (первое вхождение)
console.log(arr.indexOf(20, 2));  // 3 (поиск с индекса 2)
console.log(arr.indexOf(99));     // -1 (не найден)

console.log(arr.includes(20));    // true
console.log(arr.includes(99));    // false

// includes лучше для NaN:
const arr2 = [1, NaN, 3];
console.log(arr2.indexOf(NaN));   // -1 (не находит NaN!)
console.log(arr2.includes(NaN));  // true (находит!)`;

document.getElementById('output').textContent = `arr.indexOf(20)    => 1 (первое вхождение)\narr.indexOf(20, 2) => 3 (поиск с индекса 2)\narr.indexOf(99)    => -1 (не найден)\narr.includes(20)   => true\narr.includes(NaN)  => true\narr.indexOf(NaN)   => -1 (не находит NaN!)`;
