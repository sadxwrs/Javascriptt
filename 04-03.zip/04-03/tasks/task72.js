document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй slice() и splice() и объясни разницу.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const arr = [1, 2, 3, 4, 5];

// slice — не мутирует, возвращает новый массив
const sliced = arr.slice(1, 3);
console.log(sliced); // [2, 3]
console.log(arr);    // [1, 2, 3, 4, 5] — не изменился!

// splice — мутирует, удаляет/добавляет элементы
const removed = arr.splice(1, 2, 99, 100);
console.log(removed); // [2, 3] — удалённые элементы
console.log(arr);     // [1, 99, 100, 4, 5] — изменён!`;

document.getElementById('output').textContent = `slice(1,3)  => [2,3], НЕ мутирует исходный массив\nsplice(1,2,99,100) => удаляет [2,3], вставляет 99,100\narr после splice => [1,99,100,4,5] (мутирован!)\nslice — для чтения, splice — для изменения`;
