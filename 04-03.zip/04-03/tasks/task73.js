document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию unique(arr), которая удаляет дубликаты без использования Set.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function unique(arr) {
  return arr.filter((item, index) => arr.indexOf(item) === index);
}

// Альтернатива через reduce:
function unique2(arr) {
  return arr.reduce((acc, item) => {
    if (!acc.includes(item)) acc.push(item);
    return acc;
  }, []);
}

console.log(unique([1, 2, 2, 3, 1, 4])); // [1, 2, 3, 4]
console.log(unique(['a', 'b', 'a', 'c'])); // ['a', 'b', 'c']
console.log(unique([1, 1, 1])); // [1]`;

document.getElementById('output').textContent = `unique([1,2,2,3,1,4])      => [1,2,3,4]\nunique(['a','b','a','c'])   => ['a','b','c']\nunique([1,1,1])             => [1]\nАлгоритм: filter + indexOf (оставить только первое вхождение)`;
