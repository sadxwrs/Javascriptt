document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй функцию chunk(arr, size), разбивающую массив на части.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function chunk(arr, size) {
  const result = [];
  for (let i = 0; i < arr.length; i += size) {
    result.push(arr.slice(i, i + size));
  }
  return result;
}

console.log(chunk([1,2,3,4,5,6], 2)); // [[1,2],[3,4],[5,6]]
console.log(chunk([1,2,3,4,5], 2));   // [[1,2],[3,4],[5]]
console.log(chunk([1,2,3], 5));       // [[1,2,3]]
console.log(chunk([], 3));            // []`;

document.getElementById('output').textContent = `chunk([1,2,3,4,5,6], 2) => [[1,2],[3,4],[5,6]]\nchunk([1,2,3,4,5], 2)   => [[1,2],[3,4],[5]]\nchunk([1,2,3], 5)       => [[1,2,3]]\nchunk([], 3)            => []`;
