document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию flattenOneLevel(arr), которая разворачивает массив только на один уровень.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function flattenOneLevel(arr) {
  return arr.reduce((acc, item) => {
    return acc.concat(Array.isArray(item) ? item : [item]);
  }, []);
}

// Или через spread:
function flattenOneLevel2(arr) {
  return [].concat(...arr);
}

console.log(flattenOneLevel([1, [2, 3], [4, [5, 6]]]));
// [1, 2, 3, 4, [5, 6]] — только один уровень!

console.log(flattenOneLevel([[1,2], [3,4], [5]]));
// [1, 2, 3, 4, 5]`;

document.getElementById('output').textContent = `flattenOneLevel([1,[2,3],[4,[5,6]]]) => [1,2,3,4,[5,6]] (один уровень!)\nflattenOneLevel([[1,2],[3,4],[5]])    => [1,2,3,4,5]\nАналог встроенного: arr.flat(1)`;
