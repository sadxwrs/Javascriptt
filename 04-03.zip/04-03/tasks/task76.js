document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй forEach(), чтобы вывести каждый элемент массива.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const fruits = ['яблоко', 'банан', 'вишня'];

fruits.forEach((fruit, index) => {
  console.log(\`\${index}: \${fruit}\`);
});

// forEach не возвращает значение!
const result = fruits.forEach(f => f.toUpperCase());
console.log(result); // undefined`;

document.getElementById('output').textContent = `fruits.forEach((f, i) => console.log(i + ': ' + f))\n0: яблоко\n1: банан\n2: вишня\nforEach возвращает undefined (не используй для создания нового массива)`;
