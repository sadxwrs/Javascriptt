document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй map(), чтобы получить массив квадратов чисел.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const numbers = [1, 2, 3, 4, 5];

const squares = numbers.map(n => n * n);
console.log(squares); // [1, 4, 9, 16, 25]

// map не мутирует исходный массив:
console.log(numbers); // [1, 2, 3, 4, 5]

// С индексом:
const withIndex = numbers.map((n, i) => \`\${i}:\${n}\`);
console.log(withIndex); // ['0:1','1:2','2:3','3:4','4:5']`;

document.getElementById('output').textContent = `numbers.map(n => n*n) => [1,4,9,16,25]\nmap не мутирует исходный массив!\nmap возвращает новый массив той же длины`;
