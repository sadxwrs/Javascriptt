document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй filter(), чтобы оставить только чётные числа.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

const evens = numbers.filter(n => n % 2 === 0);
console.log(evens); // [2, 4, 6, 8, 10]

const odds = numbers.filter(n => n % 2 !== 0);
console.log(odds);  // [1, 3, 5, 7, 9]

// filter не мутирует исходный массив:
console.log(numbers.length); // 10`;

document.getElementById('output').textContent = `numbers.filter(n => n%2===0) => [2,4,6,8,10]\nnumbers.filter(n => n%2!==0) => [1,3,5,7,9]\nfilter не мутирует исходный массив\nfilter возвращает новый массив (может быть меньше)`;
