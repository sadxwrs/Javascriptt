document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй reduce(), чтобы посчитать сумму элементов.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const numbers = [1, 2, 3, 4, 5];

const sum = numbers.reduce((acc, n) => acc + n, 0);
console.log(sum); // 15

// Без начального значения:
const sum2 = numbers.reduce((acc, n) => acc + n);
console.log(sum2); // 15

// Произведение:
const product = numbers.reduce((acc, n) => acc * n, 1);
console.log(product); // 120`;

document.getElementById('output').textContent = `numbers.reduce((acc, n) => acc + n, 0) => 15\nreduce(fn, 0): acc=0, затем 0+1=1, 1+2=3, 3+3=6, 6+4=10, 10+5=15\nПроизведение: numbers.reduce((acc,n)=>acc*n, 1) => 120`;
