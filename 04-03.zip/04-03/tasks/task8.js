document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши код, который проверяет: является ли значение массивом, объектом, функцией или примитивом.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function classify(val) {
  if (val === null) return 'null (primitive)';
  if (Array.isArray(val)) return 'array';
  if (typeof val === 'function') return 'function';
  if (typeof val === 'object') return 'object';
  return \`primitive (\${typeof val})\`;
}

console.log(classify([]));           // 'array'
console.log(classify({}));           // 'object'
console.log(classify(() => {}));     // 'function'
console.log(classify(42));           // 'primitive (number)'
console.log(classify(null));         // 'null (primitive)'`;

document.getElementById('output').textContent = `classify([])       => 'array'\nclassify({})       => 'object'\nclassify(()=>{})   => 'function'\nclassify(42)       => 'primitive (number)'\nclassify(null)     => 'null (primitive)'`;
