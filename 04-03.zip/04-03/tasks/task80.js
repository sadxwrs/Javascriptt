document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Чем отличаются find() и filter()?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const users = [
  { id: 1, name: 'Анна' },
  { id: 2, name: 'Борис' },
  { id: 3, name: 'Анна' },
];

// find — возвращает ПЕРВЫЙ подходящий элемент (или undefined)
const found = users.find(u => u.name === 'Анна');
console.log(found); // { id: 1, name: 'Анна' }

// filter — возвращает ВСЕ подходящие элементы (массив)
const filtered = users.filter(u => u.name === 'Анна');
console.log(filtered); // [{ id:1 }, { id:3 }]

console.log(users.find(u => u.name === 'Нет')); // undefined
console.log(users.filter(u => u.name === 'Нет')); // []`;

document.getElementById('output').textContent = `find:   возвращает ПЕРВЫЙ подходящий элемент или undefined\nfilter: возвращает МАССИВ всех подходящих элементов\nusers.find(u => u.name==='Анна')   => { id:1, name:'Анна' }\nusers.filter(u => u.name==='Анна') => [{ id:1 }, { id:3 }]`;
