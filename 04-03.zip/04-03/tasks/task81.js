document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй some() и every() на одном массиве.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const numbers = [2, 4, 6, 7, 10];

// some — true, если ХОТЯ БЫ ОДИН элемент подходит
console.log(numbers.some(n => n % 2 !== 0)); // true (7 нечётное)
console.log(numbers.some(n => n > 100));      // false

// every — true, если ВСЕ элементы подходят
console.log(numbers.every(n => n > 0));       // true
console.log(numbers.every(n => n % 2 === 0)); // false (7 нечётное)`;

document.getElementById('output').textContent = `some:  true если хотя бы ОДИН элемент подходит\nevery: true если ВСЕ элементы подходят\nnumbers.some(n => n%2!==0)  => true (7 нечётное)\nnumbers.some(n => n>100)    => false\nnumbers.every(n => n>0)     => true\nnumbers.every(n => n%2===0) => false (7 нечётное)`;
