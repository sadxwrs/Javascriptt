document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Отсортируй массив строк по алфавиту через sort().<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const fruits = ['банан', 'яблоко', 'абрикос', 'вишня'];

const sorted = [...fruits].sort();
console.log(sorted); // ['абрикос', 'банан', 'вишня', 'яблоко']

// По убыванию:
const desc = [...fruits].sort((a, b) => b.localeCompare(a));
console.log(desc); // ['яблоко', 'вишня', 'банан', 'абрикос']

// sort мутирует исходный массив!
const arr = ['c', 'a', 'b'];
arr.sort();
console.log(arr); // ['a', 'b', 'c']`;

document.getElementById('output').textContent = `['банан','яблоко','абрикос','вишня'].sort()\n=> ['абрикос','банан','вишня','яблоко']\nПо убыванию: sort((a,b)=>b.localeCompare(a))\n=> ['яблоко','вишня','банан','абрикос']\nВажно: sort МУТИРУЕТ исходный массив!`;
