document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Почему для сортировки чисел нужно передавать колбэк в sort()?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Без колбэка — сортировка как строки!
const nums = [10, 9, 2, 100, 21];
console.log([...nums].sort());
// [10, 100, 2, 21, 9] — НЕВЕРНО! (лексикографически)

// С колбэком — правильная числовая сортировка:
console.log([...nums].sort((a, b) => a - b));
// [2, 9, 10, 21, 100] — верно, по возрастанию

console.log([...nums].sort((a, b) => b - a));
// [100, 21, 10, 9, 2] — по убыванию

// Логика: если (a - b) < 0 => a идёт раньше`;

document.getElementById('output').textContent = `Без колбэка: [10,9,2,100,21].sort() => [10,100,2,21,9] НЕВЕРНО!\nПричина: числа сравниваются как строки ('100' < '2'!)\nС колбэком: .sort((a,b)=>a-b) => [2,9,10,21,100] ВЕРНО\nЛогика: (a-b)<0 => a раньше b`;
