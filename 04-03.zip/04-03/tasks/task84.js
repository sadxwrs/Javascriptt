document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши сортировку массива чисел по возрастанию и по убыванию.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const numbers = [5, 2, 8, 1, 9, 3, 7, 4, 6];

const asc = [...numbers].sort((a, b) => a - b);
console.log(asc);
// [1, 2, 3, 4, 5, 6, 7, 8, 9]

const desc = [...numbers].sort((a, b) => b - a);
console.log(desc);
// [9, 8, 7, 6, 5, 4, 3, 2, 1]

console.log(numbers); // [5,2,8,1,9,3,7,4,6] — не изменился`;

document.getElementById('output').textContent = `[5,2,8,1,9,3,7,4,6].sort((a,b)=>a-b) => [1,2,3,4,5,6,7,8,9]\n[5,2,8,1,9,3,7,4,6].sort((a,b)=>b-a) => [9,8,7,6,5,4,3,2,1]\nИсходный массив не изменён (используем spread-копию)`;
