document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй reduce(), чтобы собрать объект-частотность элементов массива.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const fruits = ['яблоко', 'банан', 'яблоко', 'вишня', 'банан', 'яблоко'];

const freq = fruits.reduce((acc, item) => {
  acc[item] = (acc[item] || 0) + 1;
  return acc;
}, {});

console.log(freq);
// { яблоко: 3, банан: 2, вишня: 1 }`;

document.getElementById('output').textContent = `fruits.reduce((acc,item) => { acc[item]=(acc[item]||0)+1; return acc; }, {})\n=> { яблоко: 3, банан: 2, вишня: 1 }\nAcc начинается с {}, каждый элемент увеличивает счётчик`;
