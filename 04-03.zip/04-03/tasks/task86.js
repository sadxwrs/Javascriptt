document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> С помощью map() преобразуй массив строк в массив объектов.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const names = ['Анна', 'Борис', 'Вера'];

const users = names.map((name, index) => ({
  id: index + 1,
  name: name,
  email: \`\${name.toLowerCase()}@example.com\`
}));

console.log(users);
// [
//   { id:1, name:'Анна',  email:'анна@example.com' },
//   { id:2, name:'Борис', email:'борис@example.com' },
//   { id:3, name:'Вера',  email:'вера@example.com'  }
// ]`;

document.getElementById('output').textContent = `['Анна','Борис','Вера'].map((name,i) => ({id:i+1, name, email:...}))\n=> [{id:1,name:'Анна',...}, {id:2,name:'Борис',...}, {id:3,...}]\nmap идеален для трансформации каждого элемента`;
