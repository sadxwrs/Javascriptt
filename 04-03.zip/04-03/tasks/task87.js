document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй flat() и flatMap() на небольших примерах.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// flat — разворачивает вложенные массивы
const nested = [1, [2, 3], [4, [5, 6]]];
console.log(nested.flat());    // [1,2,3,4,[5,6]]
console.log(nested.flat(2));   // [1,2,3,4,5,6]
console.log(nested.flat(Infinity)); // [1,2,3,4,5,6]

// flatMap — map + flat(1)
const sentences = ['Привет мир', 'Как дела'];
const words = sentences.flatMap(s => s.split(' '));
console.log(words); // ['Привет','мир','Как','дела']`;

document.getElementById('output').textContent = `nested.flat()         => [1,2,3,4,[5,6]] (1 уровень)\nnested.flat(2)        => [1,2,3,4,5,6]\nnested.flat(Infinity) => [1,2,3,4,5,6]\nflatMap = map + flat(1)\n['Привет мир','Как дела'].flatMap(s=>s.split(' ')) => ['Привет','мир','Как','дела']`;
