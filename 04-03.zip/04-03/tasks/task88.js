document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши цепочку методов массива: фильтрация, преобразование, сортировка.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const products = [
  { name: 'Ноутбук', price: 50000, inStock: true },
  { name: 'Мышь',   price: 1500,  inStock: false },
  { name: 'Клава',  price: 3000,  inStock: true },
  { name: 'Монитор',price: 30000, inStock: true },
];

const result = products
  .filter(p => p.inStock)             // только в наличии
  .map(p => ({ name: p.name, price: p.price })) // нужные поля
  .sort((a, b) => a.price - b.price); // по цене

console.log(result);
// [{name:'Клава',price:3000}, {name:'Монитор',price:30000}, {name:'Ноутбук',price:50000}]`;

document.getElementById('output').textContent = `filter(inStock) => 3 товара\nmap(name,price) => убрать лишние поля\nsort(price)     => по возрастанию цены\nРезультат: Клава 3000, Монитор 30000, Ноутбук 50000`;
