document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй fill(), чтобы создать массив из одинаковых значений.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Массив из нулей:
const zeros = new Array(5).fill(0);
console.log(zeros); // [0, 0, 0, 0, 0]

// Заполнить часть массива:
const arr = [1, 2, 3, 4, 5];
arr.fill(99, 1, 4);
console.log(arr); // [1, 99, 99, 99, 5]

// Массив строк:
const greeting = new Array(3).fill('Привет');
console.log(greeting); // ['Привет','Привет','Привет']`;

document.getElementById('output').textContent = `new Array(5).fill(0)    => [0,0,0,0,0]\n[1,2,3,4,5].fill(99,1,4) => [1,99,99,99,5]\nnew Array(3).fill('Привет') => ['Привет','Привет','Привет']\nfill(значение, start, end)`;
