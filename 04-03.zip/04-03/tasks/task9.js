document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Объясни разницу между typeof и instanceof на примере массива.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const arr = [1, 2, 3];

console.log(typeof arr);            // 'object' — не различает!
console.log(arr instanceof Array);  // true
console.log(arr instanceof Object); // true (массив — это объект)

const obj = {};
console.log(typeof obj);            // 'object'
console.log(obj instanceof Array);  // false`;

document.getElementById('output').textContent = `typeof [1,2,3]             => 'object'\n[1,2,3] instanceof Array   => true\n[1,2,3] instanceof Object  => true\n{} instanceof Array        => false\nВывод: typeof не различает массив и объект`;
