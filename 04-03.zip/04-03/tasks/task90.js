document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Создай массив через Array.from() из строки и из объекта с length.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Из строки:
const chars = Array.from('hello');
console.log(chars); // ['h','e','l','l','o']

// Из объекта с length:
const arr = Array.from({ length: 5 }, (_, i) => i + 1);
console.log(arr); // [1, 2, 3, 4, 5]

// Из Set:
const set = new Set([1, 2, 3]);
console.log(Array.from(set)); // [1, 2, 3]

// Квадраты:
const squares = Array.from({ length: 5 }, (_, i) => (i+1) ** 2);
console.log(squares); // [1, 4, 9, 16, 25]`;

document.getElementById('output').textContent = `Array.from('hello')                     => ['h','e','l','l','o']\nArray.from({length:5}, (_,i)=>i+1)      => [1,2,3,4,5]\nArray.from(new Set([1,2,3]))            => [1,2,3]\nArray.from({length:5}, (_,i)=>(i+1)**2) => [1,4,9,16,25]`;
