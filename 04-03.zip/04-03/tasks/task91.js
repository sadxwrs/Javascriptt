document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Преобразуй массив пар вида [['a',1],['b',2]] в объект и обратно.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Массив пар => объект:
const pairs = [['a', 1], ['b', 2], ['c', 3]];
const obj = Object.fromEntries(pairs);
console.log(obj); // { a:1, b:2, c:3 }

// Объект => массив пар:
const back = Object.entries(obj);
console.log(back); // [['a',1],['b',2],['c',3]]

// Или через Map:
const map = new Map(pairs);
console.log(map.get('b')); // 2
console.log([...map.entries()]); // [['a',1],['b',2],['c',3]]`;

document.getElementById('output').textContent = `Object.fromEntries([['a',1],['b',2]]) => { a:1, b:2 }\nObject.entries({ a:1, b:2 })          => [['a',1],['b',2]]\nnew Map([['a',1],['b',2]]).get('a')   => 1`;
