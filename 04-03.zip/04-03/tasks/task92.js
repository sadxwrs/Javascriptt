document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй собственный аналог метода map() под названием myMap().<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function myMap(arr, callback) {
  const result = [];
  for (let i = 0; i < arr.length; i++) {
    result.push(callback(arr[i], i, arr));
  }
  return result;
}

// Тесты:
console.log(myMap([1,2,3], n => n * 2));     // [2,4,6]
console.log(myMap([1,2,3], (n,i) => \`\${i}:\${n}\`)); // ['0:1','1:2','2:3']
console.log(myMap(['a','b'], s => s.toUpperCase())); // ['A','B']`;

document.getElementById('output').textContent = `myMap([1,2,3], n=>n*2)           => [2,4,6]\nmyMap([1,2,3], (n,i)=>i+':'+n)   => ['0:1','1:2','2:3']\nmyMap(['a','b'], s=>s.toUpperCase()) => ['A','B']\nCallback получает: (элемент, индекс, массив)`;
