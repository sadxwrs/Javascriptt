document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй собственный аналог метода filter() под названием myFilter().<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function myFilter(arr, callback) {
  const result = [];
  for (let i = 0; i < arr.length; i++) {
    if (callback(arr[i], i, arr)) {
      result.push(arr[i]);
    }
  }
  return result;
}

console.log(myFilter([1,2,3,4,5], n => n % 2 === 0)); // [2,4]
console.log(myFilter(['a','bb','ccc'], s => s.length > 1)); // ['bb','ccc']
console.log(myFilter([1,2,3], n => n > 10)); // []`;

document.getElementById('output').textContent = `myFilter([1,2,3,4,5], n=>n%2===0)       => [2,4]\nmyFilter(['a','bb','ccc'], s=>s.length>1) => ['bb','ccc']\nmyFilter([1,2,3], n=>n>10)              => []\nCallback получает: (элемент, индекс, массив)`;
