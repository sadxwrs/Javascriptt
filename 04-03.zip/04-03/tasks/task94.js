document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй собственный аналог метода reduce() под названием myReduce().<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function myReduce(arr, callback, initialValue) {
  let acc = initialValue !== undefined ? initialValue : arr[0];
  const start = initialValue !== undefined ? 0 : 1;
  for (let i = start; i < arr.length; i++) {
    acc = callback(acc, arr[i], i, arr);
  }
  return acc;
}

console.log(myReduce([1,2,3,4,5], (acc,n) => acc+n, 0)); // 15
console.log(myReduce([1,2,3,4,5], (acc,n) => acc*n, 1)); // 120
console.log(myReduce([1,2,3], (acc,n) => acc+n));        // 6`;

document.getElementById('output').textContent = `myReduce([1,2,3,4,5], (acc,n)=>acc+n, 0) => 15\nmyReduce([1,2,3,4,5], (acc,n)=>acc*n, 1) => 120\nmyReduce([1,2,3], (acc,n)=>acc+n)         => 6 (без начального)\nCallback: (аккумулятор, элемент, индекс, массив)`;
