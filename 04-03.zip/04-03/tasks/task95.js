document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию, которая группирует элементы массива через reduce().<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function groupBy(arr, keyFn) {
  return arr.reduce((groups, item) => {
    const key = keyFn(item);
    if (!groups[key]) groups[key] = [];
    groups[key].push(item);
    return groups;
  }, {});
}

const people = [
  { name: 'Анна',  age: 25 },
  { name: 'Борис', age: 30 },
  { name: 'Вера',  age: 25 },
  { name: 'Глеб',  age: 30 },
];

console.log(groupBy(people, p => p.age));
// { 25: [{Анна},{Вера}], 30: [{Борис},{Глеб}] }`;

document.getElementById('output').textContent = `groupBy(people, p=>p.age)\n=> { 25: [{name:'Анна',age:25},{name:'Вера',age:25}],\n     30: [{name:'Борис',age:30},{name:'Глеб',age:30}] }\nreduce собирает объект с массивами по ключу`;
