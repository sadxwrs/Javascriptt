document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое итерируемый объект в JavaScript?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Итерируемый объект — объект, реализующий Symbol.iterator
// Это позволяет использовать for...of

// Встроенные итерируемые:
for (const ch of 'abc') console.log(ch);    // a, b, c
for (const n of [1,2,3]) console.log(n);    // 1, 2, 3
for (const n of new Set([1,2])) console.log(n); // 1, 2

// Ручное использование итератора:
const iter = [1,2,3][Symbol.iterator]();
console.log(iter.next()); // {value:1, done:false}
console.log(iter.next()); // {value:2, done:false}
console.log(iter.next()); // {value:3, done:false}
console.log(iter.next()); // {value:undefined, done:true}`;

document.getElementById('output').textContent = `Итерируемый — реализует Symbol.iterator, можно использовать for...of\niter.next() => { value: 1, done: false }\niter.next() => { value: 2, done: false }\nПоследний: { value: undefined, done: true }\nВстроенные: Array, String, Set, Map, arguments...`;
