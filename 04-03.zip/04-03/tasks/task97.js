document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Какие встроенные структуры являются итерируемыми? Приведи минимум 5 примеров.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// 1. Массив:
for (const n of [1,2,3]) console.log(n);

// 2. Строка:
for (const ch of 'ab') console.log(ch);

// 3. Set:
for (const n of new Set([1,2])) console.log(n);

// 4. Map:
for (const [k,v] of new Map([['a',1]])) console.log(k,v);

// 5. arguments (в функции):
function test() { for (const a of arguments) console.log(a); }
test(1, 2, 3);

// 6. NodeList (в браузере)
// 7. TypedArray
// 8. Генераторы`;

document.getElementById('output').textContent = `Итерируемые объекты:\n1. Array\n2. String\n3. Set\n4. Map\n5. arguments\n6. NodeList (браузер)\n7. TypedArray\n8. Генераторы (function*)\nНЕ итерируемые: обычный объект {}, number, boolean`;
