document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Используй for...of для строки, массива и Set.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Строка:
for (const ch of 'Привет') {
  process.stdout.write(ch + ' ');
}
// П р и в е т

// Массив:
for (const n of [10, 20, 30]) {
  console.log(n);
}
// 10, 20, 30

// Set:
const set = new Set([1, 2, 2, 3, 3]);
for (const n of set) {
  console.log(n);
}
// 1, 2, 3 (без дубликатов)`;

document.getElementById('output').textContent = `for (const ch of 'Привет') => П р и в е т\nfor (const n of [10,20,30]) => 10, 20, 30\nfor (const n of new Set([1,2,2,3])) => 1, 2, 3 (без дублей)\nfor...of работает с любым итерируемым объектом`;
