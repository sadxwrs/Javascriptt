document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что делает метод Symbol.iterator?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Symbol.iterator — это метод, который возвращает итератор

const arr = [1, 2, 3];
const iter = arr[Symbol.iterator](); // создаём итератор

console.log(iter.next()); // {value:1, done:false}
console.log(iter.next()); // {value:2, done:false}
console.log(iter.next()); // {value:3, done:false}
console.log(iter.next()); // {value:undefined, done:true}

// for...of автоматически вызывает Symbol.iterator
for (const n of arr) console.log(n); // 1, 2, 3`;

document.getElementById('output').textContent = `Symbol.iterator — метод, возвращающий итератор\nИтератор имеет метод next(), возвращающий {value, done}\narr[Symbol.iterator]().next() => {value:1, done:false}\nfor...of автоматически вызывает Symbol.iterator`;
