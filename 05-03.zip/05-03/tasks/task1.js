document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши цикл <code>for</code> который выводит числа от 1 до 10.`;

document.getElementById('solutionCode').textContent = `for (let i = 1; i <= 10; i++) {\n  console.log(i);\n}`;

let output = '';
for (let i = 1; i <= 10; i++) {
  output += i + '\n';
}
document.getElementById('output').textContent = output;