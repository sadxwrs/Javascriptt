document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что такое "fall-through" уязвимость в безопасности? Пример бага.`;
document.getElementById('solutionCode').textContent = `case "admin":\n  // забыли break!\ncase "user":\n  grantAccess(); // админ получил права пользователя? Нет — наоборот!`;
document.getElementById('output').innerHTML = `<strong>Опасность:</strong> забытый break даёт лишние права<br>Всегда явно ставь break или комментируй intentional fallthrough`;
