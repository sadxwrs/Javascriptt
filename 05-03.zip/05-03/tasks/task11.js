document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши цикл <code>for...of</code> для перебора массива <code>[10, 20, 30, 40]</code>.`;
document.getElementById('solutionCode').textContent = `const arr = [10, 20, 30, 40];\nfor (const val of arr) {\n  console.log(val);\n}`;
let output = '';
const arr = [10, 20, 30, 40];
for (const val of arr) output += val + ' ';
document.getElementById('output').textContent = output;