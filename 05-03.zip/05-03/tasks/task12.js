document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши цикл <code>for...in</code> для перебора ключей объекта <code>{a:1, b:2, c:3}</code>.`;
document.getElementById('solutionCode').textContent = `const obj = {a:1, b:2, c:3};\nfor (const key in obj) {\n  console.log(key, obj[key]);\n}`;
let output = '';
const obj = {a:1, b:2, c:3};
for (const key in obj) output += `${key}: ${obj[key]}\n`;
document.getElementById('output').textContent = output;