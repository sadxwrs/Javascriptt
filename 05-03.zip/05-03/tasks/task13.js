document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Чем <code>for...of</code> отличается от <code>for...in</code>?`;
document.getElementById('solutionCode').innerHTML = `for...of — перебирает ЗНАЧЕНИЯ\nfor...in — перебирает КЛЮЧИ`;
document.getElementById('output').innerHTML = `for...of → значения (массивы, строки)\nfor...in → ключи/индексы (объекты)`;