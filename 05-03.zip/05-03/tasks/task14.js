document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши цикл который считает количество гласных в строке "hello world".`;
document.getElementById('solutionCode').textContent = `let count = 0;\nconst str = "hello world";\nfor (const ch of str) {\n  if ("aeiou".includes(ch)) count++;\n}`;
let count = 0;
const str = "hello world";
for (const ch of str) if ("aeiou".includes(ch)) count++;
document.getElementById('output').textContent = `Гласных: ${count} (e, o, o)`;