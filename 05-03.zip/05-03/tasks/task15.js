document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши цикл умножающий все элементы массива [1,2,3,4,5] (произведение).`;
document.getElementById('solutionCode').textContent = `let prod = 1;\nconst arr = [1,2,3,4,5];\nfor (const n of arr) prod *= n;`;
let prod = 1;
const arr15 = [1,2,3,4,5];
for (const n of arr15) prod *= n;
document.getElementById('output').textContent = `Произведение = ${prod}`;