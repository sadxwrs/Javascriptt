document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши цикл который создаёт массив квадратов чисел от 1 до 10.`;
document.getElementById('solutionCode').textContent = `const res = [];\nfor (let i = 1; i <= 10; i++) res.push(i * i);`;
const res = [];
for (let i = 1; i <= 10; i++) res.push(i * i);
document.getElementById('output').textContent = JSON.stringify(res);