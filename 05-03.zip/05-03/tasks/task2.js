document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши цикл <code>while</code> который выводит числа от 1 до 10.`;

document.getElementById('solutionCode').textContent = `let i = 1;\nwhile (i <= 10) {\n  console.log(i);\n  i++;\n}`;

let output = '';
let i = 1;
while (i <= 10) {
  output += i + '\n';
  i++;
}
document.getElementById('output').textContent = output;