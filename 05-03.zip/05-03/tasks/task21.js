document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши цикл который разворачивает строку (reverse string) без использования .reverse().`;
document.getElementById('solutionCode').textContent = `let str = "hello";\nlet res = "";\nfor (let i = str.length - 1; i >= 0; i--) res += str[i];`;
let str = "hello";
let res = "";
for (let i = str.length - 1; i >= 0; i--) res += str[i];
document.getElementById('output').textContent = res;