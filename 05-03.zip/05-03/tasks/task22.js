document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Найди максимальный элемент массива используя цикл (без Math.max).`;
document.getElementById('solutionCode').textContent = `const arr = [5, 12, 3, 8, 21, 7];\nlet max = arr[0];\nfor (const x of arr) if (x > max) max = x;`;
const arr22 = [5,12,3,8,21,7];
let max = arr22[0];
for (const x of arr22) if (x > max) max = x;
document.getElementById('output').textContent = 'Максимум = ' + max;