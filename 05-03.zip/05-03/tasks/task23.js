document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши цикл который удаляет дубликаты из массива без использования Set.`;
document.getElementById('solutionCode').textContent = `const arr = [1,2,2,3,4,4,5];\nconst res = [];\nfor (const x of arr) {\n  if (!res.includes(x)) res.push(x);\n}`;
const arr23 = [1,2,2,3,4,4,5];
const res23 = [];
for (const x of arr23) if (!res23.includes(x)) res23.push(x);
document.getElementById('output').textContent = JSON.stringify(res23);