document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй <code>flatten(arr)</code> для одного уровня вложенности через цикл.`;
document.getElementById('solutionCode').textContent = `const arr = [1, [2,3], 4, [5]];\nconst res = [];\nfor (const item of arr) {\n  if (Array.isArray(item)) res.push(...item);\n  else res.push(item);\n}`;
const arr26 = [1,[2,3],4,[5]];
const res26 = [];
for (const item of arr26) Array.isArray(item) ? res26.push(...item) : res26.push(item);
document.getElementById('output').textContent = JSON.stringify(res26);