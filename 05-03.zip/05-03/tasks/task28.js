document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши цикл для двоичного поиска (binary search) в отсортированном массиве.`;
document.getElementById('solutionCode').textContent = `const arr = [1,3,5,7,9,11,13];\nlet left = 0, right = arr.length-1, target = 7;`;
document.getElementById('output').textContent = 'Найден индекс 3 (число 7)';