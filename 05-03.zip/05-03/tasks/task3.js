document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что такое <code>do...while</code>? Чем он отличается от <code>while</code>?`;

document.getElementById('solutionCode').innerHTML = `// do...while выполняется минимум 1 раз, даже если условие сразу false\ndo {\n  console.log("Выполнится хотя бы раз!");\n} while (false);`;

document.getElementById('output').innerHTML = `<strong>Отличие от while:</strong><br>• while — проверяет условие <b>перед</b> телом<br>• do...while — проверяет условие <b>после</b> тела`;