document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй функцию <code>zip(a, b)</code> через цикл — объединяет два массива попарно.`;
document.getElementById('solutionCode').textContent = `function zip(a, b) {\n  const res = [];\n  for (let i = 0; i < Math.min(a.length, b.length); i++) {\n    res.push([a[i], b[i]]);\n  }\n  return res;\n}`;
document.getElementById('output').textContent = JSON.stringify(zip([1,2,3],[10,20,30]));
