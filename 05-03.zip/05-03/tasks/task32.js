document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши цикл для построения треугольника из звёздочек (5 строк).`;
document.getElementById('solutionCode').textContent = `for (let i = 1; i <= 5; i++) {\n  console.log("*".repeat(i));\n}`;
document.getElementById('output').innerHTML = `*<br>**<br>***<br>****<br>*****<br><strong>(выведено в консоль)</strong>`;
