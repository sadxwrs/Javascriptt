document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй алгоритм пузырьковой сортировки (bubble sort) через вложенные циклы.`;
document.getElementById('solutionCode').textContent = `function bubbleSort(arr) {\n  for (let i = 0; i < arr.length; i++) {\n    for (let j = 0; j < arr.length - i - 1; j++) {\n      if (arr[j] > arr[j+1]) [arr[j], arr[j+1]] = [arr[j+1], arr[j]];\n    }\n  }\n  return arr;\n}`;
document.getElementById('output').textContent = JSON.stringify([5,3,8,4,2].sort((a,b)=>a-b));
