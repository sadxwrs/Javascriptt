document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй алгоритм сортировки вставками (insertion sort).`;
document.getElementById('solutionCode').textContent = `function insertionSort(arr) {\n  for (let i = 1; i < arr.length; i++) {\n    let key = arr[i];\n    let j = i - 1;\n    while (j >= 0 && arr[j] > key) {\n      arr[j+1] = arr[j];\n      j--;\n    }\n    arr[j+1] = key;\n  }\n  return arr;\n}`;
document.getElementById('output').textContent = '[3,1,4,2] → [1,2,3,4]';
