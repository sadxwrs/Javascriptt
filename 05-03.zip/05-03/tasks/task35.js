document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши итеративную версию fibonacci(n).`;
document.getElementById('solutionCode').textContent = `function fib(n) {\n  let a = 0, b = 1;\n  for (let i = 0; i < n; i++) [a, b] = [b, a + b];\n  return a;\n}`;
document.getElementById('output').textContent = 'fib(10) = 55';
