document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй функцию flatten(arr, depth) без рекурсии (через стек).`;
document.getElementById('solutionCode').textContent = `function flatten(arr, depth = 1) {\n  const stack = [...arr];\n  const res = [];\n  while (stack.length) {\n    const item = stack.pop();\n    if (Array.isArray(item) && depth > 0) stack.push(...item);\n    else res.unshift(item);\n  }\n  return res;\n}`;
document.getElementById('output').textContent = '[1,[2,[3]]] → [1,2,3]';
