document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши генератор простых чисел до N (решето Эратосфена).`;
document.getElementById('solutionCode').textContent = `function sieve(n) {\n  const isPrime = Array(n+1).fill(true);\n  isPrime[0] = isPrime[1] = false;\n  for (let i = 2; i * i <= n; i++) {\n    if (isPrime[i]) for (let j = i*i; j <= n; j += i) isPrime[j] = false;\n  }\n  return Array.from({length:n+1}, (_,i)=>i).filter(i=>isPrime[i]);\n}`;
document.getElementById('output').textContent = 'Простые до 20: 2,3,5,7,11,13,17,19';
