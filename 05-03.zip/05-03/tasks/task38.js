document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй функцию chunk(arr, size) — разбивает массив на подмассивы.`;
document.getElementById('solutionCode').textContent = `function chunk(arr, size) {\n  const res = [];\n  for (let i = 0; i < arr.length; i += size) {\n    res.push(arr.slice(i, i + size));\n  }\n  return res;\n}`;
document.getElementById('output').textContent = 'chunk([1,2,3,4,5], 2) = [[1,2],[3,4],[5]]';
