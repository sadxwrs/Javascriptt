document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Итеративный BFS — обход дерева в ширину через очередь.`;
document.getElementById('solutionCode').textContent = `const tree = {val:1, children:[{val:2},{val:3}]};\nconst queue = [tree];\nconst res = [];\nwhile (queue.length) {\n  const node = queue.shift();\n  res.push(node.val);\n  if (node.children) queue.push(...node.children);\n}`;
document.getElementById('output').textContent = 'Обход: 1,2,3';
