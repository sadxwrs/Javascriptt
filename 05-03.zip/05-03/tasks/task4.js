document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши <code>do...while</code> который просит ввод пока не введут число больше 10.`;

document.getElementById('solutionCode').textContent = `let num;\ndo {\n  num = parseInt(prompt("Введи число > 10"));\n} while (num <= 10);\nconsole.log("Отлично!", num);`;

document.getElementById('output').innerHTML = `<em>Нажми кнопку в браузере — появится окно prompt</em><br><strong>Цикл завершится только когда введёшь число больше 10.</strong>`;