document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй groupBy(arr, fn) — группирует элементы по ключу.`;
document.getElementById('solutionCode').textContent = `function groupBy(arr, fn) {\n  const acc = {};\n  for (const x of arr) {\n    const key = fn(x);\n    (acc[key] ??= []).push(x);\n  }\n  return acc;\n}`;
document.getElementById('output').textContent = '{even: [2,4], odd: [1,3]}';
