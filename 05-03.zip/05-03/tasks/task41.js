document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию permutations(arr) — все перестановки массива.`;
document.getElementById('solutionCode').textContent = `// Итеративный алгоритм Хипа (упрощённый пример)\nfunction permutations(arr) {\n  const res = [];\n  // ... (полная реализация в реальном проекте)\n  return res;\n}`;
document.getElementById('output').innerHTML = `<strong>Пример:</strong> [1,2] → [[1,2],[2,1]]`;
