document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Ленивый итератор бесконечной последовательности Фибоначчи через генератор.`;
document.getElementById('solutionCode').textContent = `function* fib() {\n  let [a, b] = [0, 1];\n  while (true) {\n    yield a;\n    [a, b] = [b, a + b];\n  }\n}`;
document.getElementById('output').innerHTML = `for (let i of fib()) { if (i > 100) break; console.log(i); }`;
