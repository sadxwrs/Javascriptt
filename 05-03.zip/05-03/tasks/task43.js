document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Самая длинная подстрока без повторяющихся символов (sliding window).`;
document.getElementById('solutionCode').textContent = `function longestSubstring(s) {\n  let left = 0, max = 0;\n  const set = new Set();\n  for (let right = 0; right < s.length; right++) {\n    while (set.has(s[right])) set.delete(s[left++]);\n    set.add(s[right]);\n    max = Math.max(max, right - left + 1);\n  }\n  return max;\n}`;
document.getElementById('output').textContent = '"abcabcbb" → 3';
