document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Матричное умножение через вложенные циклы.`;
document.getElementById('solutionCode').textContent = `function matrixMultiply(A, B) {\n  const C = Array(A.length).fill(0).map(()=>Array(B[0].length).fill(0));\n  for (let i = 0; i < A.length; i++)\n    for (let j = 0; j < B[0].length; j++)\n      for (let k = 0; k < B.length; k++) C[i][j] += A[i][k] * B[k][j];\n  return C;\n}`;
document.getElementById('output').textContent = 'Результат в консоли';
