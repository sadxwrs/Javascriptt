document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй throttle(fn, delay) через замыкание и Date.now().`;
document.getElementById('solutionCode').textContent = `function throttle(fn, delay) {\n  let last = 0;\n  return (...args) => {\n    if (Date.now() - last >= delay) {\n      last = Date.now();\n      fn(...args);\n    }\n  };\n}`;
document.getElementById('output').textContent = 'throttle готова';
