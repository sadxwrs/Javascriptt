document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>takeWhile и dropWhile через циклы.`;
document.getElementById('solutionCode').textContent = `function takeWhile(arr, pred) {\n  const res = [];\n  for (const x of arr) {\n    if (!pred(x)) break;\n    res.push(x);\n  }\n  return res;\n}`;
document.getElementById('output').textContent = 'takeWhile([1,2,3,4], x=>x<3) = [1,2]';
