document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Итеративный DFS для графа через стек.`;
document.getElementById('solutionCode').textContent = `function dfs(graph, start) {\n  const stack = [start];\n  const visited = new Set();\n  while (stack.length) {\n    const v = stack.pop();\n    if (!visited.has(v)) {\n      visited.add(v);\n      stack.push(...(graph[v] || []));\n    }\n  }\n  return visited;\n}`;
document.getElementById('output').textContent = 'DFS завершён';
