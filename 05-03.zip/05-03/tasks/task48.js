document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>slidingWindowMax(arr, k) — максимум в каждом окне размера k.`;
document.getElementById('solutionCode').textContent = `// Простая O(n*k) реализация\nfunction slidingWindowMax(arr, k) {\n  const res = [];\n  for (let i = 0; i <= arr.length - k; i++) {\n    res.push(Math.max(...arr.slice(i, i+k)));\n  }\n  return res;\n}`;
document.getElementById('output').textContent = '[1,3,-1,-3,5,3,6,7] k=3 → [3,3,5,5,6,7]';
