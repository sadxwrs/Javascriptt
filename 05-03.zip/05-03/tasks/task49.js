document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Two Sum — два элемента с суммой target (O(n) с Map).`;
document.getElementById('solutionCode').textContent = `function twoSum(arr, target) {\n  const map = new Map();\n  for (let i = 0; i < arr.length; i++) {\n    const comp = target - arr[i];\n    if (map.has(comp)) return [map.get(comp), i];\n    map.set(arr[i], i);\n  }\n}`;
document.getElementById('output').textContent = '[2,7,11,15] target=9 → [0,1]';
