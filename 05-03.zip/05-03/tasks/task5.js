document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что такое оператор <code>break</code>? Напиши цикл который останавливается на числе 5.`;

document.getElementById('solutionCode').textContent = `for (let i = 1; i <= 10; i++) {\n  console.log(i);\n  if (i === 5) break;\n}`;

let output = '';
for (let i = 1; i <= 10; i++) {
  output += i + '\n';
  if (i === 5) {
    output += '← break! Цикл остановлен\n';
    break;
  }
}
document.getElementById('output').textContent = output;