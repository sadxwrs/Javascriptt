document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что такое оптимизация хвостовых вызовов? Как переписать рекурсию в цикл.`;
document.getElementById('solutionCode').innerHTML = `// Пример: факториал\nfunction factorial(n, acc = 1) {\n  if (n <= 1) return acc;\n  return factorial(n-1, acc * n); // TCO\n}\n// → while-версия`;
document.getElementById('output').innerHTML = `<strong>Рекурсия превращена в цикл</strong>`;
