document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй memoize(fn) с Map-кэшем.`;
document.getElementById('solutionCode').textContent = `function memoize(fn) {\n  const cache = new Map();\n  return (...args) => {\n    const key = JSON.stringify(args);\n    if (cache.has(key)) return cache.get(key);\n    const res = fn(...args);\n    cache.set(key, res);\n    return res;\n  };\n}`;
document.getElementById('output').textContent = 'memoize готова';
