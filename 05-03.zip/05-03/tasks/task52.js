document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Генератор range через function* и for...of.`;
document.getElementById('solutionCode').textContent = `function* range(start, end, step = 1) {\n  for (let i = start; i <= end; i += step) yield i;\n}`;
document.getElementById('output').textContent = '0 2 4 6 8 10';
