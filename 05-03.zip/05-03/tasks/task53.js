document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши switch который выводит название дня недели по числу от 1 до 7.`;
document.getElementById('solutionCode').textContent = `function dayName(d) {\n  switch(d) {\n    case 1: return "Понедельник";\n    case 2: return "Вторник";\n    // ... остальные дни\n    default: return "Неверный день";\n  }\n}`;
document.getElementById('output').textContent = 'dayName(3) = Среда';
