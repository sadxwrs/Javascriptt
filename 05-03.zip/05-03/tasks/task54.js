document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что произойдёт если забыть break? Пример fallthrough.`;
document.getElementById('solutionCode').textContent = `switch(1) {\n  case 1:\n  case 2: console.log("1 или 2"); break;\n}`;
document.getElementById('output').textContent = 'Fallthrough сработал';
