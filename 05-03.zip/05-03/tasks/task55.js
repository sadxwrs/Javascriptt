document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Как работает default в switch? Обязателен ли он?`;
document.getElementById('solutionCode').textContent = `switch(val) {\n  case 1: ... \n  default: console.log("Не совпало");\n}`;
document.getElementById('output').textContent = 'default = как else';
