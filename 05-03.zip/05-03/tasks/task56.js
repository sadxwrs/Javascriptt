document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Конвертация оценки: A→Отлично, B→Хорошо и т.д.`;
document.getElementById('solutionCode').textContent = `switch(grade) {\n  case "A": return "Отлично";\n  case "B": return "Хорошо";\n  // ...\n}`;
document.getElementById('output').textContent = 'A = Отлично';
