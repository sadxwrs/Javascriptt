document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Выходные — суббота и воскресенье (намеренный fallthrough).`;
document.getElementById('solutionCode').textContent = `case "Суббота":\ncase "Воскресенье": return "Выходной";`;
document.getElementById('output').textContent = 'Суббота = Выходной';
