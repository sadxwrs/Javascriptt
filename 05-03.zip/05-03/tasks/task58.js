document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>switch для команд: "start", "stop", "pause".`;
document.getElementById('solutionCode').textContent = `switch(cmd) {\n  case "start": console.log("Запуск"); break;\n  // ...\n}`;
document.getElementById('output').textContent = 'Команда обработана';
