document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Чем switch лучше длинной цепочки if-else?`;
document.getElementById('solutionCode').innerHTML = `switch — читаемее и быстрее при многих проверках одной переменной`;
document.getElementById('output').innerHTML = `<strong>Когда использовать:</strong> много равных сравнений`;
