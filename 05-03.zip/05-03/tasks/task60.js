document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Время суток: 0-5→Ночь, 6-11→Утро и т.д. (switch(true)).`;
document.getElementById('solutionCode').textContent = `switch(true) {\n  case h < 6: return "Ночь";\n  case h < 12: return "Утро";\n  // ...\n}`;
document.getElementById('output').textContent = '12:00 = День';
