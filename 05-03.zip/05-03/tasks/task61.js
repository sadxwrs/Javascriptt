document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Можно ли в switch использовать <code>return</code> вместо <code>break</code>? В чём разница?`;
document.getElementById('solutionCode').textContent = `function getDay(d) {\n  switch(d) {\n    case 1: return "Понедельник";\n    case 2: return "Вторник";\n    default: return "Неверный день";\n  }\n}`;
document.getElementById('output').innerHTML = `<strong>return</strong> — выходит из всей функции<br><strong>break</strong> — только из switch`;
