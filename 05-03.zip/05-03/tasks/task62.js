document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши switch принимающий тип фигуры ("circle","square","triangle") и возвращающий количество углов.`;
document.getElementById('solutionCode').textContent = `switch(shape) {\n  case "circle": return 0;\n  case "square": return 4;\n  case "triangle": return 3;\n  default: return "Неизвестно";\n}`;
document.getElementById('output').textContent = 'circle → 0 углов';
