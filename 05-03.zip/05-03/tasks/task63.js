document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что вернёт switch если переменная undefined и нет default?`;
document.getElementById('solutionCode').textContent = `let x = undefined;\nswitch(x) {\n  case 1: return "один";\n}`;
document.getElementById('output').innerHTML = `Ничего не выполнится.<br>Switch просто завершится без результата.`;
