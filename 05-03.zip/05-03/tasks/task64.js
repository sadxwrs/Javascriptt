document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши switch для HTTP-статусов: 200→OK, 404→Not Found, 500→Server Error.`;
document.getElementById('solutionCode').textContent = `switch(status) {\n  case 200: return "OK";\n  case 404: return "Not Found";\n  case 500: return "Server Error";\n  default: return "Unknown";\n}`;
document.getElementById('output').textContent = '404 → Not Found';
