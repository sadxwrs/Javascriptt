document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Как switch сравнивает значения — через == или ===?`;
document.getElementById('solutionCode').textContent = `switch("1") {\n  case 1: return "совпадёт только при ==="; // НЕ совпадёт!\n}`;
document.getElementById('output').innerHTML = `<strong>Всегда строгое ===</strong><br>"1" !== 1`;
