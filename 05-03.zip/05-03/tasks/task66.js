document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши switch-калькулятор: operator (+,-,*,/) и два числа.`;
document.getElementById('solutionCode').textContent = `switch(op) {\n  case "+": return a + b;\n  case "-": return a - b;\n  case "*": return a * b;\n  case "/": return a / b;\n}`;
document.getElementById('output').textContent = '5 + 3 = 8';
