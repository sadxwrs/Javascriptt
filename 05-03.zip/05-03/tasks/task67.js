document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Можно ли вложить switch внутрь switch?`;
document.getElementById('solutionCode').textContent = `switch(main) {\n  case "A":\n    switch(sub) {\n      case 1: return "A1";\n    }\n}`;
document.getElementById('output').innerHTML = `Да, вложенные switch работают нормально.`;
