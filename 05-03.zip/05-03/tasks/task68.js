document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши switch который реагирует на нажатие клавиши ArrowUp, ArrowDown и т.д.`;
document.getElementById('solutionCode').textContent = `switch(event.key) {\n  case "ArrowUp": moveUp(); break;\n  case "ArrowDown": moveDown(); break;\n}`;
document.getElementById('output').textContent = 'Клавиша обработана';
