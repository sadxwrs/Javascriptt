document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Перепиши функцию с длинной цепочкой if-else-if на switch.`;
document.getElementById('solutionCode').textContent = `switch(true) {\n  case score >= 90: return "A";\n  case score >= 80: return "B";\n}`;
document.getElementById('output').textContent = 'switch(true) — удобный способ для диапазонов';
