document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши цикл <code>for</code> в обратном порядке от 10 до 1.`;
document.getElementById('solutionCode').textContent = `for (let i = 10; i >= 1; i--) {\n  console.log(i);\n}`;
let output = '';
for (let i = 10; i >= 1; i--) output += i + '\n';
document.getElementById('output').textContent = output;