document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй switch-диспетчер для простого командного интерпретатора (REPL).`;
document.getElementById('solutionCode').textContent = `switch(command) {\n  case "help": printHelp(); break;\n  case "exit": process.exit(); break;\n}`;
document.getElementById('output').textContent = 'Команда выполнена';
