document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что такое паттерн "switch с объектом" (object lookup)?`;
document.getElementById('solutionCode').textContent = `const actions = {\n  add: (a,b)=>a+b,\n  sub: (a,b)=>a-b\n};\nreturn (actions[op] ?? defaultFn)(a,b);`;
document.getElementById('output').textContent = 'Объект быстрее и чище switch при большом количестве случаев';
