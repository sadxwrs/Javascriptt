document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши switch для конечного автомата светофора: red→green→yellow→red.`;
document.getElementById('solutionCode').textContent = `switch(state) {\n  case "red": return "green";\n  case "green": return "yellow";\n  case "yellow": return "red";\n}`;
document.getElementById('output').textContent = 'Светофор переключён';
