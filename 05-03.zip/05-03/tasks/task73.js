document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй switch для парсинга токенов: NUMBER, STRING, OPERATOR.`;
document.getElementById('solutionCode').textContent = `switch(token.type) {\n  case "NUMBER": parseNumber(token); break;\n  case "STRING": parseString(token); break;\n}`;
document.getElementById('output').textContent = 'Токен обработан';
