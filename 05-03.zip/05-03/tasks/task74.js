document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй switch для роутинга URL: "/", "/about", "/contact".`;
document.getElementById('solutionCode').textContent = `switch(path) {\n  case "/": renderHome(); break;\n  case "/about": renderAbout(); break;\n  default: render404();\n}`;
document.getElementById('output').textContent = 'Страница отрисована';
