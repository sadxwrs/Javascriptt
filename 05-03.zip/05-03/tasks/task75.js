document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Можно ли в case использовать диапазоны? Реализуй с помощью switch(true).`;
document.getElementById('solutionCode').textContent = `switch(true) {\n  case score >= 90: return "A";\n  case score >= 80: return "B";\n}`;
document.getElementById('output').textContent = 'Диапазоны работают через switch(true)';
