document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши switch с несколькими case без break (intentional fallthrough).`;
document.getElementById('solutionCode').textContent = `case "admin":\ncase "superadmin": grantFullAccess(); break;`;
document.getElementById('output').textContent = 'Админ + супер-админ получили доступ';
