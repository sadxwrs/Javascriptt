document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй switch для форматирования числа: 1→"1st", 2→"2nd", 3→"3rd".`;
document.getElementById('solutionCode').textContent = `switch(n) {\n  case 1: return n+"st";\n  case 2: return n+"nd";\n  case 3: return n+"rd";\n  default: return n+"th";\n}`;
document.getElementById('output').textContent = '1 → 1st,  4 → 4th';
