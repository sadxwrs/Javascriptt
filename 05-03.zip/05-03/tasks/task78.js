document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши switch для конвертации нотации нот: "C"→До, "D"→Ре и т.д.`;
document.getElementById('solutionCode').textContent = `switch(note) {\n  case "C": return "До";\n  case "D": return "Ре";\n  case "E": return "Ми";\n}`;
document.getElementById('output').textContent = 'C → До';
