document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что происходит с переменными объявленными внутри case?`;
document.getElementById('solutionCode').innerHTML = `case 1: {\n  let x = 10; // нужны {}\n  console.log(x);\n  break;\n}`;
document.getElementById('output').innerHTML = `<strong>Без {} переменные "протекают" в другие case!</strong>`;
