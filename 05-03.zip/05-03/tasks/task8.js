document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Вычисли сумму чисел от 1 до 100 с помощью цикла.`;
document.getElementById('solutionCode').textContent = `let sum = 0;\nfor (let i = 1; i <= 100; i++) sum += i;\nconsole.log(sum);`;
let sum = 0;
for (let i = 1; i <= 100; i++) sum += i;
document.getElementById('output').textContent = 'Сумма = ' + sum;