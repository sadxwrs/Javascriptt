document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши switch-обработчик событий DOM: click, mouseover, keydown.`;
document.getElementById('solutionCode').textContent = `switch(event.type) {\n  case "click": handleClick(); break;\n  case "keydown": handleKey(); break;\n}`;
document.getElementById('output').textContent = 'Событие обработано';
