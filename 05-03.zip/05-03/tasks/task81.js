document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй функцию getAnimalSound(animal) используя switch.`;
document.getElementById('solutionCode').textContent = `switch(animal) {\n  case "cat": return "meow";\n  case "dog": return "woof";\n  default: return "????";\n}`;
document.getElementById('output').textContent = 'cat → meow';
