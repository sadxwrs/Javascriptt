document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши switch для определения знака зодиака по месяцу и дню.`;
document.getElementById('solutionCode').textContent = `switch(month) {\n  case 1: return day <= 20 ? "Козерог" : "Водолей";\n  // ... другие месяцы\n}`;
document.getElementById('output').textContent = '15 января → Козерог';
