document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Можно ли вернуть значение из switch напрямую? Покажи два подхода.`;
document.getElementById('solutionCode').innerHTML = `// 1. return внутри функции\n// 2. IIFE:\nconst res = (() => {\n  switch(val) { ... }\n})();`;
document.getElementById('output').textContent = 'Оба способа работают';
