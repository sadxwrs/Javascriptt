document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что такое "exhaustive switch"? Как убедиться, что все случаи обработаны?`;
document.getElementById('solutionCode').textContent = `default: throw new Error("Unhandled value: " + val);`;
document.getElementById('output').innerHTML = `<strong>Защита от новых значений</strong>`;
