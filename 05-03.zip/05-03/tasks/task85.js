document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй паттерн "State Machine" через switch.`;
document.getElementById('solutionCode').textContent = `switch(this.state) {\n  case "idle": this.state = "loading"; break;\n  case "loading": this.state = "success"; break;\n}`;
document.getElementById('output').textContent = 'Состояние изменено';
