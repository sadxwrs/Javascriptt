document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сравни производительность switch vs if-else vs object lookup.`;
document.getElementById('solutionCode').innerHTML = `switch — JIT → jump table (самый быстрый при многих case)\nobject lookup — O(1) hash\nif-else — O(n)`;
document.getElementById('output').innerHTML = `<strong>switch обычно быстрее всех</strong>`;
