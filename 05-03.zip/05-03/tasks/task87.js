document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй интерпретатор простого стекового языка (RPN калькулятор) через switch.`;
document.getElementById('solutionCode').textContent = `switch(token) {\n  case "+": stack.push(stack.pop() + stack.pop()); break;\n  case "NUM": stack.push(number); break;\n}`;
document.getElementById('output').textContent = '2 3 + → 5';
