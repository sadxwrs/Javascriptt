document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши switch-based event bus.`;
document.getElementById('solutionCode').textContent = `switch(event) {\n  case "user:login": loginHandlers.forEach(h => h(data)); break;\n}`;
document.getElementById('output').textContent = 'Событие разослано';
