document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй AST-интерпретатор через switch по типу узла.`;
document.getElementById('solutionCode').textContent = `switch(node.type) {\n  case "BinaryExpression": return eval(node.left) + eval(node.right);\n}`;
document.getElementById('output').textContent = 'AST обработан';
