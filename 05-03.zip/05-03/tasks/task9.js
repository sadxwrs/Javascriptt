document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши цикл который выводит только нечётные числа от 1 до 20.`;
document.getElementById('solutionCode').textContent = `for (let i = 1; i <= 20; i += 2) {\n  console.log(i);\n}`;
let output = '';
for (let i = 1; i <= 20; i += 2) output += i + ' ';
document.getElementById('output').textContent = output;