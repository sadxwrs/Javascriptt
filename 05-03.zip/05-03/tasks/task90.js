document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Как использовать Symbol как case в switch?`;
document.getElementById('solutionCode').textContent = `const TYPE = Symbol("type");\nswitch(val) {\n  case TYPE: return "symbol case";\n}`;
document.getElementById('output').textContent = 'Symbol работает (строгое ===)';
