document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй паттерн "Command" через switch.`;
document.getElementById('solutionCode').textContent = `const handlers = { add: AddCommand };\nswitch(type) {\n  case "add": handlers.add.execute(); break;\n}`;
document.getElementById('output').textContent = 'Команда выполнена';
