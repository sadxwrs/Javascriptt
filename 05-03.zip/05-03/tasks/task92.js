document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши middleware-цепочку где тип запроса определяется через switch.`;
document.getElementById('solutionCode').textContent = `switch(req.method) {\n  case "GET": return getMiddleware(req, res, next);\n}`;
document.getElementById('output').textContent = 'Middleware запущен';
