document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что такое Tagged Union? Реализуй обработку через switch.`;
document.getElementById('solutionCode').textContent = `switch(shape.kind) {\n  case "circle": return Math.PI * shape.r ** 2;\n  case "rect": return shape.w * shape.h;\n}`;
document.getElementById('output').textContent = 'Tagged Union обработан';
