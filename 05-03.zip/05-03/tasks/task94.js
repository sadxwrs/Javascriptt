document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй Turing-машину через switch.`;
document.getElementById('solutionCode').textContent = `while(!halted) {\n  switch(state + "_" + tape[head]) {\n    case "q0_0": state = "q1"; tape[head] = "1"; head++; break;\n  }\n}`;
document.getElementById('output').textContent = 'Turing-машина работает';
