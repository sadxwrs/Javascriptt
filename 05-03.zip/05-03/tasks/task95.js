document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши switch для парсера простых выражений (токены).`;
document.getElementById('solutionCode').textContent = `switch(char) {\n  case "+": case "-": tokens.push({type:"op", val:char}); break;\n}`;
document.getElementById('output').textContent = 'Токены распарсены';
