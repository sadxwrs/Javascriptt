document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй паттерн "Visitor" используя switch для обхода AST.`;
document.getElementById('solutionCode').textContent = `visit(node) {\n  switch(node.type) {\n    case "Literal": return visitLiteral(node);\n  }\n}`;
document.getElementById('output').textContent = 'Visitor прошёл по узлам';
