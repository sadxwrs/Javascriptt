document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Как сделать switch "type-safe" в чистом JS?`;
document.getElementById('solutionCode').textContent = `default: throw new TypeError(\`Unexpected: \${val}\`);`;
document.getElementById('output').textContent = 'Ошибка при неизвестном значении';
