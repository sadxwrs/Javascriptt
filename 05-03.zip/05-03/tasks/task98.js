document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй конечный автомат для парсинга JSON вручную через switch.`;
document.getElementById('solutionCode').textContent = `switch(state) {\n  case "START": if(char === "{") state = "OBJECT"; break;\n}`;
document.getElementById('output').textContent = 'JSON парсер запущен';
