document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши switch-based Redux-подобный reducer.`;
document.getElementById('solutionCode').textContent = `function reducer(state, action) {\n  switch(action.type) {\n    case "ADD": return [...state, action.payload];\n    case "RESET": return [];\n  }\n}`;
document.getElementById('output').textContent = 'Состояние обновлено';
