document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое DevTools? Как открыть вкладку Sources в Chrome?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Открытие DevTools в Chrome:
// F12 или Ctrl+Shift+I (Cmd+Option+I на Mac)
// Для вкладки Sources: нажать F12, затем перейти на вкладку "Sources"

console.log("DevTools открыт!");
// В DevTools -> Sources можно видеть исходный код страницы,
// ставить breakpoints и отлаживать JavaScript код`;

document.getElementById('output').textContent = `DevTools — инструменты разработчика Chrome. Открыть: F12 или Ctrl+Shift+I. Вкладка Sources — для отладки JS.`;
