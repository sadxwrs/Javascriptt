document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как использовать <code>console.table()</code> для удобного вывода массива объектов?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Logpoint — breakpoint который логирует без остановки кода
// Правый клик на строку -> "Add logpoint"
// Вписать: "i =", i, "сумма:", total  (как шаблон)

// Аналог в коде: добавить console.log без debugger
function processItems(items) {
  let total = 0;
  for (let i = 0; i < items.length; i++) {
    total += items[i];
    // Logpoint на строке выше: 'i=' + i + ' total=' + total
    console.log('i=', i, 'total=', total); // что делает logpoint
  }
  return total;
}

console.log(processItems([5, 3, 8, 2]));`;

document.getElementById('output').textContent = `Logpoint = breakpoint без паузы, только с логом. Правый клик → Add logpoint. Не останавливает выполнение.`;
