document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое logpoint в DevTools? Чем он лучше временного <code>console.log</code>?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Отладка async/await в DevTools:
// Включить 'Async' в панели Call Stack (чекбокс)

async function fetchData(url) {
  debugger; // DevTools покажет весь async call stack
  const response = await fetch(url);
  const data = await response.json();
  return data;
}

async function main() {
  const result = await fetchData('https://jsonplaceholder.typicode.com/todos/1');
  console.log(result);
}

main();
// С включённым Async Call Stack видно полную цепочку промисов`;

document.getElementById('output').textContent = `Для async: включить 'Async' в Call Stack. DevTools покажет всю цепочку промисов и awaits.`;
