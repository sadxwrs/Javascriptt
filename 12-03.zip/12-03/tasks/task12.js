document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как отлаживать асинхронный код (async/await) в DevTools? Где смотреть асинхронный стек?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Blackboxing — исключает библиотеки из отладки (DevTools не заходит внутрь)
// Settings -> Ignore List -> Add pattern: /node_modules/
// Или правый клик на файл библиотеки -> "Add to ignore list"

// Без blackboxing при Step Into в библиотечный код:
import _ from 'lodash'; // DevTools зашёл бы внутрь lodash

function myCode() {
  debugger;
  const result = _.sum([1, 2, 3]); // Step Into без blackbox = код lodash
  return result; // Step Into с blackbox = пропустит lodash
}

myCode();
// Blackbox экономит время — не нужно шагать по библиотечному коду`;

document.getElementById('output').textContent = `Blackboxing (Ignore List) — DevTools пропускает файлы библиотек при пошаговой отладке. Settings → Ignore List.`;
