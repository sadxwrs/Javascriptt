document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое blackboxing в DevTools? Как добавить библиотеку в blackbox и зачем?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Performance вкладка в DevTools:
// 1. Открыть DevTools -> Performance
// 2. Нажать Record (⏺)
// 3. Выполнить действие на странице
// 4. Нажать Stop
// 5. Анализировать flame chart

// Что искать:
// - Длинные жёлтые блоки (scripting) > 50ms
// - Принудительный reflow (фиолетовые блоки)
// - Частые перерисовки

function heavyTask() {
  const arr = [];
  for (let i = 0; i < 1_000_000; i++) {
    arr.push(Math.sqrt(i));
  }
  return arr.length;
}

console.time('heavy');
heavyTask();
console.timeEnd('heavy'); // альтернатива Performance`;

document.getElementById('output').textContent = `Performance tab: Record → действие → Stop. Flame chart показывает где тратится время. Ищи блоки > 50ms.`;
