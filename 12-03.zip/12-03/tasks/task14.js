document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как использовать Performance-вкладку для поиска медленных функций? Что такое flame graph?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Memory вкладка в DevTools -> Heap snapshot
// Помогает найти утечки памяти

// Пример утечки памяти:
const leaks = [];

function createLeak() {
  const bigArray = new Array(10000).fill('data'); // большой массив
  leaks.push(bigArray); // никогда не очищается — утечка!
}

// Как использовать Heap Snapshot:
// 1. DevTools -> Memory -> Take snapshot (до)
// 2. Выполнить подозрительный код
// 3. Take snapshot (после)
// 4. Сравнить — найти объекты которые остались в памяти

setInterval(createLeak, 1000); // утечка растёт со временем
console.log("Смотри Memory tab!");`;

document.getElementById('output').textContent = `Heap Snapshot: сделать до и после подозрительного кода, сравнить. Лишние объекты в памяти = утечка.`;
