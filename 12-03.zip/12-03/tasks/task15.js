document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как отладить утечку памяти с помощью Memory-вкладки DevTools? Что такое Heap Snapshot?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Network вкладка — мониторинг всех HTTP запросов
// Показывает: URL, статус, тип, размер, время

// Полезные фильтры:
// XHR/Fetch — только AJAX запросы
// Img — только изображения
// WS — WebSocket соединения

// Как анализировать запрос:
// Кликнуть на запрос -> вкладки:
// Headers — заголовки запроса/ответа
// Preview — красивый вид ответа
// Response — сырой ответ
// Timing — Waterfall диаграмма

fetch('https://jsonplaceholder.typicode.com/posts/1')
  .then(r => r.json())
  .then(data => console.log('Данные:', data));
// В Network увидишь этот запрос с полной информацией`;

document.getElementById('output').textContent = `Network tab показывает все запросы. Фильтр XHR — только AJAX. Timing — как долго каждый этап запроса.`;
