document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое code style? Зачем нужны единые соглашения в команде?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Стиль кода — набор соглашений для читаемого и единообразного кода
// Зачем: упрощает чтение, ревью, командную работу

// Плохо: непоследовательный стиль
const x=1;const y=2
function f(a,b){return a+b}

// Хорошо: единый стиль
const x = 1;
const y = 2;

function add(a, b) {
  return a + b;
}

// Популярные style guides:
// - Airbnb JavaScript Style Guide
// - Google JavaScript Style Guide
// - StandardJS (без точек с запятой)
console.log(add(x, y));`;

document.getElementById('output').textContent = `Стиль кода — соглашения о форматировании. Популярные гайды: Airbnb, Google, StandardJS. Главное — единообразие.`;
