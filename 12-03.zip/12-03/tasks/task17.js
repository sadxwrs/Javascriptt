document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Чем отличается camelCase от snake_case и PascalCase? Когда применяется каждый в JS?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Соглашения об именовании в JavaScript:

// camelCase — переменные, функции
const userName = 'Alice';
const userAge = 25;
function getUserName() { return userName; }

// PascalCase — классы, компоненты (React)
class UserProfile {}
class ProductCard {}
const UserComponent = () => {};

// UPPER_SNAKE_CASE — константы
const MAX_RETRY_COUNT = 3;
const API_BASE_URL = 'https://api.example.com';

// snake_case — в JS не используется (только в Python)
// const user_name = 'wrong'; // не принято в JS

// kebab-case — файлы, CSS классы
// user-profile.js, .product-card {}

console.log(userName, MAX_RETRY_COUNT);`;

document.getElementById('output').textContent = `camelCase — переменные/функции. PascalCase — классы. UPPER_SNAKE_CASE — константы. kebab-case — файлы/CSS.`;
