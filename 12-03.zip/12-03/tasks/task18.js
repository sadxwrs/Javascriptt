document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое ESLint? Как он помогает соблюдать стиль кода?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// ESLint — инструмент статического анализа JavaScript кода
// Находит ошибки и нарушения стиля до запуска кода

// Установка:
// npm install --save-dev eslint
// npx eslint --init

// Пример .eslintrc.json:
// {
//   "extends": "eslint:recommended",
//   "rules": {
//     "no-unused-vars": "error",
//     "no-console": "warn",
//     "semi": ["error", "always"],
//     "quotes": ["error", "single"]
//   }
// }

// Код с ошибками ESLint:
let unusedVar = 42; // ESLint: 'unusedVar' is assigned but never used
var x = 1          // ESLint: Missing semicolon

// Запуск: npx eslint src/
// В VS Code: расширение ESLint показывает ошибки сразу
console.log("ESLint помогает поддерживать качество кода");`;

document.getElementById('output').textContent = `ESLint — статический анализ кода. Находит ошибки и нарушения стиля. Установка: npm i -D eslint, npx eslint --init.`;
