document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое Prettier? Чем он отличается от ESLint?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Prettier — автоматический форматировщик кода
// В отличие от ESLint, не проверяет логику — только форматирует

// Установка:
// npm install --save-dev prettier

// .prettierrc:
// {
//   "semi": true,
//   "singleQuote": true,
//   "tabWidth": 2,
//   "printWidth": 80,
//   "trailingComma": "es5"
// }

// До Prettier:
const obj={name:'Alice',age:25,city:'Moscow'}
function greet(  name  ){return 'Hello '+name}

// После Prettier (npx prettier --write src/):
const obj = { name: 'Alice', age: 25, city: 'Moscow' };
function greet(name) {
  return 'Hello ' + name;
}

console.log("Prettier форматирует — ESLint проверяет логику");`;

document.getElementById('output').textContent = `Prettier — форматировщик кода. Только стиль, не логика. Конфиг в .prettierrc. Запуск: prettier --write.`;
