document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что делает оператор <code>debugger</code>? Когда он полезен?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Оператор debugger — останавливает выполнение JS если DevTools открыт
function calculatePrice(price, discount) {
  debugger; // ← выполнение остановится здесь
  const result = price - (price * discount / 100);
  return result;
}

// Полезен когда нужно проверить состояние переменных в конкретном месте
calculatePrice(1000, 20);
console.log("Без открытых DevTools debugger просто игнорируется");`;

document.getElementById('output').textContent = `debugger останавливает JS при открытых DevTools. Без DevTools — игнорируется. Удобен для инспекции переменных.`;
