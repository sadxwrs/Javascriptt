document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Почему важно ограничивать длину строки кода? Какой стандарт чаще всего используют?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Длина строки: рекомендуется максимум 80-120 символов
// Причина: читаемость, side-by-side diff в git

// Плохо: очень длинная строка
const result = someObject.someMethod(parameterOne, parameterTwo, parameterThree, parameterFour);

// Хорошо: разбить на несколько строк
const result = someObject.someMethod(
  parameterOne,
  parameterTwo,
  parameterThree,
  parameterFour
);

// Длинные условия:
if (
  conditionOne &&
  conditionTwo &&
  conditionThree
) {
  doSomething();
}

// В ESLint: "max-len": ["error", { "code": 80 }]
// В Prettier: "printWidth": 80
console.log("80-120 символов — оптимальная длина строки");`;

document.getElementById('output').textContent = `Максимум 80-120 символов на строку. Длинные строки разбивать. ESLint: max-len, Prettier: printWidth.`;
