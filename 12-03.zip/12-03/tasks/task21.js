document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое EditorConfig? Напиши минимальный <code>.editorconfig</code> для JS-проекта.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// EditorConfig — конфигурация редактора для единообразия в команде
// Файл .editorconfig в корне проекта

// Пример .editorconfig:
// root = true
//
// [*]
// charset = utf-8
// end_of_line = lf
// indent_style = space
// indent_size = 2
// trim_trailing_whitespace = true
// insert_final_newline = true
//
// [*.md]
// trim_trailing_whitespace = false

// Поддерживается VS Code, IntelliJ, Vim и другими
// Важно: устанавливает базовые правила ДО ESLint и Prettier

// Это решает проблему: Windows использует CRLF, Unix — LF
// Без EditorConfig git показывает diff на каждой строке
console.log("EditorConfig — единые правила для всей команды");`;

document.getElementById('output').textContent = `.editorconfig задаёт indent_style, end_of_line, charset. Работает во всех редакторах без плагинов (почти).`;
