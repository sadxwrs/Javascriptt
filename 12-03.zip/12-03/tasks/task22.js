document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое принцип "один уровень абстракции на функцию"? Приведи пример нарушения и исправления.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Принцип: функция должна работать на одном уровне абстракции

// Плохо: разные уровни смешаны
function processOrder(order) {
  // Низкий уровень: SQL запрос
  const query = \\\`INSERT INTO orders VALUES (\\\${order.id}, '\\\${order.name}')\\\`;
  db.execute(query);
  // Высокий уровень: бизнес-логика
  sendConfirmationEmail(order.user);
  updateInventory(order.items);
}

// Хорошо: один уровень абстракции
function processOrder(order) {
  saveOrderToDatabase(order);     // всё на одном уровне
  notifyCustomer(order.user);
  updateInventory(order.items);
}

function saveOrderToDatabase(order) {
  const query = \\\`INSERT INTO orders VALUES (\\\${order.id}, '\\\${order.name}')\\\`;
  db.execute(query); // детали здесь
}

console.log("Один уровень абстракции на функцию!");`;

document.getElementById('output').textContent = `Функция должна работать на одном уровне абстракции. Не мешать SQL-запросы с бизнес-логикой в одном месте.`;
