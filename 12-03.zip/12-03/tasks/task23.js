document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое "магические числа" (magic numbers) в коде? Как от них избавиться?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Magic numbers — числа без объяснения. Проблема: непонятно что они значат

// Плохо:
function canVote(age) {
  return age >= 18; // что значит 18?
}

if (status === 2) { // что значит 2?
  processPayment();
}

setTimeout(callback, 86400000); // что такое 86400000?

// Хорошо:
const VOTING_AGE = 18;
const STATUS_APPROVED = 2;
const ONE_DAY_MS = 24 * 60 * 60 * 1000; // 86400000

function canVote(age) {
  return age >= VOTING_AGE;
}

if (status === STATUS_APPROVED) {
  processPayment();
}

setTimeout(callback, ONE_DAY_MS);
console.log("Именованные константы > magic numbers");`;

document.getElementById('output').textContent = `Magic numbers — непонятные числа в коде. Решение: вынести в именованные константы. Код становится самодокументируемым.`;
