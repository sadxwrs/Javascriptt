document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое принцип DRY (Don't Repeat Yourself)? Приведи пример его применения.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// DRY = Don't Repeat Yourself
// Каждый кусок знания должен иметь единственное место в системе

// Плохо: дублирование
function getFullNameUser(user) {
  return user.firstName + ' ' + user.lastName;
}
function getFullNameAuthor(author) {
  return author.firstName + ' ' + author.lastName; // копипаст!
}

// Хорошо: общая функция
function getFullName(person) {
  return \\\`\\\${person.firstName} \\\${person.lastName}\\\`;
}

const userName = getFullName(user);
const authorName = getFullName(author);

// DRY нарушается при:
// - Копировании блоков кода
// - Дублировании бизнес-правил
// - Повторении логики валидации
console.log("DRY: не повторяй себя!");`;

document.getElementById('output').textContent = `DRY — Don't Repeat Yourself. Дублирование = проблема: при изменении нужно менять везде. Выносить общее в функции.`;
