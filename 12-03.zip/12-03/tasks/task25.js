document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое принцип KISS (Keep It Simple, Stupid)? Как он влияет на написание функций?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// KISS = Keep It Simple, Stupid
// Простое решение лучше сложного

// Плохо: излишняя сложность
function isEven(n) {
  return n % 2 === 0 ? true : false; // зачем тернарный?
}

function getAbsoluteValue(n) {
  if (n < 0) {
    return n * -1;
  } else {
    return n;
  }
}

// Хорошо: просто и понятно
const isEven = n => n % 2 === 0;
const abs = n => Math.abs(n);

// Признаки нарушения KISS:
// - Глубокая вложенность (> 3 уровней)
// - Функции > 20-30 строк
// - Непонятные однострочники ради "краткости"
// - Преждевременная оптимизация

console.log(isEven(4)); // true
console.log(abs(-5));   // 5`;

document.getElementById('output').textContent = `KISS — Keep It Simple. Простое решение лучше сложного. Признаки нарушения: глубокая вложенность, огромные функции.`;
