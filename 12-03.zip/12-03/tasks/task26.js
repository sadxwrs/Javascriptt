document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Почему глубокая вложенность кода — это проблема? Как её уменьшить?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Глубокая вложенность ухудшает читаемость

// Плохо: 4+ уровня вложенности
function processUser(user) {
  if (user) {
    if (user.isActive) {
      if (user.age >= 18) {
        if (user.hasPermission) {
          doSomething(user);
        }
      }
    }
  }
}

// Хорошо: early return (охранные условия)
function processUser(user) {
  if (!user) return;
  if (!user.isActive) return;
  if (user.age < 18) return;
  if (!user.hasPermission) return;

  doSomething(user); // основная логика — в конце
}

// Правило: максимум 2-3 уровня вложенности
// Глубже — рефакторить: выносить в функции, использовать early return
console.log("Early return уменьшает вложенность!");`;

document.getElementById('output').textContent = `Максимум 2-3 уровня вложенности. Используй early return (охранные условия) вместо глубоких if-else.`;
