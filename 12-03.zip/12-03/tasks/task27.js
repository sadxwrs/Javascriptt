document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как правильно именовать булевы переменные? Приведи примеры хороших и плохих имён.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Именование булевых переменных: используй глаголы/прилагательные

// Плохо:
const login = true;
const error = false;
const data = true;

// Хорошо: is/has/can/should/will
const isLoggedIn = true;
const hasError = false;
const canEdit = true;
const shouldRedirect = false;
const isLoading = false;
const hasPermission = true;

// Функции возвращающие boolean: тоже с is/has/can
function isValidEmail(email) {
  return email.includes('@');
}

function hasUserPermission(user, action) {
  return user.permissions.includes(action);
}

console.log(isLoggedIn, hasError);
console.log(isValidEmail('test@example.com')); // true`;

document.getElementById('output').textContent = `Булевы переменные: is/has/can/should/will. isLoggedIn, hasError, canEdit. Функции: isValid(), hasPermission().`;
