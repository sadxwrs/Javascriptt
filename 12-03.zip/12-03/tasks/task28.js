document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое линтер-правило <code>no-shadow</code>? Почему shadowing переменных опасен?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// no-shadow — ESLint правило: нельзя называть переменную именем из внешнего scope

// Плохо: внутренний 'value' скрывает внешний
const value = 10;

function processData() {
  const value = 20; // тень внешнего value — путаница!
  console.log(value); // 20, но кто-то может решить что 10
}

// Плохо: параметр скрывает внешнее имя
const user = { name: 'Alice' };
function greet(user) { // параметр user скрывает внешний user
  return \\\`Hello, \\\${user.name}\\\`;
}

// Хорошо: разные, понятные имена
const defaultUser = { name: 'Alice' };
function greet(currentUser) {
  return \\\`Hello, \\\${currentUser.name}\\\`;
}

// ESLint: "no-shadow": "error"
console.log(value, greet(defaultUser));`;

document.getElementById('output').textContent = `no-shadow: нельзя объявлять переменную с именем из внешнего scope. Это создаёт путаницу. ESLint поймает.`;
