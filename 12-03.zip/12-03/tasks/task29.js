document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое принцип "early return" и как он улучшает читаемость функций? Напиши пример рефакторинга.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Early return — возвращаться как можно раньше, избегая else

// Плохо: лесенка
function divide(a, b) {
  if (b !== 0) {
    if (typeof a === 'number' && typeof b === 'number') {
      return a / b;
    } else {
      return 'Не числа';
    }
  } else {
    return 'Деление на ноль';
  }
}

// Хорошо: early return
function divide(a, b) {
  if (b === 0) return 'Деление на ноль';
  if (typeof a !== 'number' || typeof b !== 'number') return 'Не числа';
  return a / b; // "счастливый путь" — в конце
}

console.log(divide(10, 2));  // 5
console.log(divide(10, 0));  // Деление на ноль
console.log(divide('a', 2)); // Не числа`;

document.getElementById('output').textContent = `Early return: сначала отсеиваем ошибочные случаи, в конце — основная логика. Убирает вложенность if-else.`;
