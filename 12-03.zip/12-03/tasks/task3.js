document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как поставить breakpoint на строку кода в DevTools? Что происходит при остановке?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Установка breakpoint в DevTools -> Sources:
// 1. Открыть DevTools (F12)
// 2. Вкладка Sources -> найти нужный файл
// 3. Кликнуть на номер строки — появится синяя метка (breakpoint)
// 4. При выполнении кода остановка произойдёт ПЕРЕД этой строкой

function greet(name) {
  const message = "Hello, " + name; // ← поставить breakpoint здесь
  return message;
}

greet("World");
// При остановке: в панели Scope видны все переменные в scope`;

document.getElementById('output').textContent = `Кликнуть на номер строки в Sources — появится синий breakpoint. Остановка происходит ПЕРЕД строкой.`;
