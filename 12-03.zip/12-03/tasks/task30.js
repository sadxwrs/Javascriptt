document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как настроить ESLint + Prettier + husky + lint-staged для автоматической проверки кода перед коммитом?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// husky — запускает скрипты на git hooks
// lint-staged — применяет linter только к изменённым файлам (staged)

// Установка:
// npm install --save-dev husky lint-staged
// npx husky init

// package.json:
// {
//   "lint-staged": {
//     "*.js": ["eslint --fix", "prettier --write"],
//     "*.{css,md}": "prettier --write"
//   },
//   "scripts": {
//     "prepare": "husky"
//   }
// }

// .husky/pre-commit (создаётся автоматически):
// npx lint-staged

// Как это работает:
// 1. git add файлы
// 2. git commit
// 3. husky запускает pre-commit hook
// 4. lint-staged проверяет только staged файлы
// 5. Если ошибки — коммит отменяется
console.log("husky + lint-staged = автоматическая проверка перед коммитом");`;

document.getElementById('output').textContent = `husky запускает скрипты на git hooks. lint-staged проверяет только staged файлы. Вместе: автопроверка при коммите.`;
