document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое JSDoc? Напиши JSDoc-комментарий для функции <code>sum(a, b)</code>.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `/**
 * JSDoc — стандарт документирования JavaScript через комментарии
 * Используется для: автодополнения в IDE, генерации документации
 */

/**
 * Складывает два числа
 * @param {number} a - Первое слагаемое
 * @param {number} b - Второе слагаемое
 * @returns {number} Сумма a и b
 */
function add(a, b) {
  return a + b;
}

/**
 * Описание пользователя
 * @typedef {Object} User
 * @property {number} id - Уникальный идентификатор
 * @property {string} name - Имя пользователя
 * @property {boolean} isActive - Активен ли пользователь
 */

/**
 * @param {User} user
 * @returns {string}
 */
function greet(user) {
  return \\\`Hello, \\\${user.name}!\\\`;
}

console.log(add(2, 3)); // IDE покажет подсказку с типами`;

document.getElementById('output').textContent = `JSDoc: @param, @returns, @typedef. IDE использует для автодополнения и проверки типов без TypeScript.`;
