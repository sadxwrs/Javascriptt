document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что означают теги <code>@param</code> и <code>@returns</code> в JSDoc?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `/**
 * @param — документирует параметр функции
 * @returns — документирует возвращаемое значение
 */

/**
 * Форматирует дату в строку DD.MM.YYYY
 * @param {Date} date - Дата для форматирования
 * @param {string} [separator='.'] - Разделитель (необязательный)
 * @returns {string} Отформатированная дата
 */
function formatDate(date, separator = '.') {
  const day   = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year  = date.getFullYear();
  return \\\`\\\${day}\\\${separator}\\\${month}\\\${separator}\\\${year}\\\`;
}

/**
 * Делит два числа
 * @param {number} a - Делимое
 * @param {number} b - Делитель
 * @returns {number|null} Результат или null при делении на ноль
 */
function divide(a, b) {
  if (b === 0) return null;
  return a / b;
}

console.log(formatDate(new Date()));
console.log(divide(10, 2));`;

document.getElementById('output').textContent = `@param {тип} имя - описание. [имя] — необязательный. @returns {тип} — что возвращает. IDE показывает при вводе.`;
