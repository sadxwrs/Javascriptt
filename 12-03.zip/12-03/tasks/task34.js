document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Когда комментарий "почему" важнее комментария "что"? Приведи пример.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Плохие комментарии объясняют ЧТО делает код (это видно из самого кода)
// Хорошие комментарии объясняют ПОЧЕМУ так сделано

// Плохо: комментарий повторяет код
let i = 0;
i++; // увеличиваем i на 1

const arr = [1, 2, 3];
arr.reverse(); // разворачиваем массив

// Хорошо: объясняет ПОЧЕМУ
// Сортируем по убыванию так как API ожидает данные от новых к старым
transactions.sort((a, b) => b.date - a.date);

// Используем setTimeout(0) для переноса в следующий тик event loop,
// иначе DOM не успевает обновиться перед вычислением высоты
setTimeout(() => { recalcHeight(); }, 0);

// Делим на 1000: API возвращает миллисекунды, нам нужны секунды
const seconds = timestamp / 1000;

console.log("Комментируй ПОЧЕМУ, не ЧТО!");`;

document.getElementById('output').textContent = `Комментируй ПОЧЕМУ, а не ЧТО. Код и так показывает что делает. Объясняй решения, хаки, неочевидные причины.`;
