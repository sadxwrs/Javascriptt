document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое TODO-комментарий? Как принято их форматировать?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// TODO — что нужно сделать в будущем
// FIXME — известная проблема требующая исправления
// HACK/WORKAROUND — временное решение
// NOTE — важное замечание

function getUserData(userId) {
  // TODO: добавить кеширование после оптимизации DB
  return fetch(\\\`/api/users/\\\${userId}\\\`);
}

function calculateDiscount(price, user) {
  // FIXME: для premium пользователей скидка считается неверно при price < 10
  return price * (1 - user.discountRate);
}

function parseDate(str) {
  // HACK: Date.parse ведёт себя по-разному в Safari, используем ручной парсинг
  const [day, month, year] = str.split('.').map(Number);
  return new Date(year, month - 1, day);
}

// NOTE: этот модуль используется только в legacy коде, не трогать
const legacyModule = {};

// Поиск TODO в проекте: grep -r "TODO" src/
// VS Code: расширение "Todo Tree" подсвечивает все метки
console.log("TODO/FIXME/HACK — маркеры для важных замечаний");`;

document.getElementById('output').textContent = `TODO — нужно сделать. FIXME — есть баг. HACK — временный костыль. NOTE — важно знать. Ищи: grep -r TODO src/`;
