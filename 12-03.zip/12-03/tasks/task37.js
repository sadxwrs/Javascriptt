document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое "self-documenting code"? Перепиши плохо именованный код с комментариями в читаемый без них.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Self-documenting code — код, читаемый без комментариев

// Плохо: нужен комментарий чтобы понять
function calc(u, p, t) {
  return u * p * (1 - t);
}

// Хорошо: имена говорят всё
function calculateOrderTotal(unitPrice, quantity, taxRate) {
  return unitPrice * quantity * (1 - taxRate);
}

// Плохо: магические числа и непонятная логика
if (status >= 200 && status < 300) { doSuccess(); }

// Хорошо: именованные функции-предикаты
const isSuccessResponse = status => status >= 200 && status < 300;
if (isSuccessResponse(status)) { doSuccess(); }

// Техники самодокументирующегося кода:
// 1. Понятные имена переменных/функций
// 2. Именованные константы вместо magic numbers
// 3. Маленькие функции с чётким назначением
// 4. Ранние возвраты (early return)

console.log(calculateOrderTotal(100, 3, 0.2)); // 240`;

document.getElementById('output').textContent = `Self-documenting code: понятные имена, именованные константы, маленькие функции. Код читается как текст.`;
