document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое теги <code>@deprecated</code>, <code>@throws</code>, <code>@example</code> в JSDoc? Напиши пример их использования.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `/**
 * @deprecated Используй getUser() вместо этого метода
 * Будет удалён в версии 3.0
 */
function getUserById_OLD(id) {
  return fetch(\\\`/api/users/\\\${id}\\\`);
}

/**
 * Делит два числа
 * @param {number} a - Делимое  
 * @param {number} b - Делитель
 * @returns {number} Результат деления
 * @throws {Error} Если b равно нулю
 * @example
 * divide(10, 2) // => 5
 * divide(7, 2)  // => 3.5
 */
function divide(a, b) {
  if (b === 0) throw new Error('Деление на ноль');
  return a / b;
}

/**
 * @example
 * // Создать пользователя:
 * const user = createUser({ name: 'Alice', age: 25 });
 * console.log(user.id); // уникальный ID
 */
function createUser(data) {
  return { ...data, id: Date.now() };
}

console.log(divide(10, 2));`;

document.getElementById('output').textContent = `@deprecated — устаревший метод. @throws — какие ошибки бросает. @example — примеры использования в IDE.`;
