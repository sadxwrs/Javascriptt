document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как комментарии помогают при code review? Что такое "commenting contract"?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Code Review — проверка кода коллегами перед мержем

// Что проверяют на ревью:
// 1. Корректность логики
// 2. Читаемость и стиль
// 3. Тесты
// 4. Безопасность
// 5. Производительность

// Хороший комментарий на ревью:
// ❌ "Это неправильно" (неконструктивно)
// ✅ "Этот цикл O(n²), можно использовать Set для O(n):
//    const set = new Set(arr); return arr.filter(x => !set.has(x))"

// Пример кода для ревью с проблемами:
function findDuplicates(arr) {
  const result = [];
  for (let i = 0; i < arr.length; i++) {       // O(n²) — проблема производительности
    for (let j = i + 1; j < arr.length; j++) {
      if (arr[i] === arr[j] && !result.includes(arr[i])) {
        result.push(arr[i]);
      }
    }
  }
  return result;
}

// Исправление после ревью:
function findDuplicates_v2(arr) {
  const seen = new Set();
  return arr.filter(x => seen.size === seen.add(x).size);
}

console.log(findDuplicates_v2([1, 2, 3, 2, 1, 4]));`;

document.getElementById('output').textContent = `Code review: проверка логики, стиля, тестов, безопасности. Конструктивный комментарий = проблема + решение.`;
