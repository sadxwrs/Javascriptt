document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Чем отличаются кнопки Step Over, Step Into и Step Out при пошаговой отладке?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Step Over (F10)  — выполнить текущую строку целиком, не заходя в функции
// Step Into (F11)  — войти внутрь вызываемой функции
// Step Out  (Shift+F11) — выйти из текущей функции наверх

function inner() {
  console.log("Я внутри inner()"); // Step Into приведёт сюда
}

function outer() {
  debugger;
  inner();       // Step Over: пропустит inner(), Step Into: зайдёт внутрь
  console.log("После inner"); // Step Out из inner() попадёт сюда
}

outer();`;

document.getElementById('output').textContent = `Step Over (F10) — пропустить функцию. Step Into (F11) — войти в неё. Step Out (Shift+F11) — выйти наружу.`;
