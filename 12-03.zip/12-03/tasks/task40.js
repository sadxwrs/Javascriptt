document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как настроить автогенерацию документации из JSDoc-комментариев (например через JSDoc 3 или TypeDoc)?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// JSDoc + инструменты генерации документации

// Инструменты:
// - JSDoc (npx jsdoc src/ -d docs/)
// - TypeDoc (для TypeScript)
// - ESDoc

// Хорошо задокументированный модуль:

/**
 * @module MathUtils
 * @description Утилиты для математических вычислений
 */

/**
 * Вычисляет факториал числа
 * @param {number} n - Неотрицательное целое число
 * @returns {number} Факториал n
 * @throws {RangeError} Если n отрицательное
 * @example
 * factorial(0) // => 1
 * factorial(5) // => 120
 */
function factorial(n) {
  if (n < 0) throw new RangeError('n должно быть >= 0');
  if (n === 0 || n === 1) return 1;
  return n * factorial(n - 1);
}

// Команда генерации: npx jsdoc app.js -d ./docs
// Результат: HTML документация в папке docs/
console.log(factorial(5)); // 120`;

document.getElementById('output').textContent = `JSDoc + jsdoc CLI генерирует HTML документацию. npx jsdoc src/ -d docs/. TypeDoc — для TypeScript проектов.`;
