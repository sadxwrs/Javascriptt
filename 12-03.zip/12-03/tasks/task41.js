document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое "literate programming"? Как идея влияет на современные практики написания комментариев?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Literate Programming — концепция Кнута:
// Программа как текст для людей, с вставками кода

// В JS применяется как хорошо документированный код:

/**
 * ЗАДАЧА: Найти все простые числа до N (Решето Эратосфена)
 *
 * АЛГОРИТМ:
 * 1. Создаём массив булевых значений [2..N], все = true (простые)
 * 2. Начиная с p=2: помечаем все кратные p как составные (false)
 * 3. Берём следующее незачеркнутое число — оно простое
 * 4. Повторяем до sqrt(N)
 *
 * СЛОЖНОСТЬ: O(n log log n) по времени, O(n) по памяти
 */
function sieveOfEratosthenes(n) {
  const isPrime = new Array(n + 1).fill(true);
  isPrime[0] = isPrime[1] = false; // 0 и 1 — не простые

  for (let p = 2; p * p <= n; p++) {
    if (isPrime[p]) {
      // Зачёркиваем все кратные p начиная с p²
      for (let multiple = p * p; multiple <= n; multiple += p) {
        isPrime[multiple] = false;
      }
    }
  }
  return isPrime.reduce((primes, val, idx) => val ? [...primes, idx] : primes, []);
}

console.log(sieveOfEratosthenes(30)); // [2,3,5,7,11,13,17,19,23,29]`;

document.getElementById('output').textContent = `Literate programming: код + объяснение алгоритма вместе. JSDoc + комментарии с теорией = самодокументирующийся модуль.`;
