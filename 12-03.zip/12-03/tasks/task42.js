document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое "ниндзя-код"? Почему намеренно запутанный код — это проблема для команды?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Ниндзя-код — стиль написания намеренно запутанного кода
// (антипаттерн! описан для понимания чего НЕ делать)

// Признаки ниндзя-кода:
// 1. Однобуквенные имена
// 2. Сокращения
// 3. Максимальная краткость любой ценой
// 4. Повторное использование переменных
// 5. Умные однострочники

// Пример ниндзя-кода (ПЛОХО):
const a = (x, y) => x > y ? x : y;
let d = new Date(); let t = d.getTime();
const r = (a) => a.reduce((s,v)=>s+v,0)/a.length;

// Тот же код читаемо (ХОРОШО):
const getMaxValue = (first, second) => first > second ? first : second;
const now = new Date();
const timestamp = now.getTime();
const calculateAverage = (numbers) => {
  const sum = numbers.reduce((total, value) => total + value, 0);
  return sum / numbers.length;
};

console.log(getMaxValue(5, 3)); // 5
console.log(calculateAverage([1, 2, 3, 4])); // 2.5`;

document.getElementById('output').textContent = `Ниндзя-код — умышленно запутанный код. Признаки: однобуквенные имена, сокращения, трюки. Антипаттерн!`;
