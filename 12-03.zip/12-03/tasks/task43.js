document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что плохого в однобуквенных именах переменных вроде <code>x</code>, <code>t</code>, <code>d</code>? Когда они допустимы?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Однобуквенные имена — часть ниндзя-кода (ПЛОХО)
// Исключения: i/j/k в простых циклах, x/y в математике

// Плохо: непонятные имена
function p(d) {
  const r = d.filter(u => u.a > 18);
  return r.map(u => u.n);
}

// Хорошо: понятные имена
function getAdultUserNames(users) {
  const adultUsers = users.filter(user => user.age > 18);
  return adultUsers.map(user => user.name);
}

// Допустимо: стандартные сокращения в ограниченном контексте
for (let i = 0; i < arr.length; i++) {
  // i понятен всем в контексте цикла
}

const distance = Math.sqrt(x * x + y * y);
// x, y понятны в математическом контексте

// Правило: имя должно описывать содержимое
// Чем шире область видимости — тем подробнее имя
const users = [{ name: 'Alice', age: 25 }];
console.log(getAdultUserNames(users));`;

document.getElementById('output').textContent = `Однобуквенные имена допустимы только для i/j в циклах и x/y в математике. Всё остальное — описательные имена.`;
