document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое сокращение имён переменных как анти-паттерн? Приведи пример <code>brsr</code> вместо <code>browser</code>.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Сокращения в именах — плохая практика (ПЛОХО)

// Плохо: сокращения которые непонятны без контекста
const usrNm = 'Alice';
const btnClk = () => {};
const mgr = new UserManager();
const cfg = { host: 'localhost' };
const req = {}; // это request? requirement?
const res = {}; // это result? response? resource?

// Хорошо: полные понятные имена
const userName = 'Alice';
const handleButtonClick = () => {};
const userManager = new UserManager();
const config = { host: 'localhost' };
const request = {};
const response = {};

// Допустимые общепринятые сокращения:
const btn = document.querySelector('button'); // btn — общепринятое
const el = document.getElementById('app');   // el — общепринятое
const e = event;                              // e для event handler
const cb = callback;                          // cb — часто используется
const fn = someFunction;                      // fn — понятно

console.log(userName);`;

document.getElementById('output').textContent = `Избегай сокращений: usrNm, btnClk, mgr — непонятно. Допустимы общепринятые: btn, el, e, cb, fn, i.`;
