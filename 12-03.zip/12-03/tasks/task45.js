document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Почему переиспользование одной переменной для разных целей — плохая практика?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Переиспользование переменных — ниндзя трюк (ПЛОХО)
// Одна переменная для разных данных = путаница

// Плохо: переменная меняет смысл
let data = fetchUserData(); // data — данные пользователя
data = data.filter(u => u.active); // data — отфильтрованные
data = data.map(u => u.name); // data — массив имён
data = data.join(', '); // data — строка

// Хорошо: каждый этап — своя переменная
const allUsers = fetchUserData();
const activeUsers = allUsers.filter(u => u.active);
const userNames = activeUsers.map(u => u.name);
const nameList = userNames.join(', ');

// Почему плохо переиспользовать:
// 1. Нельзя отладить промежуточные результаты
// 2. Тяжело читать (что в data сейчас?)
// 3. Нельзя использовать allUsers позже
// 4. let вместо const — открывает дверь к мутациям

function fetchUserData() {
  return [{ active: true, name: 'Alice' }, { active: false, name: 'Bob' }];
}
console.log(nameList);`;

document.getElementById('output').textContent = `Не переиспользуй переменные для разных данных. Каждый этап = новая переменная. Используй const вместо let.`;
