document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое "умные" однострочники? Почему краткость не всегда = качество?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Умные однострочники — ниндзя трюк (ПЛОХО)
// Краткость ради краткости снижает читаемость

// Плохо: однострочник который трудно читать
const result = arr.reduce((a,c,i)=>i===0?c:a+','+c);
const doubled = [...Array(5)].map((_,i)=>2*i+2);
const flat = arr.reduce((a,b)=>[...a,...b],[]);

// Хорошо: понятный код
const result = arr.join(',');
const doubled = [2, 4, 6, 8, 10];
const flat = arr.flat();

// Граница между умным и элегантным:
// Умно но плохо:
const isPalindrome = s => s.split('').reverse().join('') === s;

// Лучше для сложной логики:
function isPalindrome(str) {
  const reversed = str.split('').reverse().join('');
  return reversed === str;
}

// Простой однострочник — норм:
const sum = (a, b) => a + b; // понятно и кратко
const double = x => x * 2;

console.log(sum(3, 4), double(5));`;

document.getElementById('output').textContent = `Однострочники ОК когда логика простая. Сложная логика в одну строку = ниндзя-код. Читаемость важнее краткости.`;
