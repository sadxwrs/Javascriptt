document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое "подчёркивание ради подчёркивания"? Когда префикс <code>_</code> несёт смысл, а когда нет?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Подчёркивание _ как префикс — соглашение о 'приватности'
// В современном JS можно использовать # для приватных полей класса

// Старое соглашение: _ = приватное (только соглашение, не защита)
class OldClass {
  constructor() {
    this._privateData = 'secret'; // _ = "не трогай снаружи"
    this.publicData = 'visible';
  }
  _privateMethod() { return this._privateData; }
  publicMethod() { return this._privateMethod(); }
}

// Современный JS: # = реально приватное
class ModernClass {
  #privateData = 'secret'; // реальная приватность!
  publicData = 'visible';

  #privateMethod() { return this.#privateData; }
  publicMethod() { return this.#privateMethod(); }
}

const obj = new ModernClass();
console.log(obj.publicData);     // 'visible'
console.log(obj.publicMethod()); // 'secret'
// console.log(obj.#privateData); // SyntaxError!

// _ как "неиспользуемая переменная":
const [first, _, third] = [1, 2, 3]; // _ игнорируем
console.log(first, third); // 1 3`;

document.getElementById('output').textContent = `_ — старое соглашение о приватности. # — реальная приватность в ES2022. _ как заглушка для неиспользуемых переменных.`;
