document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Почему добавление новых свойств к встроенным прототипам (<code>Array.prototype.myMethod</code>) опасно?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Monkey patching — изменение встроенных объектов/прототипов (ОПАСНО)
// Ниндзя трюк: может сломать чужой код

// ПЛОХО: патчим встроенный прототип
Array.prototype.sum = function() {
  return this.reduce((a, b) => a + b, 0);
};
[1, 2, 3].sum(); // работает, но...
// Проблема: другие библиотеки могут сделать то же по-другому!

// ПЛОХО: патчим Math
Math.randomInt = (max) => Math.floor(Math.random() * max);

// ХОРОШО: утилитарные функции вместо патчинга
function sumArray(arr) {
  return arr.reduce((a, b) => a + b, 0);
}
function randomInt(max) {
  return Math.floor(Math.random() * max);
}

// Когда monkey patching допустим:
// - Полифилы: добавляем метод только если его нет
if (!Array.prototype.at) {
  Array.prototype.at = function(index) {
    return index < 0 ? this[this.length + index] : this[index];
  };
}

console.log(sumArray([1, 2, 3]));
console.log(randomInt(10));`;

document.getElementById('output').textContent = `Monkey patching встроенных прототипов — опасно, конфликты с библиотеками. Исключение: полифилы с проверкой if(!method).`;
