document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое "побочные эффекты в условиях" как ниндзя-трюк? Приведи пример и объясни проблему.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Побочные эффекты в условиях — ниндзя трюк (ПЛОХО)
// Код который что-то делает И проверяет условие = путаница

// Плохо: присваивание внутри if
let result;
if (result = fetchData()) { // присваивает И проверяет
  processResult(result);
}

// Плохо: функция с побочным эффектом в условии
if (updateAndCheck(user)) { // что именно проверяется?
  doSomething();
}

// Плохо: инкремент в условии
while (arr[i++] !== null) { // i изменяется здесь!
  process(arr[i]); // уже другой индекс!
}

// Хорошо: разделяй действие и проверку
const data = fetchData();
if (data) {
  processResult(data);
}

function fetchData() { return { value: 42 }; }
function processResult(r) { console.log('Результат:', r.value); }

const data2 = fetchData();
if (data2) processResult(data2);`;

document.getElementById('output').textContent = `Не делай побочных эффектов в условиях. Присваивание в if, изменение переменной в while — читать и отлаживать сложно.`;
