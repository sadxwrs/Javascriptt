document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как посмотреть значение переменной при остановке на breakpoint?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// При остановке на breakpoint в DevTools можно:
// 1. Навести мышку на переменную — увидеть её значение (tooltip)
// 2. Панель Scope (справа) — все переменные текущего scope
// 3. Консоль — вводить выражения и видеть результат
// 4. Watch — добавить выражение для постоянного отслеживания

function calc(a, b) {
  debugger; // Навести мышь на 'a' или 'b' — увидишь значения
  const sum = a + b;
  return sum;
}

calc(10, 25);
// В Scope появятся: a=10, b=25, sum=undefined (ещё не вычислено)`;

document.getElementById('output').textContent = `Навести мышь на переменную → tooltip. Панель Scope — все переменные. Консоль — ввести любое выражение.`;
