document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Почему возврат разных типов из одной функции — это ниндзя-приём? Что следует делать вместо этого?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Функция должна возвращать значения одного типа (ПРИНЦИП)
// Разные типы возврата — ниндзя трюк (ПЛОХО)

// Плохо: возвращает число ИЛИ null ИЛИ строку
function getAge(user) {
  if (!user) return null;
  if (user.age > 200) return 'invalid'; // строка!
  return user.age; // число
}

// Хорошо: последовательный тип возврата
/**
 * @returns {number|null} Возраст или null если невалидно
 */
function getAge(user) {
  if (!user || user.age > 200) return null;
  return user.age; // всегда число или null
}

// Хорошо: или бросать ошибки вместо null
function getAge(user) {
  if (!user) throw new TypeError('user обязателен');
  if (user.age > 200) throw new RangeError('Некорректный возраст');
  return user.age; // всегда number
}

console.log(getAge({ age: 25 }));  // 25
console.log(getAge(null));          // null`;

document.getElementById('output').textContent = `Функция должна возвращать один тип. Смесь числа/строки/null/undefined — ниндзя. Используй null/undefined единообразно.`;
