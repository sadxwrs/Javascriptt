document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Найди и объясни все "ниндзя-проблемы" в коде:\\n<code>function f(a,b,c,d){return a?b?c:d:b}</code><br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Функции с множеством параметров — проблема читаемости

// Плохо: сложно понять что значит каждый аргумент
function createUser(a, b, c, d, e) {
  return { name: a, age: b, email: c, role: d, active: e };
}
createUser('Alice', 25, 'alice@mail.com', 'admin', true);
// Что такое 4-й аргумент? 5-й? Нужно смотреть в определение

// Плохо даже с именами параметров если их > 3
function sendEmail(to, from, subject, body, cc, bcc, priority) {
  // 7 параметров — ужас
}

// Хорошо: объект параметров (options object pattern)
function createUser({ name, age, email, role = 'user', active = true }) {
  return { name, age, email, role, active };
}

createUser({ name: 'Alice', age: 25, email: 'alice@mail.com', role: 'admin' });
// Самодокументируется, порядок не важен, есть defaults

function sendEmail({ to, from, subject, body, cc = [], bcc = [], priority = 'normal' }) {
  console.log(\\\`Отправка: \\\${subject} -> \\\${to}\\\`);
}

sendEmail({ to: 'bob@mail.com', from: 'me@mail.com', subject: 'Hi', body: 'Hello' });`;

document.getElementById('output').textContent = `Больше 2-3 параметров → используй объект параметров. Самодокументируется, порядок не важен, можно задать defaults.`;
