document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое "обфускация" кода? Чем она отличается от минификации? Когда обфускация оправдана?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Минификация — сжатие кода без изменения логики (НОРМАЛЬНО)
// Обфускация — намеренное запутывание кода (ниндзя для продакшена)

// Исходный код:
function calculateDiscount(price, discountRate) {
  const discount = price * discountRate;
  return price - discount;
}

// После минификации (terser, UglifyJS):
// function calculateDiscount(p,d){return p-p*d}
// Логика та же, просто сжато для производительности

// После обфускации (javascript-obfuscator):
// var _0x1a2b=['log','Hello'],_0xc3d4=function...
// Специально запутано — нельзя восстановить исходный код

// Зачем нужна минификация:
// - Меньший размер файла = быстрая загрузка
// - Webpack/Vite делают это автоматически в build

// Зачем обфускация:
// - Защита коммерческой логики (игры, лицензии)
// - НЕ для безопасности (легко обойти)

// Source maps — связывают минифицированный код с исходным для отладки
// В DevTools минифицированный код автоматически разворачивается!

console.log(calculateDiscount(1000, 0.2)); // 800`;

document.getElementById('output').textContent = `Минификация сжимает код (Webpack делает автоматически). Обфускация запутывает. Source maps восстанавливают для отладки.`;
