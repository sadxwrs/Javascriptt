document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое автоматическое тестирование? Зачем оно нужно?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Автотесты — код который проверяет другой код
// Зачем: уверенность при рефакторинге, документация поведения

// Простейший тест без фреймворка:
function add(a, b) {
  return a + b;
}

// Ручная проверка:
function assert(condition, message) {
  if (!condition) throw new Error(\\\`FAIL: \\\${message}\\\`);
  console.log(\\\`PASS: \\\${message}\\\`);
}

assert(add(2, 3) === 5, 'add(2, 3) должно быть 5');
assert(add(0, 0) === 0, 'add(0, 0) должно быть 0');
assert(add(-1, 1) === 0, 'add(-1, 1) должно быть 0');

// Преимущества автотестов:
// ✅ Быстрее ручного тестирования
// ✅ Документируют ожидаемое поведение
// ✅ Ловят регрессии при изменениях
// ✅ Дают уверенность при рефакторинге

// Пирамида тестирования:
// Unit tests (много, быстрые)
// Integration tests (средне)
// E2E tests (мало, медленные)`;

document.getElementById('output').textContent = `Автотесты = код проверяющий код. Дают уверенность при изменениях. Пирамида: unit > integration > e2e.`;
