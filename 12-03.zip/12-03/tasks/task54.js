document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое Mocha? Чем он отличается от Jest?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Mocha — фреймворк тестирования (нужны отдельные assert/expect библиотеки)
// Jest — all-in-one (встроенные matchers, mocks, coverage)

// === MOCHA ===
// npm install --save-dev mocha chai
// package.json: "test": "mocha"

// test/add.test.js (Mocha + Chai):
// const { expect } = require('chai');
// describe('add', () => {
//   it('складывает два числа', () => {
//     expect(add(2, 3)).to.equal(5);
//   });
// });

// === JEST ===
// npm install --save-dev jest
// package.json: "test": "jest"

// add.test.js (Jest — всё встроено):
// test('складывает два числа', () => {
//   expect(add(2, 3)).toBe(5);
// });

// Когда что использовать:
// Jest:   React проекты, хочу всё из коробки, нужны мoki
// Mocha:  Node.js, гибкость в выборе assertion библиотеки

console.log('Jest = батарейки в комплекте, Mocha = конструктор');`;

document.getElementById('output').textContent = `Jest — всё встроено (matchers, mocks, coverage). Mocha — гибкий конструктор, нужны Chai + Sinon отдельно.`;
