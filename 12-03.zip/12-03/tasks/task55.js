document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>describe</code> и <code>it</code> в Mocha? Напиши минимальный тест.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// describe — группирует связанные тесты (контейнер)
// it (или test) — отдельный тестовый случай

// Структура с describe/it:
// describe('Имя функции/модуля', () => {
//   describe('Группа сценариев', () => {
//     it('конкретное поведение', () => {
//       // тест
//     });
//   });
// });

// Пример:
function divide(a, b) {
  if (b === 0) throw new Error('Division by zero');
  return a / b;
}

// В тест-файле:
// describe('divide', () => {
//   describe('при корректных аргументах', () => {
//     it('делит два числа', () => {
//       assert.equal(divide(10, 2), 5);
//     });
//     it('работает с дробными числами', () => {
//       assert.equal(divide(7, 2), 3.5);
//     });
//   });
//   describe('при некорректных аргументах', () => {
//     it('бросает ошибку при делении на ноль', () => {
//       assert.throws(() => divide(1, 0));
//     });
//   });
// });

console.log(divide(10, 2));   // 5
console.log(divide(7, 2));    // 3.5`;

document.getElementById('output').textContent = `describe группирует тесты. it/test — отдельный тест. Вложенные describe для подгрупп сценариев.`;
