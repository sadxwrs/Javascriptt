document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>assert.equal</code> и <code>assert.strictEqual</code>? В чём разница?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// assert.equal использует == (нестрогое сравнение)
// assert.strictEqual использует === (строгое сравнение)

const assert = require ? require('assert') : {
  equal: (a, b) => console.log(a == b ? 'PASS' : \\\`FAIL: \\\${a} != \\\${b}\\\`),
  strictEqual: (a, b) => console.log(a === b ? 'PASS' : \\\`FAIL: \\\${a} !== \\\${b}\\\`)
};

// equal: '5' == 5 → true (опасно!)
// assert.equal('5', 5);    // PASS — может маскировать баг типов!

// strictEqual: '5' === 5 → false (правильно)
// assert.strictEqual('5', 5); // FAIL — поймает несоответствие типов

// ВСЕГДА используй strictEqual:
function add(a, b) { return a + b; }

// assert.strictEqual(add(2, 3), 5);    // PASS
// assert.strictEqual(add(2, 3), '5');  // FAIL — правильно поймает

// В Jest аналоги:
// toBe     → строгое ===    (как strictEqual)
// toEqual  → глубокое сравнение объектов
// expect(add(2,3)).toBe(5);           // строгое
// expect({a:1}).toEqual({a:1});       // глубокое

console.log('Всегда используй строгое сравнение в тестах!');`;

document.getElementById('output').textContent = `assert.equal использует ==. assert.strictEqual использует ===. Всегда используй strictEqual! В Jest: toBe.`;
