document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое библиотека Chai? Как подключить её к Mocha?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Chai — assertion библиотека для Mocha с тремя стилями

// === ASSERT style (похож на Node.js assert) ===
// const assert = require('chai').assert;
// assert.equal(value, expected);
// assert.isTrue(value);
// assert.include(array, item);

// === EXPECT style (цепочки, читается как английский) ===
// const expect = require('chai').expect;
// expect(add(2,3)).to.equal(5);
// expect(arr).to.have.length(3);
// expect(obj).to.have.property('name');
// expect(fn).to.throw(Error);

// === SHOULD style (расширяет Object.prototype) ===
// const should = require('chai').should();
// (5).should.equal(5);
// arr.should.have.length(3);

// Пример тестов с expect:
// describe('getUser', () => {
//   it('возвращает объект с name и age', () => {
//     const user = getUser(1);
//     expect(user).to.be.an('object');
//     expect(user).to.have.property('name');
//     expect(user.age).to.be.at.least(0);
//   });
// });

console.log('Chai: assert / expect / should — три стиля на выбор');`;

document.getElementById('output').textContent = `Chai: три стиля — assert (классика), expect (цепочки), should (через прототип). Популярнее всего expect стиль.`;
