document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши тест для функции <code>sum(a, b)</code> используя <code>expect(sum(2,3)).to.equal(5)</code>.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// BDD = Behavior-Driven Development
// Тесты пишутся как сценарии поведения, понятные всем (не только разработчикам)

// Структура BDD: Given / When / Then
// Given — начальное состояние
// When  — действие
// Then  — ожидаемый результат

// Пример в Mocha/Chai:
// describe('Корзина покупок', () => {
//   describe('при добавлении товара', () => {
//     it('увеличивает количество товаров', () => {
//       // Given: пустая корзина
//       const cart = new Cart();
//
//       // When: добавляем товар
//       cart.addItem({ id: 1, name: 'Apple', price: 1.5 });
//
//       // Then: в корзине 1 товар
//       expect(cart.items).to.have.length(1);
//     });
//
//     it('обновляет итоговую сумму', () => {
//       const cart = new Cart();
//       cart.addItem({ id: 1, name: 'Apple', price: 1.5 });
//       expect(cart.total).to.equal(1.5);
//     });
//   });
// });

// BDD имена тестов: "должен делать Х" или "делает Х"
console.log('BDD: Given-When-Then, тесты читаются как документация');`;

document.getElementById('output').textContent = `BDD: тесты описывают поведение через Given/When/Then. Понятны всей команде. it('добавляет товар в корзину').`;
