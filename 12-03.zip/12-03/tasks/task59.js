document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое BDD-стиль тестирования? Что означает <code>describe / it / expect</code>?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Хуки Mocha/Jest для настройки и очистки тестов

// before    — один раз ПЕРЕД всеми тестами в describe
// after     — один раз ПОСЛЕ всех тестов в describe  
// beforeEach — ПЕРЕД каждым тестом
// afterEach  — ПОСЛЕ каждого теста

// Пример:
// describe('Database tests', () => {
//   let db;
//
//   before(async () => {
//     db = await connectToDatabase(); // один раз открываем соединение
//     console.log('DB connected');
//   });
//
//   after(async () => {
//     await db.close(); // один раз закрываем
//     console.log('DB closed');
//   });
//
//   beforeEach(async () => {
//     await db.seed(testData); // свежие данные перед каждым тестом
//   });
//
//   afterEach(async () => {
//     await db.clear(); // чистим после каждого теста
//   });
//
//   it('находит пользователя', async () => {
//     const user = await db.findUser(1);
//     expect(user).to.exist;
//   });
// });

// В Jest: beforeAll, afterAll, beforeEach, afterEach
console.log('Хуки: before/after = один раз, beforeEach/afterEach = каждый тест');`;

document.getElementById('output').textContent = `before/after — один раз для всей suite. beforeEach/afterEach — перед/после каждого теста. Для setup/teardown.`;
