document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое Watch-выражения в DevTools? Как добавить переменную в Watch?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Watch — панель в DevTools для отслеживания выражений
// Добавить: нажать '+' в панели Watch -> вписать выражение

let arr = [1, 2, 3, 4, 5];
let total = 0;

debugger; // Добавь в Watch: arr.length, total, arr[0]*2

for (let i = 0; i < arr.length; i++) {
  total += arr[i];
  debugger; // Watch обновляется при каждой остановке
}

console.log("Итог:", total);
// Watch полезен для отслеживания сложных выражений без перепечатывания`;

document.getElementById('output').textContent = `Watch-выражения автоматически вычисляются при каждой остановке. Добавить: '+' в панели Watch.`;
