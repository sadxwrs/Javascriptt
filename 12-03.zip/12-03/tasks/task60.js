document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>before</code>, <code>after</code>, <code>beforeEach</code>, <code>afterEach</code> хуки в Mocha?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// TDD = Test-Driven Development
// Цикл: Red → Green → Refactor

// 1. RED: Пишем тест который ПАДАЕТ (функции ещё нет)
// it('считает сумму массива', () => {
//   expect(sum([1, 2, 3])).to.equal(6); // ❌ sum не существует
// });

// 2. GREEN: Пишем минимальный код чтобы тест прошёл
function sum(arr) {
  return arr.reduce((a, b) => a + b, 0); // ✅ тест проходит
}

// 3. REFACTOR: Улучшаем код не ломая тесты
// (в данном случае уже хорошо, рефакторить нечего)

// Ещё итерация TDD:
// RED:
// it('возвращает 0 для пустого массива', () => {
//   expect(sum([])).to.equal(0); // проверяем edge case
// });

// GREEN: код уже обрабатывает [] правильно (reduce с пустым = 0)

// Преимущества TDD:
// ✅ 100% покрытие тестами
// ✅ Код написан под тест = минимально необходимый
// ✅ Рефакторинг безопасен

console.log(sum([1, 2, 3])); // 6
console.log(sum([]));         // 0`;

document.getElementById('output').textContent = `TDD: Red (тест падает) → Green (минимальный код) → Refactor (улучшить). Всегда начинай с теста.`;
