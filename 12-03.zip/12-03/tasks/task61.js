document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое TDD (Test Driven Development)? Опиши цикл Red → Green → Refactor.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Классический пример TDD: факториал

function factorial(n) {
  if (n < 0) throw new RangeError('n не может быть отрицательным');
  if (n === 0 || n === 1) return 1;
  return n * factorial(n - 1);
}

// Тесты (Mocha/Chai стиль):
// describe('factorial', () => {
//   it('factorial(0) === 1', () => {
//     assert.strictEqual(factorial(0), 1);
//   });
//   it('factorial(1) === 1', () => {
//     assert.strictEqual(factorial(1), 1);
//   });
//   it('factorial(5) === 120', () => {
//     assert.strictEqual(factorial(5), 120);
//   });
//   it('factorial(10) === 3628800', () => {
//     assert.strictEqual(factorial(10), 3628800);
//   });
//   it('бросает RangeError для отрицательных', () => {
//     assert.throws(() => factorial(-1), RangeError);
//   });
// });

// Запуск ручных проверок:
const tests = [
  [0, 1], [1, 1], [2, 2], [3, 6], [4, 24], [5, 120]
];
tests.forEach(([n, expected]) => {
  const result = factorial(n);
  console.log(\\\`factorial(\\\${n}) = \\\${result} \\\${result === expected ? '✅' : '❌'}\\\`);
});`;

document.getElementById('output').textContent = `Для factorial тестируй: 0, 1, маленькие числа, большое число, отрицательное. Граничные случаи (edge cases) важны.`;
