document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши набор тестов для функции <code>factorial(n)</code> покрывающий edge cases: 0, 1, отрицательное.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Code Coverage — какой процент кода покрыт тестами
// nyc (Istanbul) — инструмент coverage для Mocha
// Jest — встроенный coverage

// Метрики coverage:
// Statements — строки кода выполненные хоть раз
// Branches   — все ветки if/else/ternary
// Functions  — все функции вызваны
// Lines      — все строки выполнены

// Настройка с Mocha:
// npm install --save-dev nyc
// package.json:
// "test": "nyc mocha",
// "nyc": { "reporter": ["text", "html"], "branches": 80 }

// С Jest:
// "test": "jest --coverage"
// или jest.config.js: coverageThreshold: { global: { branches: 80 } }

function processAge(age) {
  if (age < 0) return 'invalid';   // branch 1
  if (age < 18) return 'minor';    // branch 2
  if (age >= 65) return 'senior';  // branch 3
  return 'adult';                   // branch 4
}

// Для 100% branch coverage нужно тестировать все 4 ветки:
// processAge(-1)   → 'invalid'
// processAge(15)   → 'minor'
// processAge(25)   → 'adult'
// processAge(70)   → 'senior'
console.log([processAge(-1), processAge(15), processAge(25), processAge(70)]);`;

document.getElementById('output').textContent = `Coverage: Statements/Branches/Functions/Lines. nyc для Mocha, --coverage для Jest. Цель: 80%+ branch coverage.`;
