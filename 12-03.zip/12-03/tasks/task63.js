document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое test coverage? Как измерить покрытие кода тестами (например через nyc/istanbul)?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// stub  — заменяет функцию заготовленным ответом
// mock  — заменяет объект с ожиданиями (expectations)
// spy   — оборачивает функцию, записывает вызовы

// Пример с Sinon.js:
// npm install --save-dev sinon

// === SPY: наблюдаем за реальной функцией ===
// const spy = sinon.spy(console, 'log');
// console.log('hello');
// assert(spy.calledOnce);
// assert(spy.calledWith('hello'));
// spy.restore();

// === STUB: заменяем поведение ===
// const stub = sinon.stub(userService, 'getUser').returns({ id: 1, name: 'Alice' });
// const user = userService.getUser(1); // вернёт наш заглушку
// assert.equal(user.name, 'Alice');
// stub.restore();

// === MOCK: строгие ожидания ===
// const mock = sinon.mock(userService);
// mock.expects('getUser').once().withArgs(1).returns({ name: 'Bob' });
// userService.getUser(1);
// mock.verify(); // проверяет что все ожидания выполнены
// mock.restore();

// В Jest всё встроено:
// jest.spyOn(obj, 'method')
// jest.fn().mockReturnValue(42)
// jest.mock('./module')
console.log('spy = наблюдает, stub = заменяет ответ, mock = ожидания');`;

document.getElementById('output').textContent = `spy — записывает вызовы реальной функции. stub — заменяет с заготовленным ответом. mock — с ожиданиями-assertions.`;
