document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое stub и mock? Чем они отличаются? Приведи пример с Sinon.js.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Тестирование асинхронного кода в Mocha/Jest

// 1. Через callback (done):
// it('загружает данные', (done) => {
//   fetchData((err, data) => {
//     assert(!err);
//     assert(data.length > 0);
//     done(); // говорим Mocha что тест завершён
//   });
// });

// 2. Через Promise:
// it('загружает данные', () => {
//   return fetchData().then(data => {
//     assert(data.length > 0); // обязательно return Promise!
//   });
// });

// 3. Через async/await (лучший способ):
// it('загружает данные', async () => {
//   const data = await fetchData();
//   assert(data.length > 0);
// });

// Пример с fetch:
async function getUser(id) {
  const response = await fetch(\\\`https://jsonplaceholder.typicode.com/users/\\\${id}\\\`);
  return response.json();
}

// Тест:
// it('возвращает пользователя с id', async () => {
//   const user = await getUser(1);
//   expect(user).to.have.property('id', 1);
//   expect(user).to.have.property('name');
// });

// Для тестирования без реальных запросов — stub/mock fetch
console.log('async тесты: async/await лучше чем done callback');`;

document.getElementById('output').textContent = `Async тесты: 1) done callback, 2) return Promise, 3) async/await. Всегда return Promise или используй async.`;
