document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как тестировать асинхронный код в Mocha? Покажи вариант с callback и с Promise.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// it.only  — запустить ТОЛЬКО этот тест (остальные пропустить)
// it.skip  — пропустить этот тест
// describe.only, describe.skip — работают на уровне группы

// Использование:
// it.only('единственный запущенный тест', () => { ... }); // В Mocha: это.only
// it.skip('временно отключённый тест', () => { ... });

// Когда использовать only:
// - Отлаживаем конкретный тест не запуская все
// - Быстрее при разработке

// Когда использовать skip:
// - Тест временно сломан (нет времени чинить)
// - Функциональность ещё не реализована
// - Маркируем как TODO

// Пример:
// describe('UserService', () => {
//   it.skip('создаёт пользователя', () => {
//     // TODO: функция createUser ещё не реализована
//   });
//
//   it.only('находит пользователя по id', () => {
//     // Сейчас отлаживаем только это
//     const user = findUser(1);
//     expect(user.id).to.equal(1);
//   });
//
//   it('удаляет пользователя', () => {
//     // не запустится из-за only выше
//   });
// });

// ВАЖНО: не коммить .only в репозиторий!
// ESLint плагин: eslint-plugin-mocha правило no-exclusive-tests
console.log('only = только этот тест, skip = пропустить');`;

document.getElementById('output').textContent = `it.only — только этот тест. it.skip — пропустить. Не коммить .only! Используй eslint-plugin-mocha: no-exclusive-tests.`;
