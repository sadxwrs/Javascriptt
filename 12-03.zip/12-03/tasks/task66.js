document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>it.only</code> и <code>it.skip</code>? Когда их применяют?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Тестирование исключений (что функция бросает ошибку)

function divide(a, b) {
  if (typeof a !== 'number' || typeof b !== 'number') {
    throw new TypeError('Аргументы должны быть числами');
  }
  if (b === 0) throw new RangeError('Деление на ноль');
  return a / b;
}

// Mocha + assert:
// it('бросает RangeError при делении на 0', () => {
//   assert.throws(() => divide(1, 0), RangeError);
// });
// it('бросает TypeError для не-числа', () => {
//   assert.throws(() => divide('a', 2), TypeError);
// });

// Mocha + Chai expect:
// it('бросает с правильным сообщением', () => {
//   expect(() => divide(1, 0))
//     .to.throw(RangeError)
//     .with.property('message', 'Деление на ноль');
// });

// Jest:
// it('бросает RangeError', () => {
//   expect(() => divide(1, 0)).toThrow(RangeError);
//   expect(() => divide(1, 0)).toThrow('Деление на ноль');
// });

// Ручная проверка:
try {
  divide(1, 0);
} catch(e) {
  console.log(e instanceof RangeError ? '✅ Правильный тип' : '❌');
  console.log(e.message === 'Деление на ноль' ? '✅ Правильное сообщение' : '❌');
}`;

document.getElementById('output').textContent = `assert.throws(() => fn(), ErrorType). В Jest: expect(() => fn()).toThrow(Error). Оборачивай вызов в стрелочную функцию!`;
