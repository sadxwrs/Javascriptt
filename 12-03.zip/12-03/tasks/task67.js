document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши тест проверяющий что функция бросает ошибку при неверном аргументе.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Организация тестов: структура папок и файлов

// Варианты расположения тестов:
// 1. Рядом с кодом (co-location):
//    src/
//      utils/
//        math.js
//        math.test.js  ← рядом
//
// 2. Отдельная папка:
//    src/utils/math.js
//    tests/utils/math.test.js

// Соглашения по именованию:
// math.test.js    — Jest, Vitest
// math.spec.js    — Jasmine, Angular
// test-math.js    — старый стиль Mocha

// Структура test suite:
// describe('Math utilities', () => {
//   describe('add()', () => {
//     it('складывает положительные числа');
//     it('обрабатывает ноль');
//     it('работает с отрицательными');
//   });
//
//   describe('divide()', () => {
//     it('делит числа');
//     it('бросает ошибку при делении на 0');
//   });
// });

// Правила хорошей организации:
// ✅ Один файл тестов = один тестируемый модуль
// ✅ Имена тестов описывают поведение
// ✅ Тесты независимы друг от друга
// ✅ Используй beforeEach для сброса состояния

console.log('Организуй тесты: один модуль = один тест-файл');`;

document.getElementById('output').textContent = `Тест-файлы рядом с кодом или в tests/. Имя: module.test.js. Один describe на модуль, вложенные на методы.`;
