document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое test suite? Как организовать тесты в файлы и папки для большого проекта?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Snapshot testing — сохраняет 'снимок' вывода, потом сравнивает
// Удобно для: React компонентов, JSON ответов, конфигураций

// Jest пример (React):
// it('рендерит кнопку корректно', () => {
//   const tree = renderer.create(<Button label="Click me" />).toJSON();
//   expect(tree).toMatchSnapshot();
// });
// Первый запуск: создаёт __snapshots__/Button.test.js.snap
// Следующие запуски: сравнивает с сохранённым снимком

// Snapshot для JSON:
// it('возвращает правильную структуру', () => {
//   const user = createUser({ name: 'Alice', age: 25 });
//   expect(user).toMatchSnapshot();
// });

// Обновление snapshot при намеренных изменениях:
// jest --updateSnapshot  или  jest -u

// Плюсы snapshot:
// ✅ Легко создавать
// ✅ Ловит неожиданные изменения вывода

// Минусы:
// ❌ Большие снимки сложно ревьюить
// ❌ Легко обновить не подумав (jest -u)
// ❌ Не тестирует поведение, только структуру

// Альтернатива: конкретные assertions лучше для критической логики
console.log('Snapshot = фотография вывода. Удобно для UI, осторожно для логики.');`;

document.getElementById('output').textContent = `Snapshot сохраняет 'снимок' вывода. Первый запуск создаёт файл. Обновить: jest -u. Плохо для ревью больших снимков.`;
