document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое snapshot testing? Как оно работает и в чём его ограничения?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Dependency Injection (DI) — передаём зависимости снаружи, а не создаём внутри
// Делает код тестируемым (можно подставить mock)

// Плохо: зависимость жёстко встроена (сложно тестировать)
function sendEmail(to, subject) {
  const mailer = new RealMailer(); // нельзя подменить в тесте
  return mailer.send(to, subject);
}

// Хорошо: зависимость передаётся снаружи (DI)
function sendEmail(to, subject, mailer = new RealMailer()) {
  return mailer.send(to, subject);
}

// В тесте подставляем mock:
// it('отправляет письмо', () => {
//   const mockMailer = { send: sinon.stub().resolves(true) };
//   await sendEmail('test@mail.com', 'Hello', mockMailer);
//   assert(mockMailer.send.calledOnce);
//   assert(mockMailer.send.calledWith('test@mail.com', 'Hello'));
// });

// DI через параметры функции (Function DI):
function processUser(user, db = realDb, emailService = realEmailService) {
  db.save(user);
  emailService.sendWelcome(user.email);
}

// DI через конструктор класса (Constructor DI):
class OrderService {
  constructor(db, emailer) {
    this.db = db;
    this.emailer = emailer;
  }
}

console.log('DI = передавай зависимости параметром, не создавай внутри');`;

document.getElementById('output').textContent = `DI: передавай зависимости как параметры, не создавай внутри. Это позволяет подменять их в тестах на mock/stub.`;
