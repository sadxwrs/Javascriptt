document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое conditional breakpoint? Как поставить breakpoint срабатывающий только при <code>i > 5</code>?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Call Stack — стек вызовов, показывает какие функции вызвали текущую
function third() {
  debugger; // Call Stack: third -> second -> first -> (anonymous)
  console.log("Я третья функция");
}
function second() {
  third();
}
function first() {
  second();
}

first();
// В DevTools при остановке: панель Call Stack покажет:
// third (app.js:3)
// second (app.js:7)
// first (app.js:10)
// (anonymous) (app.js:13)`;

document.getElementById('output').textContent = `Call Stack показывает цепочку вызовов. Клик по фрейму — перейти к тому месту кода. Помогает понять откуда пришли.`;
