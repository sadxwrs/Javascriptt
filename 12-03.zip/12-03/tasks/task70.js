document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как тестировать функции с побочными эффектами (запросы к API, запись в БД)? Что такое dependency injection в контексте тестов?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Property-based testing — генерирует случайные входные данные и проверяет свойства
// Библиотека: fast-check (npm install fast-check)

// Вместо конкретных примеров проверяем СВОЙСТВА функции

// Обычный тест (пример-based):
// assert.equal(add(2, 3), 5);
// assert.equal(add(0, 0), 0);

// Property-based (с fast-check):
// const fc = require('fast-check');
//
// it('сложение коммутативно', () => {
//   fc.assert(
//     fc.property(fc.integer(), fc.integer(), (a, b) => {
//       return add(a, b) === add(b, a); // свойство: a+b = b+a
//     })
//   );
// });
//
// it('разворот дважды = исходный массив', () => {
//   fc.assert(
//     fc.property(fc.array(fc.integer()), (arr) => {
//       const reversed = [...arr].reverse().reverse();
//       return JSON.stringify(reversed) === JSON.stringify(arr);
//     })
//   );
// });

// fast-check генерирует сотни тестов и ищет контрпример
// Если находит — показывает минимальный failing case (shrinking)

function add(a, b) { return a + b; }

// Ручная симуляция property-based:
for (let i = 0; i < 100; i++) {
  const a = Math.floor(Math.random() * 1000) - 500;
  const b = Math.floor(Math.random() * 1000) - 500;
  if (add(a, b) !== add(b, a)) console.error(\\\`FAIL: \\\${a}, \\\${b}\\\`);
}
console.log('100 случайных пар проверены ✅');`;

document.getElementById('output').textContent = `Property-based: fast-check генерирует сотни случайных входных данных. Проверяем свойства (коммутативность, инверсию).`;
