document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое property-based testing? Как использовать fast-check с Mocha для генерации тестовых данных?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// CI/CD — автоматический запуск тестов при пуше в репозиторий
// GitHub Actions: файл .github/workflows/test.yml

// Пример .github/workflows/test.yml:
// name: Tests
//
// on:
//   push:
//     branches: [main, develop]
//   pull_request:
//     branches: [main]
//
// jobs:
//   test:
//     runs-on: ubuntu-latest
//
//     steps:
//       - uses: actions/checkout@v3
//
//       - name: Setup Node.js
//         uses: actions/setup-node@v3
//         with:
//           node-version: '20'
//           cache: 'npm'
//
//       - name: Install dependencies
//         run: npm ci
//
//       - name: Run tests
//         run: npm test
//
//       - name: Check coverage
//         run: npm run test:coverage

// package.json scripts:
// "test": "jest",
// "test:coverage": "jest --coverage --coverageThreshold='{"global":{"branches":80}}'",

console.log('CI/CD: каждый пуш/PR запускает тесты автоматически');
console.log('GitHub Actions: .github/workflows/test.yml');`;

document.getElementById('output').textContent = `GitHub Actions: .github/workflows/test.yml. Запускать при push/PR. Steps: checkout → node setup → npm ci → npm test.`;
