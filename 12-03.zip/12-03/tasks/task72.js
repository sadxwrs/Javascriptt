document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как настроить CI/CD pipeline (например GitHub Actions) для автоматического запуска Mocha-тестов на каждый push?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Полифил (polyfill) — код который реализует браузерную функцию
// для старых браузеров которые её не поддерживают

// Пример: Array.prototype.at() — добавлено в 2021
// Старые браузеры его не знают

// Полифил для Array.prototype.at:
if (!Array.prototype.at) {
  Array.prototype.at = function(index) {
    const i = Math.trunc(index) || 0;
    if (i < 0) return this[this.length + i];
    return this[i];
  };
}

// Теперь работает везде:
const arr = [1, 2, 3, 4, 5];
console.log(arr.at(0));   // 1
console.log(arr.at(-1));  // 5 (последний элемент)
console.log(arr.at(-2));  // 4

// Полифил добавляет функциональность если её нет
// Это отличает полифил от транспайлера (который меняет синтаксис)

// Где брать готовые полифилы:
// - core-js (самая полная коллекция)
// - MDN: раздел "Polyfill" у каждого метода
// - Can I Use: проверить нужен ли полифил`;

document.getElementById('output').textContent = `Полифил — реализует новую функцию для старых браузеров. Проверяет if(!feature) и добавляет. core-js — большая коллекция.`;
