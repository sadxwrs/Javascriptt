document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое полифил (polyfill)? Зачем он нужен?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// ПОЛИФИЛ — добавляет новые методы/объекты которых нет в браузере
// ТРАНСПАЙЛЕР — превращает новый СИНТАКСИС в старый

// === ПОЛИФИЛ ===
// Проблема: Array.prototype.includes нет в IE11
// Решение: добавить реализацию метода
if (!Array.prototype.includes) {
  Array.prototype.includes = function(value) {
    return this.indexOf(value) !== -1;
  };
}

// === ТРАНСПАЙЛЕР (Babel) ===
// Проблема: arrow functions не работают в IE11
// Babel превращает:
const add = (a, b) => a + b;
// В:
// var add = function(a, b) { return a + b; };

// Ключевое различие:
// Полифил:     RUNTIME — добавляет объект/метод во время выполнения
// Транспайлер: BUILDTIME — меняет синтаксис при компиляции

// Что не может транспайлер (нужен полифил):
// - Promise, fetch, Map, Set, Symbol
// - Array.from, Object.assign
// - Все новые методы массивов/строк

// Что транспайлер делает сам (без полифила):
// - Arrow functions, class, let/const
// - Destructuring, spread, template literals
// - async/await (синтаксис)

console.log([1, 2, 3].includes(2)); // true`;

document.getElementById('output').textContent = `Полифил добавляет методы в RUNTIME. Транспайлер (Babel) меняет синтаксис при BUILD. Promise нужен полифил, arrow — Babel.`;
