document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Чем полифил отличается от транспайлера (например Babel)?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Feature detection — проверяем поддержку функции ПЕРЕД использованием
// Лучше чем определение браузера (browser detection)

// Плохо: browser detection (ненадёжно, ломается)
// if (navigator.userAgent.includes('Chrome')) { ... }

// Хорошо: feature detection
// Паттерн 1: проверка существования метода
if (typeof Array.prototype.flat === 'function') {
  console.log([1, [2, 3]].flat()); // используем нативный
} else {
  console.log('flat не поддерживается — нужен полифил');
}

// Паттерн 2: try/catch для экспериментальных API
let canUseWebP = false;
try {
  canUseWebP = document.createElement('canvas')
    .toDataURL('image/webp').startsWith('data:image/webp');
} catch(e) {}

// Паттерн 3: 'in' оператор
if ('IntersectionObserver' in window) {
  console.log('Lazy loading через IntersectionObserver');
} else {
  console.log('Нужен полифил для IntersectionObserver');
}

// Библиотека Modernizr делает это за тебя:
// if (Modernizr.flexbox) { ... }

// Feature detection + полифил:
if (!Array.prototype.at) {
  Array.prototype.at = (index) => index < 0 ? this[this.length + index] : this[index];
}
console.log('Feature detection — лучшая практика');`;

document.getElementById('output').textContent = `Feature detection: проверяй if(typeof feature === 'function') перед использованием. Лучше browser detection.`;
