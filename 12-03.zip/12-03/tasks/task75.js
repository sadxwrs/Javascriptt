document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое feature detection? Как проверить поддерживает ли браузер метод перед его использованием?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Полифил для Array.prototype.includes
// Нужен для IE11 и старых мобильных браузеров

// Оригинальный метод:
// [1, 2, 3].includes(2)  // true
// [1, 2, NaN].includes(NaN)  // true (!) — отличие от indexOf

// Полифил (из MDN):
if (!Array.prototype.includes) {
  Object.defineProperty(Array.prototype, 'includes', {
    value: function(searchElement, fromIndex) {
      if (this == null) throw new TypeError('"this" is null or not defined');

      const arr = Object(this);
      const len = arr.length >>> 0; // беззнаковый сдвиг = Math.floor + >= 0

      if (len === 0) return false;

      const start = fromIndex | 0;
      let i = Math.max(start >= 0 ? start : len - Math.abs(start), 0);

      // Специальная обработка NaN (indexOf не умеет)
      function sameValueZero(x, y) {
        return x === y || (typeof x === 'number' && typeof y === 'number' && isNaN(x) && isNaN(y));
      }

      while (i < len) {
        if (sameValueZero(arr[i], searchElement)) return true;
        i++;
      }
      return false;
    },
    configurable: true,
    writable: true
  });
}

// Тест:
console.log([1, 2, 3].includes(2));    // true
console.log([1, NaN, 3].includes(NaN)); // true
console.log([1, 2, 3].includes(4));    // false`;

document.getElementById('output').textContent = `Array.includes полифил: if(!Array.prototype.includes) {...}. Важно: обработка NaN (sameValueZero, в отличие от indexOf).`;
