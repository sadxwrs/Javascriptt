document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши полифил для <code>Array.prototype.includes</code>.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// core-js — самая полная коллекция полифилов для JavaScript
// Поддерживает ES5, ES6+, Stage proposals

// Установка:
// npm install core-js

// Способ 1: подключить всё (большой бандл)
// import 'core-js/stable';

// Способ 2: только нужное (лучше для производительности)
// import 'core-js/features/array/flat';
// import 'core-js/features/promise';
// import 'core-js/features/object/assign';

// Способ 3: через Babel (автоматически, рекомендуется)
// babel.config.js:
// {
//   presets: [
//     ['@babel/preset-env', {
//       useBuiltIns: 'usage',  // автоматически добавляет нужные полифилы
//       corejs: 3,
//       targets: '> 0.5%, last 2 versions, not dead'
//     }]
//   ]
// }

// Что включает core-js:
// - Promise, Map, Set, WeakMap, WeakSet
// - Array.from, Array.of, Array.prototype.flat/flatMap
// - Object.assign, Object.entries, Object.fromEntries
// - String.prototype.includes, padStart, trimStart
// - Symbol, Iterator, Generator
// - globalThis, queueMicrotask

console.log('core-js — полифилы для всего ES6+');
console.log('Версия 3 поддерживает последние стандарты');`;

document.getElementById('output').textContent = `core-js — коллекция полифилов ES6+. Использовать с Babel useBuiltIns:usage для автоматического включения нужных.`;
