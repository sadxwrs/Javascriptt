document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое core-js? Как подключить нужные полифилы через него?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// @babel/preset-env — умный пресет Babel
// Автоматически определяет какие трансформации нужны для целевых браузеров

// Установка:
// npm install --save-dev @babel/core @babel/preset-env

// babel.config.json:
// {
//   "presets": [
//     ["@babel/preset-env", {
//       "targets": {
//         "browsers": ["> 1%", "last 2 versions", "not ie <= 11"]
//       },
//       "useBuiltIns": "usage",  // автоматически добавляет полифилы
//       "corejs": 3
//     }]
//   ]
// }

// Как работает:
// 1. Читает targets (целевые браузеры)
// 2. Проверяет что поддерживает каждый браузер
// 3. Добавляет только необходимые трансформации и полифилы

// Пример: если target поддерживает arrow functions
//   → Babel НЕ трансформирует их (оставит как есть)
// Пример: если target НЕ поддерживает async/await
//   → Babel компилирует в generator функции

// useBuiltIns опции:
// 'entry'  — подставляет полный список для targets (в entry file)
// 'usage'  — только то что реально используется в коде ✅ рекомендуется
// false    — полифилы не добавляются

const arr = [1, 2, 3];
console.log(arr.includes(2));    // Babel добавит полифил если нужно
console.log(arr.flat());          // то же самое
console.log(Object.fromEntries([['a', 1]])); // и это`;

document.getElementById('output').textContent = `@babel/preset-env: targets + useBuiltIns:usage + corejs:3. Автоматически добавляет только нужные трансформации и полифилы.`;
