document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>@babel/preset-env</code> и как он связан с полифилами?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Полифил для Array.prototype.flat (ES2019)
// flat() разворачивает вложенные массивы на указанную глубину

if (!Array.prototype.flat) {
  Array.prototype.flat = function(depth = 1) {
    // Рекурсивная вспомогательная функция
    function flatten(arr, currentDepth) {
      const result = [];
      for (const item of arr) {
        if (Array.isArray(item) && currentDepth > 0) {
          // Рекурсивно разворачиваем вложенный массив
          const nested = flatten(item, currentDepth - 1);
          result.push(...nested);
        } else {
          result.push(item);
        }
      }
      return result;
    }
    return flatten(this, depth);
  };
}

// Тесты:
const arr1 = [1, [2, 3], [4, [5, 6]]];
console.log(arr1.flat());    // [1, 2, 3, 4, [5, 6]] — глубина 1
console.log(arr1.flat(2));   // [1, 2, 3, 4, 5, 6]  — глубина 2
console.log(arr1.flat(Infinity)); // полная развёртка

const arr2 = [1, , 3]; // дырки в массиве
console.log(arr2.flat()); // [1, 3] — дырки удаляются`;

document.getElementById('output').textContent = `Полифил Array.flat: рекурсия с уменьшением depth. Дырки (holes) в массиве удаляются. Infinity — полная развёртка.`;
