document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши полифил для <code>Array.prototype.flat</code> (один уровень вложенности).<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Полифил для Object.assign (ES6)
// assign копирует enumerable own properties из источников в цель

if (typeof Object.assign !== 'function') {
  Object.defineProperty(Object, 'assign', {
    value: function assign(target, ...sources) {
      if (target == null) {
        throw new TypeError('Cannot convert undefined or null to object');
      }
      
      const to = Object(target);
      
      for (const source of sources) {
        if (source != null) {
          for (const key in source) {
            // Только собственные (не унаследованные) свойства
            if (Object.prototype.hasOwnProperty.call(source, key)) {
              to[key] = source[key];
            }
          }
        }
      }
      return to;
    },
    writable: true,
    configurable: true,
  });
}

// Тесты:
const target = { a: 1, b: 2 };
const source = { b: 4, c: 5 };
const result = Object.assign(target, source);
console.log(result);  // { a: 1, b: 4, c: 5 }
console.log(target === result); // true — изменяет target!

// Неглубокое копирование:
const copy = Object.assign({}, { a: 1 }, { b: 2 });
console.log(copy); // { a: 1, b: 2 }`;

document.getElementById('output').textContent = `Object.assign полифил: for..in + hasOwnProperty. Копирует только enumerable own свойства. Мутирует первый аргумент!`;
