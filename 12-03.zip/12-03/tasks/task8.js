document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как использовать вкладку Console для выполнения JS-кода в контексте страницы?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Conditional Breakpoint — срабатывает только при условии
// Правый клик на номере строки -> "Add conditional breakpoint"
// Вписать условие, например: i === 50 или user.name === 'admin'

const users = [
  { name: 'Alice', age: 25 },
  { name: 'admin', age: 30 }, // breakpoint сработает здесь
  { name: 'Bob', age: 22 },
];

for (let i = 0; i < users.length; i++) {
  const user = users[i]; // Условие: user.name === 'admin'
  console.log(user.name);
}
// Без условия пришлось бы жать F8 много раз`;

document.getElementById('output').textContent = `Conditional breakpoint: правый клик → Add conditional breakpoint. Срабатывает только когда условие истинно.`;
