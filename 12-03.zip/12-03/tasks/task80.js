document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши полифил для <code>Object.assign</code>.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// browserslist — конфигурация целевых браузеров
// Используется: Babel, Autoprefixer, ESLint, PostCSS

// .browserslistrc (или поле "browserslist" в package.json):
// > 1%            — браузеры с долей рынка > 1%
// last 2 versions — последние 2 версии каждого браузера
// not dead        — браузеры с поддержкой (обновления < 2 лет)
// not IE 11       — исключить IE11

// Проверить какие браузеры выбраны:
// npx browserslist

// Пример package.json:
// {
//   "browserslist": [
//     "> 0.5%",
//     "last 2 versions",
//     "Firefox ESR",
//     "not dead",
//     "not IE 11"
//   ]
// }

// Различные окружения:
// "browserslist": {
//   "production": ["> 0.2%", "not dead", "not op_mini all"],
//   "development": ["last 1 chrome version", "last 1 firefox version"]
// }

// Как Babel использует browserslist:
// @babel/preset-env читает .browserslistrc
// и добавляет только трансформации нужные для указанных браузеров

// npx browserslist выводит список всех браузеров соответствующих запросу
console.log('browserslist — один конфиг для Babel, Autoprefixer, PostCSS');`;

document.getElementById('output').textContent = `browserslist в .browserslistrc или package.json. Синтаксис: '> 1%, last 2 versions'. Babel и PostCSS читают автоматически.`;
