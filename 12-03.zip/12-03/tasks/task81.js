document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>browserslist</code>? Как он используется вместе с Babel и core-js для выбора нужных полифилов?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Полифил для Promise — основы (упрощённая версия)
// Полный полифил сложнее (см. es6-promise или core-js)

if (typeof Promise === 'undefined') {
  // Упрощённый Promise полифил:
  window.Promise = function(executor) {
    this._callbacks = [];
    this._errbacks = [];
    this._state = 'pending';
    this._value = undefined;

    const resolve = (value) => {
      if (this._state !== 'pending') return;
      this._state = 'fulfilled';
      this._value = value;
      this._callbacks.forEach(cb => cb(value));
    };

    const reject = (reason) => {
      if (this._state !== 'pending') return;
      this._state = 'rejected';
      this._value = reason;
      this._errbacks.forEach(cb => cb(reason));
    };

    executor(resolve, reject);
  };

  Promise.prototype.then = function(onFulfilled, onRejected) {
    // Упрощённо: без цепочек и microtask queue
    if (this._state === 'fulfilled') onFulfilled && onFulfilled(this._value);
    if (this._state === 'rejected') onRejected && onRejected(this._value);
    if (this._state === 'pending') {
      onFulfilled && this._callbacks.push(onFulfilled);
      onRejected && this._errbacks.push(onRejected);
    }
    return this;
  };
}

// Для реального использования: npm install es6-promise или core-js
console.log('Promise полифил: нужны resolve/reject/then/catch/finally + статические методы');`;

document.getElementById('output').textContent = `Promise полифил сложен: нужен microtask queue, цепочки. Для продакшена: core-js/features/promise или es6-promise.`;
