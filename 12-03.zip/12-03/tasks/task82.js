document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши полифил для <code>Promise</code> — опиши какие методы нужно реализовать и в каком порядке.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// useBuiltIns: 'usage' — Babel автоматически добавляет полифилы
// Только для методов реально используемых в коде

// babel.config.json:
// {
//   "presets": [
//     ["@babel/preset-env", {
//       "useBuiltIns": "usage",
//       "corejs": { "version": 3, "proposals": true }
//     }]
//   ]
// }

// В коде используем без явного импорта:
const arr = [1, [2, [3]]];
arr.flat(2); // Babel увидит flat и добавит полифил если нужно для targets

const map = new Map([['a', 1]]);
map.set('b', 2); // Babel добавит полифил Map если нужно

// Babel автоматически вставит в начало бандла:
// import "core-js/modules/es.array.flat";
// import "core-js/modules/es.map";

// Отличие от useBuiltIns: 'entry':
// 'entry': нужно вручную написать import 'core-js'; в entry point
//          добавляет ВСЕ полифилы для targets (большой бандл)
// 'usage': анализирует код и добавляет ТОЛЬКО используемые (меньше бандл) ✅

// corejs: 3 — использовать core-js версии 3 (актуальная)

console.log('useBuiltIns:usage = автоматические точечные полифилы');
console.log(arr.flat(2)); // [1, 2, 3]`;

document.getElementById('output').textContent = `useBuiltIns:usage анализирует код и добавляет только нужные полифилы. Меньше бандл чем entry. Нужен corejs:3.`;
