document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое "useBuiltIns: usage" в Babel? Как это влияет на автоматическое добавление полифилов?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Полифил — реализует СТАНДАРТНЫЙ API который должен быть в браузере
// Шим (shim) — любая библиотека-адаптер, не обязательно стандарт

// ПОЛИФИЛ: добавляет стандартный метод Array.prototype.flat
if (!Array.prototype.flat) {
  Array.prototype.flat = function(depth = 1) {
    return depth > 0
      ? this.reduce((acc, val) => acc.concat(Array.isArray(val) ? val.flat(depth - 1) : val), [])
      : this.slice();
  };
}

// ШИМ: нестандартный адаптер (например, es5-shim для старых браузеров)
// Шим может добавлять нестандартные методы или адаптировать поведение

// Примеры шимов:
// - html5shiv  — шим для HTML5 элементов в IE
// - es5-shim   — шим для ES5 методов
// - Modernizr  — шим обнаружения возможностей

// Основное различие:
// Полифил:  реализует ТОЧНУЮ спецификацию браузерного API
// Шим:      любой адаптер/прокладка, может отличаться от спецификации

// Пример: jQuery.ajax — ЭТО ШИМ (не полифил fetch)
// а вот github.com/github/fetch — ПОЛИФИЛ (реализует спецификацию fetch)

console.log([1, [2, [3]]].flat(2)); // [1, 2, 3]
console.log('Полифил = стандарт, шим = любой адаптер');`;

document.getElementById('output').textContent = `Полифил реализует точную спецификацию стандартного API. Шим — любой адаптер/прокладка (может быть нестандартным).`;
