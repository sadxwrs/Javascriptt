document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Чем полифил отличается от шима (shim)? Приведи пример каждого.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Полифил для Array.prototype.flatMap (ES2019)
// flatMap = map + flat(1) — только на один уровень

if (!Array.prototype.flatMap) {
  Array.prototype.flatMap = function(callback, thisArg) {
    if (typeof callback !== 'function') {
      throw new TypeError(callback + ' is not a function');
    }
    
    const result = [];
    const arr = this;
    
    for (let i = 0; i < arr.length; i++) {
      const mapped = callback.call(thisArg, arr[i], i, arr);
      
      if (Array.isArray(mapped)) {
        // Разворачиваем только один уровень
        for (const item of mapped) {
          result.push(item);
        }
      } else {
        result.push(mapped);
      }
    }
    
    return result;
  };
}

// Тесты:
const sentences = ['hello world', 'foo bar'];
const words = sentences.flatMap(s => s.split(' '));
console.log(words); // ['hello', 'world', 'foo', 'bar']

// Полезно для фильтрации + трансформации:
const numbers = [1, 2, 3, 4];
const result = numbers.flatMap(x => x % 2 === 0 ? [x, x * 2] : []);
console.log(result); // [2, 4, 4, 8]`;

document.getElementById('output').textContent = `Array.flatMap = map + flat(1). Полифил: map каждый элемент, если Array — разворачиваем один уровень, иначе просто добавляем.`;
