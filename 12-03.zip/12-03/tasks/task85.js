document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши полифил для <code>Array.prototype.flatMap</code>.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// globalThis — универсальная ссылка на глобальный объект (ES2020)
// В браузере: window, в Node.js: global, в Worker: self

// Полифил для globalThis:
if (typeof globalThis === 'undefined') {
  // Метод 1: через Function
  (function() {
    Object.defineProperty(Object.prototype, '__globalThis__', {
      get: function() { return this; },
      configurable: true,
    });
    const g = __globalThis__;
    delete Object.prototype.__globalThis__;
    if (typeof g.globalThis === 'undefined') {
      g.globalThis = g;
    }
  })();
}

// Более простой полифил:
if (typeof globalThis === 'undefined') {
  const getGlobal = new Function('return this')();
  // new Function создаёт функцию в глобальном scope
  if (typeof getGlobal.globalThis === 'undefined') {
    getGlobal.globalThis = getGlobal;
  }
}

// Зачем нужен globalThis:
function log(message) {
  // Работает в браузере, Node.js и Worker без проверок
  globalThis.console.log(message);
}

// Без globalThis приходилось:
// const g = typeof window !== 'undefined' ? window
//         : typeof global !== 'undefined' ? global
//         : typeof self !== 'undefined' ? self : this;

console.log(typeof globalThis); // 'object'
console.log(globalThis === globalThis.globalThis); // true`;

document.getElementById('output').textContent = `globalThis — универсальный глобальный объект. Полифил: new Function('return this')(). Заменяет window/global/self.`;
