document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши полифил для <code>globalThis</code> работающий в браузере, Node.js и Web Worker.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Scoped polyfill — полифил без загрязнения глобального scope
// Добавляет функциональность как локальную утилиту, не меняя прототипы

// Проблема обычного полифила:
// Array.prototype.flat = ... // меняет глобальный прототип!
// Конфликт если другая библиотека тоже патчит flat

// Scoped polyfill — импортируем функцию-обёртку:
// import flat from 'array.prototype.flat/polyfill';
// flat([1, [2, 3]]); // используем как функцию

// Пример scoped полифила для Array.flat:
function arrayFlat(arr, depth = 1) {
  if (depth <= 0) return arr.slice();
  return arr.reduce((result, item) => {
    if (Array.isArray(item)) {
      return result.concat(arrayFlat(item, depth - 1));
    }
    return result.concat(item);
  }, []);
}

// Scoped полифил для Object.assign:
function objectAssign(target, ...sources) {
  if (target == null) throw new TypeError('Target cannot be null');
  const to = Object(target);
  for (const source of sources) {
    if (source != null) {
      for (const key of Object.keys(source)) {
        to[key] = source[key];
      }
    }
  }
  return to;
}

// Используем как функции — не трогаем глобальные объекты
console.log(arrayFlat([1, [2, [3]]], 2));   // [1, 2, 3]
console.log(objectAssign({}, { a: 1 }, { b: 2 })); // {a:1, b:2}
console.log('Scoped полифил = без глобальных побочных эффектов');`;

document.getElementById('output').textContent = `Scoped polyfill: функция-утилита вместо патча прототипа. Нет конфликтов с другими библиотеками. Импортируй явно.`;
