document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как правильно добавить полифил не загрязняя глобальный скоп? Что такое "scoped polyfill"?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Задание 87
console.log('Решение');`;

document.getElementById('output').textContent = `Задание 87`;
