document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое Call Stack в DevTools? Как по нему понять последовательность вызовов?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// console.table() выводит массив объектов в виде красивой таблицы
const products = [
  { name: 'Apple',  price: 1.5,  count: 100 },
  { name: 'Banana', price: 0.8,  count: 250 },
  { name: 'Cherry', price: 3.2,  count: 50  },
];

console.table(products);
// Выведет таблицу с колонками: (index), name, price, count

// Можно указать только нужные колонки:
console.table(products, ['name', 'price']);

// Работает и с простыми массивами:
console.table([1, 2, 3]);`;

document.getElementById('output').textContent = `console.table() выводит массив объектов как HTML-таблицу. Удобнее для чтения чем console.log массива.`;
