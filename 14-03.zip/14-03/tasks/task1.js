document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Создай объект user с полями name, age, isAdmin и выведи каждое поле.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const user = {
  name: 'Анна',
  age: 25,
  isAdmin: true
};

console.log(user.name);    // 'Анна'
console.log(user.age);     // 25
console.log(user.isAdmin); // true`;

document.getElementById('output').textContent = `user.name    => 'Анна'
user.age     => 25
user.isAdmin => true`;
