document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как получить массив всех ключей объекта? Как получить массив всех значений?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const scores = { alice: 95, bob: 72, carol: 88 };

// Ключи:
const keys = Object.keys(scores);
console.log(keys); // ['alice', 'bob', 'carol']

// Значения:
const values = Object.values(scores);
console.log(values); // [95, 72, 88]

// Пары:
const entries = Object.entries(scores);
console.log(entries); // [['alice',95],['bob',72],['carol',88]]

// Практика:
const avg = values.reduce((s, v) => s + v, 0) / values.length;
console.log(avg); // 85`;

document.getElementById('output').textContent = `Object.keys(scores)    => ['alice','bob','carol']
Object.values(scores)  => [95,72,88]
Object.entries(scores) => [['alice',95],['bob',72],['carol',88]]
Средний балл: 85`;
