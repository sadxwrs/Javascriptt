document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Чем Symbol.for('id') отличается от Symbol('id')?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Symbol('id') — локальный, ВСЕГДА новый:
const a = Symbol('id');
const b = Symbol('id');
console.log(a === b); // false (всегда разные!)

// Symbol.for('id') — глобальный реестр, НЕ дублируется:
const c = Symbol.for('id');
const d = Symbol.for('id');
console.log(c === d); // true (один и тот же!)

console.log(a === c); // false (локальный vs глобальный)

// Использование:
// Symbol()     — приватные ключи внутри модуля
// Symbol.for() — публичные ключи для межмодульного взаимодействия
console.log(Symbol.keyFor(c)); // 'id'
console.log(Symbol.keyFor(a)); // undefined`;

document.getElementById('output').textContent = `Symbol('id') === Symbol('id') => false (всегда новый)
Symbol.for('id') === Symbol.for('id') => true (реестр)
Symbol('id') === Symbol.for('id') => false
Разница: for() — глобальный, Symbol() — локальный`;
