document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как использовать Symbol в качестве ключа объекта? Покажи пример.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const ID = Symbol('id');
const SECRET = Symbol('secret');

const user = {
  name: 'Петя',
  age: 30,
  [ID]: 12345,          // Symbol-ключ
  [SECRET]: 'qwerty123' // Symbol-ключ
};

console.log(user[ID]);      // 12345
console.log(user[SECRET]);  // 'qwerty123'

// Symbol-ключи НЕ видны в обычном переборе:
console.log(Object.keys(user));   // ['name', 'age']
console.log(JSON.stringify(user)); // {"name":"Петя","age":30} — без Symbol!

// Получить Symbol-ключи:
console.log(Object.getOwnPropertySymbols(user)); // [Symbol(id), Symbol(secret)]`;

document.getElementById('output').textContent = `user[ID] => 12345
user[SECRET] => 'qwerty123'
Object.keys(user) => ['name','age'] (Symbol скрыты!)
JSON.stringify(user) => нет Symbol-свойств
Object.getOwnPropertySymbols(user) => [Symbol(id), Symbol(secret)]`;
