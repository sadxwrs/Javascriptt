document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Почему Symbol-свойства не видны в for...in и Object.keys()?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const LOG = Symbol('log');
const user = {
  name: 'Рита',
  age: 25,
  [LOG]: 'internal log data'
};

// for...in — не видит Symbol:
for (const key in user) {
  console.log(key); // 'name', 'age' — LOG нет!
}

// Object.keys — не видит Symbol:
console.log(Object.keys(user));   // ['name', 'age']
console.log(Object.values(user)); // ['Рита', 25]

// Это НАМЕРЕННО: Symbol созданы для приватных/системных ключей
// которые не должны мешать обычному перебору

// Всё Symbol-ключи:
console.log(Object.getOwnPropertySymbols(user)); // [Symbol(log)]

// Все ключи включая Symbol:
console.log(Reflect.ownKeys(user)); // ['name','age',Symbol(log)]`;

document.getElementById('output').textContent = `for...in пропускает Symbol-ключи
Object.keys/values/entries — тоже не видят Symbol
Цель: Symbol для служебных/приватных данных без конфликтов
Object.getOwnPropertySymbols => только Symbol-ключи
Reflect.ownKeys => ВСЕ ключи включая Symbol`;
