document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как получить все Symbol-ключи объекта? Какой метод для этого используется?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const A = Symbol('a');
const B = Symbol('b');

const obj = {
  regular: 'обычное',
  [A]: 'значение A',
  [B]: 'значение B'
};

// Только Symbol-ключи:
const symbols = Object.getOwnPropertySymbols(obj);
console.log(symbols);         // [Symbol(a), Symbol(b)]
console.log(symbols.length);  // 2

// Читаем значения:
symbols.forEach(sym => {
  console.log(sym.description, ':', obj[sym]);
});
// 'a : значение A'
// 'b : значение B'

// Все ключи (обычные + Symbol):
console.log(Reflect.ownKeys(obj));
// ['regular', Symbol(a), Symbol(b)]`;

document.getElementById('output').textContent = `Object.getOwnPropertySymbols(obj) => [Symbol(a), Symbol(b)]
obj[Symbol(a)] => 'значение A'
Reflect.ownKeys(obj) => ['regular', Symbol(a), Symbol(b)] (всё)
for...in и Object.keys — только обычные ключи`;
