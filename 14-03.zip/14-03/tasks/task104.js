document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое well-known Symbols? Перечисли 5 наиболее используемых.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Well-known Symbols — встроенные Symbol для кастомизации поведения

// 1. Symbol.iterator — кастомная итерация
const range = {
  from: 1, to: 3,
  [Symbol.iterator]() {
    let cur = this.from;
    return { next: () => cur <= this.to
      ? { value: cur++, done: false }
      : { done: true } };
  }
};
console.log([...range]); // [1, 2, 3]

// 2. Symbol.toPrimitive — преобразование к примитиву
// 3. Symbol.hasInstance — кастомный instanceof
// 4. Symbol.asyncIterator — асинхронная итерация
// 5. Symbol.toStringTag — кастомный тег Object.prototype.toString

const myObj = { [Symbol.toStringTag]: 'MyObject' };
console.log(Object.prototype.toString.call(myObj)); // '[object MyObject]'`;

document.getElementById('output').textContent = `Well-known Symbols — встроенные Symbol для кастомизации:
1. Symbol.iterator — кастомная итерация (for...of)
2. Symbol.toPrimitive — преобразование к примитиву
3. Symbol.hasInstance — кастомный instanceof
4. Symbol.asyncIterator — for await...of
5. Symbol.toStringTag — кастомный тег toString
[...range] => [1,2,3]`;
