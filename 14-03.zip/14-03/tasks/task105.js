document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое Symbol.iterator? Реализуй кастомный итератор для объекта через этот Symbol.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const countdown = {
  start: 5,
  [Symbol.iterator]() {
    let current = this.start;
    return {
      next() {
        if (current >= 0) {
          return { value: current--, done: false };
        }
        return { value: undefined, done: true };
      }
    };
  }
};

// for...of:
for (const n of countdown) {
  process.stdout.write(n + ' ');
}
// 5 4 3 2 1 0

// spread:
console.log([...countdown]); // [5, 4, 3, 2, 1, 0]

// деструктуризация:
const [first, second] = countdown;
console.log(first, second); // 5 4`;

document.getElementById('output').textContent = `for...of countdown => 5 4 3 2 1 0
[...countdown] => [5,4,3,2,1,0]
const [first, second] = countdown => first=5, second=4
Symbol.iterator позволяет любому объекту быть итерируемым`;
