document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое Symbol.toPrimitive? Напиши объект с кастомным преобразованием в примитив.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const money = {
  amount: 100,
  currency: 'RUB',

  [Symbol.toPrimitive](hint) {
    if (hint === 'number') return this.amount;
    if (hint === 'string') return \`\${this.amount} \${this.currency}\`;
    // default — для + и ==
    return this.amount;
  }
};

console.log(+money);          // 100  (number hint)
console.log(\`\${money}\`);      // '100 RUB' (string hint)
console.log(money + 50);      // 150  (default hint)
console.log(money > 99);      // true (number comparison)

// Три hint: 'number', 'string', 'default'
console.log(String(money));   // '100 RUB'`;

document.getElementById('output').textContent = `+money          => 100  (hint: 'number')
\`\${money}\`       => '100 RUB' (hint: 'string')
money + 50       => 150 (hint: 'default')
money > 99       => true
String(money)    => '100 RUB'
Hint принимает: 'number', 'string', 'default'`;
