document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое Symbol.hasInstance? Как переопределить поведение instanceof?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `class EvenNumber {
  static [Symbol.hasInstance](instance) {
    // instanceof EvenNumber вернёт true для чётных чисел
    return typeof instance === 'number' && instance % 2 === 0;
  }
}

console.log(2  instanceof EvenNumber); // true
console.log(4  instanceof EvenNumber); // true
console.log(3  instanceof EvenNumber); // false
console.log(7  instanceof EvenNumber); // false
console.log('2' instanceof EvenNumber); // false (строка)

// Аналог для массивоподобных:
class ArrayLike {
  static [Symbol.hasInstance](instance) {
    return Array.isArray(instance) ||
           (instance !== null && typeof instance === 'object' && 'length' in instance);
  }
}

console.log([] instanceof ArrayLike);          // true
console.log({length: 3} instanceof ArrayLike); // true
console.log({} instanceof ArrayLike);          // false`;

document.getElementById('output').textContent = `2 instanceof EvenNumber => true
4 instanceof EvenNumber => true
3 instanceof EvenNumber => false
[] instanceof ArrayLike => true
{length:3} instanceof ArrayLike => true
Symbol.hasInstance позволяет переопределить логику instanceof`;
