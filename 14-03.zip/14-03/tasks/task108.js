document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое Symbol.species? Как он влияет на поведение методов вроде map() в наследниках массива?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `class PowerArray extends Array {
  sum() {
    return this.reduce((acc, v) => acc + v, 0);
  }

  // Без Symbol.species:
  // map/filter вернут PowerArray
  // С Symbol.species = Array:
  // map/filter вернут обычный Array
  static get [Symbol.species]() {
    return Array; // map/filter создают обычные массивы
  }
}

const pa = new PowerArray(1, 2, 3, 4, 5);
console.log(pa.sum()); // 15

const mapped = pa.map(x => x * 2);
console.log(mapped instanceof PowerArray); // false!
console.log(mapped instanceof Array);      // true

// Без Symbol.species:
// mapped instanceof PowerArray => true`;

document.getElementById('output').textContent = `pa.sum() => 15 (собственный метод)
pa.map(x=>x*2) — возвращает обычный Array (из-за Symbol.species)
mapped instanceof PowerArray => false
mapped instanceof Array => true
Без Symbol.species map вернул бы PowerArray`;
