document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй приватные свойства объекта через Symbol (до появления приватных полей классов #field).<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Паттерн: Symbol как приватный ключ
const _password = Symbol('password');
const _validate = Symbol('validate');

function createUser(name, password) {
  const user = {
    name,
    [_password]: password,

    [_validate](pwd) {
      return pwd === this[_password];
    },

    login(pwd) {
      if (this[_validate](pwd)) {
        return \`\${this.name} авторизован!\`;
      }
      return 'Неверный пароль';
    }
  };
  return user;
}

const user = createUser('Маша', 'secret123');
console.log(user.login('wrong'));      // 'Неверный пароль'
console.log(user.login('secret123')); // 'Маша авторизован!'
console.log(user[_password]);          // 'secret123' (доступно по ключу)
console.log(Object.keys(user));        // ['name','login'] (Symbol скрыт!)`;

document.getElementById('output').textContent = `user.login('wrong')      => 'Неверный пароль'
user.login('secret123') => 'Маша авторизован!'
user[_password]          => 'secret123' (по Symbol-ключу)
Object.keys(user)        => ['name','login'] (Symbol не видны)
Symbol — 'полуприватные': снаружи не видны, но доступны по ключу`;
