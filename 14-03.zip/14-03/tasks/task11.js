document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как получить массив пар [ключ, значение] из объекта?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const config = { host: 'localhost', port: 3000, debug: true };

const pairs = Object.entries(config);
console.log(pairs);
// [['host','localhost'],['port',3000],['debug',true]]

// Обратное преобразование:
const restored = Object.fromEntries(pairs);
console.log(restored);
// { host:'localhost', port:3000, debug:true }

// Применение: трансформация объекта
const upper = Object.fromEntries(
  Object.entries(config).map(([k, v]) => [k.toUpperCase(), v])
);
console.log(upper); // { HOST:'localhost', PORT:3000, DEBUG:true }`;

document.getElementById('output').textContent = `Object.entries(config) => [['host','localhost'],['port',3000],['debug',true]]
Object.fromEntries(pairs) => восстанавливает объект обратно
Паттерн трансформации: entries => map => fromEntries`;
