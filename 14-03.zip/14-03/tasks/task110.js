document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое Symbol.asyncIterator? Реализуй объект поддерживающий for await...of.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Symbol.asyncIterator — для асинхронной итерации

const asyncRange = {
  from: 1,
  to: 5,

  [Symbol.asyncIterator]() {
    let current = this.from;
    const last = this.to;
    return {
      async next() {
        // Симуляция задержки (fetch, БД и т.д.)
        await new Promise(r => setTimeout(r, 10));
        if (current <= last) {
          return { value: current++, done: false };
        }
        return { value: undefined, done: true };
      }
    };
  }
};

async function main() {
  for await (const num of asyncRange) {
    process.stdout.write(num + ' ');
  }
  // 1 2 3 4 5 (с задержками)
}
main();`;

document.getElementById('output').textContent = `Symbol.asyncIterator — для for await...of
Каждый next() — асинхронная операция (Promise)
for await (const num of asyncRange) => 1 2 3 4 5
Применяется для: потоков данных, пагинации API, WebSocket`;
