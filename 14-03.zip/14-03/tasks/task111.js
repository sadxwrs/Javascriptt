document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое преобразование объекта в примитив? В каких ситуациях оно происходит?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const obj = { value: 42 };

// Ситуации преобразования:
// 1. Математические операции:
console.log(obj - 0);     // NaN (нет valueOf/toString возвращающих число)

// 2. Строковый контекст:
console.log(\`\${obj}\`);    // '[object Object]'
console.log(String(obj)); // '[object Object]'

// 3. Сравнения:
console.log(obj == 42);   // false

// С кастомными методами:
const smart = {
  value: 100,
  toString() { return \`Объект(\${this.value})\`; },
  valueOf()  { return this.value; }
};

console.log(smart + 0);   // 100 (valueOf)
console.log(\`\${smart}\`);  // 'Объект(100)' (toString)`;

document.getElementById('output').textContent = `Ситуации преобразования объекта в примитив:
1. Математика: obj - 0 => NaN (стандартный)
2. Строка: \`\${obj}\` => '[object Object]'
3. Сравнение: obj == 42 => false
С valueOf: smart + 0 => 100
С toString: \`\${smart}\` => 'Объект(100)'`;
