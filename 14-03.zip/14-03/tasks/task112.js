document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое hint в алгоритме ToPrimitive? Какие три значения он принимает?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const obj = {
  [Symbol.toPrimitive](hint) {
    console.log('hint:', hint);
    if (hint === 'number') return 42;
    if (hint === 'string') return 'строка';
    return true; // default
  }
};

// number hint — математические операции:
+obj;          // hint: number => 42
obj - 5;       // hint: number => 42
obj * 2;       // hint: number

// string hint — шаблонные строки, String():
\`\${obj}\`;      // hint: string => 'строка'
String(obj);   // hint: string

// default hint — == и + с другим значением:
obj + '';      // hint: default => true
obj == 1;      // hint: default`;

document.getElementById('output').textContent = `ToPrimitive hint — три значения:
'number' — +obj, obj-5, obj*2, сравнение с числом
'string' — \`\${obj}\`, String(obj), alert(obj)
'default' — obj+"", obj==1, obj+otherValue
Symbol.toPrimitive получает hint первым аргументом`;
