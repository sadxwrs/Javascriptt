document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое метод toString() объекта? Когда он вызывается автоматически?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Стандартный toString:
const plain = {};
console.log(plain.toString()); // '[object Object]'

// Кастомный toString:
const point = {
  x: 3,
  y: 4,
  toString() {
    return \`Point(\${this.x}, \${this.y})\`;
  }
};

// Вызывается автоматически при:
// 1. Шаблонных строках:
console.log(\`\${point}\`);       // 'Point(3, 4)'

// 2. String():
console.log(String(point));    // 'Point(3, 4)'

// 3. Конкатенации (если нет valueOf):
console.log(point + '!');      // 'Point(3, 4)!'

// 4. alert(point) в браузере`;

document.getElementById('output').textContent = `Стандартный: {}.toString() => '[object Object]'
Кастомный point.toString() => 'Point(3, 4)'
Автовызов при: \`\${point}\` => 'Point(3, 4)'   String(point) => 'Point(3, 4)'   point+'!' => 'Point(3, 4)!'`;
