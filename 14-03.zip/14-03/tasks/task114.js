document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое метод valueOf()? Когда он вызывается при преобразовании?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const product = {
  name: 'Ноутбук',
  price: 50000,

  valueOf() {
    return this.price; // числовое представление
  },

  toString() {
    return \`\${this.name} (\${this.price} руб.)\`;
  }
};

// valueOf вызывается в числовом контексте:
console.log(+product);          // 50000
console.log(product - 10000);   // 40000
console.log(product > 30000);   // true
console.log(product * 2);       // 100000

// toString вызывается в строковом:
console.log(\`\${product}\`);      // 'Ноутбук (50000 руб.)'
console.log(String(product));   // 'Ноутбук (50000 руб.)'`;

document.getElementById('output').textContent = `+product       => 50000 (valueOf)
product - 10000 => 40000
product > 30000 => true
\`\${product}\`    => 'Ноутбук (50000 руб.)' (toString)
valueOf — числовой контекст, toString — строковый`;
