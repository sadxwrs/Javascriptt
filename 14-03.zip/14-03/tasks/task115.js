document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что вернёт String({})? Почему?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `console.log(String({}));         // '[object Object]'
console.log(String({ a: 1 }));   // '[object Object]'
console.log(String([]));         // '' (пустая строка!)
console.log(String([1, 2, 3]));  // '1,2,3'

// Почему '[object Object]'?
// JS вызывает {}.toString() => '[object Object]'
// [object <тип>] — стандартный формат

// Object.prototype.toString.call:
console.log(Object.prototype.toString.call({}));  // '[object Object]'
console.log(Object.prototype.toString.call([]));  // '[object Array]'
console.log(Object.prototype.toString.call(null)); // '[object Null]'

// Кастомный тег:
const myObj = { [Symbol.toStringTag]: 'MyClass' };
console.log(String(myObj)); // '[object Object]' (toString переопределён не был)
console.log(Object.prototype.toString.call(myObj)); // '[object MyClass]'`;

document.getElementById('output').textContent = `String({})    => '[object Object]'
String([])    => '' (пустая строка!)
String([1,2,3]) => '1,2,3'
Объект вызывает Object.prototype.toString() => '[object Object]'
Object.prototype.toString.call(null) => '[object Null]'`;
