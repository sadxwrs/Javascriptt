document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое Symbol.toPrimitive? Напиши объект у которого при числовом контексте возвращается 42, при строковом — 'объект'.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const magic = {
  [Symbol.toPrimitive](hint) {
    switch (hint) {
      case 'number':  return 42;
      case 'string':  return 'объект';
      case 'default': return 'дефолт';
    }
  }
};

// Числовой контекст:
console.log(+magic);      // 42
console.log(magic * 2);   // 84
console.log(magic - 10);  // 32

// Строковый контекст:
console.log(\`\${magic}\`);  // 'объект'
console.log(String(magic)); // 'объект'

// Дефолтный контекст:
console.log(magic + ''); // 'дефолт'
console.log(magic == 42); // false (default hint сравнение)`;

document.getElementById('output').textContent = `+magic      => 42  (hint: number)
magic * 2   => 84
\`\${magic}\`  => 'объект' (hint: string)
magic + ''  => 'дефолт' (hint: default)
Symbol.toPrimitive — высший приоритет над valueOf/toString`;
