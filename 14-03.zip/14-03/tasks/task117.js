document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Какой приоритет у методов Symbol.toPrimitive, valueOf, toString при преобразовании?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const obj = {
  [Symbol.toPrimitive](hint) {
    console.log('toPrimitive:', hint);
    return 1;
  },
  valueOf() {
    console.log('valueOf');
    return 2;
  },
  toString() {
    console.log('toString');
    return '3';
  }
};

// Symbol.toPrimitive всегда выигрывает:
+obj; // 'toPrimitive: number'

// Без Symbol.toPrimitive:
const obj2 = {
  valueOf() { console.log('valueOf'); return 2; },
  toString() { console.log('toString'); return '3'; }
};
+obj2;         // 'valueOf' (для number/default)
\`\${obj2}\`;     // 'toString' (для string) — если valueOf вернёт не примитив`;

document.getElementById('output').textContent = `Приоритет:
1. Symbol.toPrimitive (если есть) — всегда
2. valueOf — для hint: number и default
3. toString — для hint: string (или если valueOf вернул объект)
Если все три не дали примитив — TypeError`;
