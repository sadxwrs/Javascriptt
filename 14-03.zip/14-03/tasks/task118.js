document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что происходит при obj + ''? Какие методы вызываются и в каком порядке?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const obj = {
  valueOf()  { console.log('valueOf');  return 42; },
  toString() { console.log('toString'); return 'текст'; }
};

// obj + '' — hint: 'default'
// 1. Нет Symbol.toPrimitive
// 2. valueOf() — возвращает 42 (примитив) => используется!
console.log(obj + ''); // 'valueOf' => '42' (число + строка)

// Если valueOf вернёт объект — будет вызван toString:
const obj2 = {
  valueOf()  { return {}; }, // не примитив!
  toString() { return 'резерв'; }
};
console.log(obj2 + ''); // 'резерв' (valueOf не сработал)

// Итог шагов для obj + '':
// 1. hint = 'default'
// 2. Symbol.toPrimitive? нет
// 3. valueOf() => 42 => примитив => 42 + '' = '42'`;

document.getElementById('output').textContent = `obj + '' (hint: 'default'):
1. Symbol.toPrimitive? нет
2. valueOf() => 42 (примитив!)
3. 42 + '' => '42'
Если valueOf вернёт объект — вызовется toString
Результат: 'valueOf' => '42'`;
