document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши объект money с полями amount и currency, который красиво преобразуется в строку и в число.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `class Money {
  constructor(amount, currency = 'RUB') {
    this.amount = amount;
    this.currency = currency;
  }

  [Symbol.toPrimitive](hint) {
    if (hint === 'number') return this.amount;
    if (hint === 'string') return \`\${this.amount} \${this.currency}\`;
    return this.amount; // default — числовой
  }

  add(other) {
    const otherAmount = +other;
    return new Money(this.amount + otherAmount, this.currency);
  }
}

const price = new Money(100);
const tax   = new Money(20);

console.log(+price);            // 100
console.log(\`\${price}\`);        // '100 RUB'
console.log(price + tax);       // 120 (default hint)
console.log(price.add(tax));    // Money {amount:120}
console.log(\`Итого: \${price.add(tax)}\`); // 'Итого: 120 RUB'`;

document.getElementById('output').textContent = `+price         => 100 (числовой)
\`\${price}\`     => '100 RUB' (строковый)
price + tax    => 120 (default)
price.add(tax) => Money {amount:120}
\`Итого: \${price.add(tax)}\` => 'Итого: 120 RUB'`;
