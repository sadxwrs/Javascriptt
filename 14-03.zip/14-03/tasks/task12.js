document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Создай объект с вложенным объектом и обратись к свойству вложенного объекта.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const user = {
  name: 'Катя',
  address: {
    city: 'Питер',
    street: 'Невский пр.',
    zip: '190000'
  }
};

console.log(user.address.city);   // 'Питер'
console.log(user.address.street); // 'Невский пр.'
console.log(user['address']['zip']); // '190000'

// Деструктуризация:
const { address: { city } } = user;
console.log(city); // 'Питер'`;

document.getElementById('output').textContent = `user.address.city      => 'Питер'
user.address.street    => 'Невский пр.'
user['address']['zip'] => '190000'
Деструктуризация: const { address: { city } } = user => city='Питер'`;
