document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что происходит при сложении двух объектов obj1 + obj2? Разбери шаги алгоритма.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `const a = { valueOf() { return 3; } };
const b = { valueOf() { return 7; } };

console.log(a + b); // 10

// Шаги алгоритма a + b:
// 1. Вычислить примитив для a: hint='default' => valueOf() => 3
// 2. Вычислить примитив для b: hint='default' => valueOf() => 7
// 3. Если оба числа — сложить: 3 + 7 = 10
// 4. Если хоть одно строка — конкатенация

const c = { toString() { return 'привет'; } };
const d = { toString() { return ' мир'; } };
console.log(c + d); // 'привет мир' (строки => конкатенация)

// Смешанный случай:
const e = { valueOf() { return 5; } };
const f = { toString() { return '!'; } };
// e: valueOf=>5(число), f: нет valueOf, toString=>'!'(строка)
console.log(e + f); // '5!' (число+строка => конкатенация)`;

document.getElementById('output').textContent = `a+b (оба valueOf=>числа): 3+7 => 10
c+d (оба toString=>строки): 'привет'+' мир' => 'привет мир'
e+f (число+строка): 5+'!' => '5!' (конкатенация)
Алгоритм: ToPrimitive(default) для каждого, затем + по правилам JS`;
