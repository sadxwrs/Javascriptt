document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй объект range который можно использовать в арифметике: range + 5 добавляет 5 к конечному значению диапазона.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `class Range {
  constructor(from, to) {
    this.from = from;
    this.to   = to;
  }

  [Symbol.toPrimitive](hint) {
    if (hint === 'number')  return this.to - this.from; // длина диапазона
    if (hint === 'string')  return \`[\${this.from}..\${this.to}]\`;
    return this.to; // default — возвращаем конец диапазона
  }

  // Кастомное сложение:
  [Symbol.toPrimitive] = function(hint) {
    if (hint === 'default') return this.to;
    if (hint === 'number')  return this.to - this.from;
    return \`[\${this.from}..\${this.to}]\`;
  };
}

const r = new Range(1, 10);
console.log(\`\${r}\`);    // '[1..10]'
console.log(+r);        // 9 (длина)
console.log(r + 5);     // 15 (конец + 5)
console.log(r - 3);     // 6  (длина - 3 = 9-3)`;

document.getElementById('output').textContent = `\`\${r}\`   => '[1..10]' (hint: string)
+r       => 9 (hint: number — длина диапазона)
r + 5    => 15 (hint: default — конец 10 + 5)
r - 3    => 6  (hint: number — 9-3)`;
