document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое Object.create(proto)? Как создать объект с заданным прототипом?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const animal = {
  type: 'Животное',
  speak() { return \`\${this.name} говорит\`; }
};

// Создать объект с animal как прототипом:
const cat = Object.create(animal);
cat.name = 'Мурка';

console.log(cat.type);    // 'Животное' (из прототипа)
console.log(cat.speak()); // 'Мурка говорит'

// Цепочка прототипов:
const kitten = Object.create(cat);
kitten.name = 'Котёнок';
console.log(kitten.type);    // 'Животное' (через 2 уровня!)
console.log(kitten.speak()); // 'Котёнок говорит'

// Объект без прототипа:
const clean = Object.create(null);
console.log(clean.toString); // undefined (нет прототипа!)`;

document.getElementById('output').textContent = `cat = Object.create(animal)
cat.type => 'Животное' (из прототипа animal)
cat.speak() => 'Мурка говорит'
kitten = Object.create(cat) — цепочка прототипов
Object.create(null) — объект вообще без прототипа`;
