document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое прототипная цепочка? Как JS ищет свойство по цепочке прототипов?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const grandParent = { a: 1 };
const parent = Object.create(grandParent);
parent.b = 2;
const child = Object.create(parent);
child.c = 3;

// JS ищет свойство снизу вверх по цепочке:
console.log(child.c); // 3 — своё
console.log(child.b); // 2 — из parent
console.log(child.a); // 1 — из grandParent
console.log(child.z); // undefined — нет нигде

// Цепочка: child -> parent -> grandParent -> Object.prototype -> null

// Проверка:
console.log(child.__proto__ === parent);           // true
console.log(parent.__proto__ === grandParent);     // true
console.log(grandParent.__proto__ === Object.prototype); // true`;

document.getElementById('output').textContent = `child.c => 3 (своё свойство)
child.b => 2 (из parent)
child.a => 1 (из grandParent)
child.z => undefined (нет нигде)
Цепочка: child -> parent -> grandParent -> Object.prototype -> null`;
