document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что возвращает Object.getPrototypeOf(obj)?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `function Animal(name) { this.name = name; }
const cat = new Animal('Мурка');

// Получить прототип:
console.log(Object.getPrototypeOf(cat) === Animal.prototype); // true
console.log(Object.getPrototypeOf(Animal.prototype) === Object.prototype); // true
console.log(Object.getPrototypeOf(Object.prototype)); // null (конец цепочки)

// Для массива:
const arr = [1, 2, 3];
console.log(Object.getPrototypeOf(arr) === Array.prototype); // true

// Устаревший способ (не рекомендуется):
console.log(cat.__proto__ === Animal.prototype); // true

// Object.getPrototypeOf предпочтительнее __proto__`;

document.getElementById('output').textContent = `Object.getPrototypeOf(cat) === Animal.prototype => true
Object.getPrototypeOf(Animal.prototype) === Object.prototype => true
Object.getPrototypeOf(Object.prototype) => null (конец!)
Object.getPrototypeOf предпочтительнее cat.__proto__`;
