document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое hasOwnProperty()? Зачем проверять собственные свойства отдельно?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const parent = { inherited: true };
const child = Object.create(parent);
child.own = 'моё';

// hasOwnProperty — только собственные свойства:
console.log(child.hasOwnProperty('own'));        // true
console.log(child.hasOwnProperty('inherited'));  // false!
console.log('inherited' in child);               // true (in идёт по цепочке)

// Современный способ:
console.log(Object.hasOwn(child, 'own'));        // true
console.log(Object.hasOwn(child, 'inherited'));  // false

// Практика: безопасный for...in
for (const key in child) {
  if (Object.hasOwn(child, key)) {
    console.log('собственное:', key); // только 'own'
  }
}`;

document.getElementById('output').textContent = `child.hasOwnProperty('own')       => true
child.hasOwnProperty('inherited')  => false (из прототипа)
'inherited' in child               => true (in идёт по цепочке!)
Object.hasOwn(child, key) — современный аналог (ES2022)
for...in + hasOwn — фильтрация только собственных ключей`;
