document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как перебрать только собственные свойства объекта, исключая прототипные?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const parent = { shared: true };
const obj = Object.create(parent);
obj.a = 1;
obj.b = 2;
obj.c = 3;

// Способ 1: Object.keys (только собственные перечисляемые):
console.log(Object.keys(obj)); // ['a', 'b', 'c']

// Способ 2: for...in + hasOwn:
for (const key in obj) {
  if (Object.hasOwn(obj, key)) console.log(key);
} // a, b, c

// Способ 3: Object.entries:
for (const [key, val] of Object.entries(obj)) {
  console.log(key, val);
} // a 1, b 2, c 3

// Способ 4: getOwnPropertyNames (включая неперечисляемые):
console.log(Object.getOwnPropertyNames(obj)); // ['a','b','c']`;

document.getElementById('output').textContent = `Object.keys(obj) => ['a','b','c'] (только собственные, без 'shared')
for...in + hasOwn — то же самое
Object.entries — пары [key,value] собственных
Object.getOwnPropertyNames — собственные включая неперечисляемые
for...in БЕЗ hasOwn включит 'shared' из прототипа!`;
