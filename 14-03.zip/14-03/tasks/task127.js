document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое Proxy? Создай простой Proxy логирующий все обращения к свойствам объекта.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const user = { name: 'Вася', age: 30 };

const loggedUser = new Proxy(user, {
  get(target, prop, receiver) {
    console.log(\`GET: \${String(prop)}\`);
    return Reflect.get(target, prop, receiver);
  },
  set(target, prop, value, receiver) {
    console.log(\`SET: \${String(prop)} = \${value}\`);
    return Reflect.set(target, prop, value, receiver);
  }
});

console.log(loggedUser.name);
// GET: name
// 'Вася'

loggedUser.age = 31;
// SET: age = 31

console.log(loggedUser.age);
// GET: age
// 31`;

document.getElementById('output').textContent = `loggedUser.name => 'GET: name' + 'Вася'
loggedUser.age = 31 => 'SET: age = 31'
loggedUser.age => 'GET: age' + 31
Proxy перехватывает операции с объектом через обработчики (ловушки)`;
