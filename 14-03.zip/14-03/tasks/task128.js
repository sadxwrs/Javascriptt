document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое ловушка get в Proxy? Напиши Proxy возвращающий 0 для несуществующих числовых свойств.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function createSafeArray(arr) {
  return new Proxy(arr, {
    get(target, prop, receiver) {
      // Если числовой индекс и элемента нет — вернуть 0
      if (!isNaN(Number(prop)) && !(prop in target)) {
        return 0;
      }
      return Reflect.get(target, prop, receiver);
    }
  });
}

const safe = createSafeArray([1, 2, 3]);

console.log(safe[0]);  // 1 (существует)
console.log(safe[2]);  // 3 (существует)
console.log(safe[5]);  // 0 (нет — возвращаем 0)
console.log(safe[99]); // 0
console.log(safe.length); // 3 (length работает нормально)`;

document.getElementById('output').textContent = `safe[0]  => 1 (существует)
safe[2]  => 3 (существует)
safe[5]  => 0 (нет — безопасный дефолт)
safe[99] => 0
safe.length => 3
Ловушка get: (target, prop, receiver) => возвращаемое значение`;
