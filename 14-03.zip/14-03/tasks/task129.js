document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое ловушка set в Proxy? Напиши валидирующий Proxy запрещающий запись отрицательных чисел.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function createPositiveOnly(obj) {
  return new Proxy(obj, {
    set(target, prop, value, receiver) {
      if (typeof value === 'number' && value < 0) {
        throw new RangeError(\`Нельзя записать отрицательное число: \${value}\`);
      }
      return Reflect.set(target, prop, value, receiver);
    }
  });
}

const scores = createPositiveOnly({});

scores.alice = 95;
scores.bob   = 72;
console.log(scores.alice); // 95

try {
  scores.carol = -10;
} catch(e) {
  console.log(e.message); // 'Нельзя записать отрицательное число: -10'
}

console.log('carol' in scores); // false (запись была отклонена)`;

document.getElementById('output').textContent = `scores.alice = 95 => OK
scores.bob = 72 => OK
scores.carol = -10 => RangeError: 'Нельзя записать отрицательное число: -10'
'carol' in scores => false (запись отклонена)
Ловушка set: (target, prop, value, receiver) => boolean`;
