document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое деструктуризация объекта? Извлеки name и age из объекта через деструктуризацию.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const user = { name: 'Лёша', age: 27, city: 'Казань', role: 'admin' };

// Деструктуризация:
const { name, age } = user;
console.log(name); // 'Лёша'
console.log(age);  // 27

// С переименованием:
const { name: userName, role: userRole } = user;
console.log(userName); // 'Лёша'
console.log(userRole); // 'admin'

// Оставшиеся поля через rest:
const { name: n, ...rest } = user;
console.log(rest); // { age:27, city:'Казань', role:'admin' }`;

document.getElementById('output').textContent = `const { name, age } = user => name='Лёша', age=27
const { name: userName } = user => userName='Лёша'
const { name: n, ...rest } = user => rest={ age:27, city:'Казань', role:'admin' }`;
