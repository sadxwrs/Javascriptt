document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое Reflect? Как он используется вместе с Proxy?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Reflect — объект для «дефолтных» операций над объектами
// Методы Reflect точно соответствуют ловушкам Proxy

const handler = {
  get(target, prop, receiver) {
    console.log(\`Чтение: \${String(prop)}\`);
    // Reflect.get — дефолтное поведение чтения
    return Reflect.get(target, prop, receiver);
  },
  set(target, prop, value, receiver) {
    console.log(\`Запись: \${String(prop)} = \${value}\`);
    return Reflect.set(target, prop, value, receiver);
  },
  has(target, prop) {
    console.log(\`Проверка: \${String(prop)}\`);
    return Reflect.has(target, prop);
  }
};

const proxy = new Proxy({ x: 1 }, handler);
proxy.x;       // 'Чтение: x'
proxy.y = 2;   // 'Запись: y = 2'
'x' in proxy;  // 'Проверка: x'`;

document.getElementById('output').textContent = `Reflect — набор методов для стандартных операций над объектами
Reflect.get = obj[prop] (дефолтное чтение)
Reflect.set = obj[prop] = val (дефолтная запись)
Reflect.has = prop in obj
В Proxy: всегда возвращай через Reflect чтобы сохранить дефолтное поведение`;
