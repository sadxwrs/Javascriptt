document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое ловушка has в Proxy? Переопредели оператор in для объекта.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// has — перехватывает оператор 'in'

const range = {
  start: 1,
  end: 100
};

const rangeProxy = new Proxy(range, {
  has(target, prop) {
    // Переопределяем: 'n in range' проверяет попадание числа в диапазон
    const num = Number(prop);
    if (!isNaN(num)) {
      return num >= target.start && num <= target.end;
    }
    return Reflect.has(target, prop);
  }
});

console.log(50 in rangeProxy);  // true
console.log(1  in rangeProxy);  // true
console.log(100 in rangeProxy); // true
console.log(0  in rangeProxy);  // false
console.log(101 in rangeProxy); // false
console.log('start' in rangeProxy); // true (обычная проверка)`;

document.getElementById('output').textContent = `50 in rangeProxy  => true  (50 в диапазоне [1..100])
1 in rangeProxy   => true
100 in rangeProxy => true
0 in rangeProxy   => false
101 in rangeProxy => false
'start' in rangeProxy => true (обычное свойство)`;
