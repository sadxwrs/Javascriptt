document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши Proxy реализующий 'отрицательные индексы' для массива как в Python.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function negativeIndex(arr) {
  return new Proxy(arr, {
    get(target, prop, receiver) {
      let index = Number(prop);
      if (Number.isInteger(index) && index < 0) {
        // Отрицательный индекс: считаем с конца
        index = target.length + index;
      }
      return Reflect.get(target, String(index), receiver);
    }
  });
}

const arr = negativeIndex([1, 2, 3, 4, 5]);

console.log(arr[0]);  // 1 (первый)
console.log(arr[4]);  // 5 (последний)
console.log(arr[-1]); // 5 (последний)
console.log(arr[-2]); // 4 (предпоследний)
console.log(arr[-5]); // 1 (первый)
console.log(arr.length); // 5 (length не тронут)`;

document.getElementById('output').textContent = `arr[0]   => 1
arr[4]   => 5
arr[-1]  => 5 (последний)
arr[-2]  => 4 (предпоследний)
arr[-5]  => 1 (первый)
arr.length => 5 (без изменений)`;
