document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое Object.getOwnPropertyDescriptors()? Как скопировать объект вместе с дескрипторами?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const source = {};
Object.defineProperty(source, 'readOnly', {
  value: 42,
  writable: false,
  enumerable: true,
  configurable: false
});
source.regular = 'обычное';

// Обычный spread НЕ копирует дескрипторы:
const bad = { ...source };
console.log(Object.getOwnPropertyDescriptor(bad, 'readOnly').writable);
// true! (writable потерян)

// Копирование с дескрипторами:
const good = Object.create(
  Object.getPrototypeOf(source),
  Object.getOwnPropertyDescriptors(source)
);
console.log(Object.getOwnPropertyDescriptor(good, 'readOnly').writable);
// false! (дескриптор сохранён)

good.readOnly = 100; // молча игнорируется
console.log(good.readOnly); // 42`;

document.getElementById('output').textContent = `{ ...source } теряет дескрипторы: writable => true (изменилось!)
Object.create(proto, Object.getOwnPropertyDescriptors(source)) — копирует всё
good.readOnly = 100 => игнорируется (writable: false сохранён)
good.readOnly => 42
Используй getOwnPropertyDescriptors для полного клонирования`;
