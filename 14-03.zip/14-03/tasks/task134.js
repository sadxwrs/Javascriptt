document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй реактивный объект через Proxy: при изменении любого свойства автоматически вызывается callback.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function reactive(obj, onChange) {
  return new Proxy(obj, {
    set(target, prop, value, receiver) {
      const oldValue = target[prop];
      const result = Reflect.set(target, prop, value, receiver);
      if (result && oldValue !== value) {
        onChange(prop, value, oldValue);
      }
      return result;
    }
  });
}

const state = reactive(
  { count: 0, name: 'App' },
  (prop, newVal, oldVal) => {
    console.log(\`\${prop}: \${oldVal} => \${newVal}\`);
  }
);

state.count++;      // 'count: 0 => 1'
state.count += 9;   // 'count: 1 => 10'
state.name = 'Vue'; // 'name: App => Vue'
state.count = 10;   // нет вывода (значение не изменилось!)`;

document.getElementById('output').textContent = `state.count++ => 'count: 0 => 1'
state.count += 9 => 'count: 1 => 10'
state.name = 'Vue' => 'name: App => Vue'
state.count = 10 => тишина (значение не изменилось)
Callback вызывается только при реальном изменении значения`;
