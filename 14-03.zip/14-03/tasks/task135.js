document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое revocable Proxy (Proxy.revocable())? Когда он полезен?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Proxy.revocable создаёт Proxy который можно отозвать
const target = { secret: 'данные' };

const { proxy, revoke } = Proxy.revocable(target, {
  get(t, prop) {
    console.log('Чтение:', prop);
    return Reflect.get(t, prop);
  }
});

console.log(proxy.secret); // 'Чтение: secret' => 'данные'

// Отзываем Proxy:
revoke();

try {
  console.log(proxy.secret); // TypeError!
} catch(e) {
  console.log(e.message); // Cannot perform 'get' on a proxy that has been revoked
}

// Полезно для:
// - Временного доступа к данным
// - API с истекающим временем жизни
// - Безопасности: отозвать доступ к объекту`;

document.getElementById('output').textContent = `proxy.secret => 'Чтение: secret' => 'данные'
revoke() — отзываем доступ
proxy.secret после revoke => TypeError!
Полезно для: временного доступа, API-токенов, безопасного разграничения доступа`;
