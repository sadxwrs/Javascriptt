document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй 'виртуальный' объект через Proxy у которого любое свойство возвращает функцию логирующую своё имя.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function createLogger(prefix = '') {
  return new Proxy({}, {
    get(target, prop) {
      // Возвращаем функцию для любого свойства
      return (...args) => {
        console.log(\`[\${prefix}] \${String(prop)}(\${args.join(', ')})\`);
        // Возвращаем сам logger для чейнинга
        return createLogger(\`\${prefix}.\${String(prop)}\`);
      };
    }
  });
}

const log = createLogger('App');

log.init();         // '[App] init()'
log.user.create('Аня', 25); // '[App] user()', '[App.user] create(Аня, 25)'
log.db.query('SELECT *'); // '[App] db()', '[App.db] query(SELECT *)'
log.render().update();`;

document.getElementById('output').textContent = `log.init()                => '[App] init()'
log.user.create('Аня',25) => '[App] user()' + '[App.user] create(Аня, 25)'
Любое свойство => функция, логирующая имя при вызове
Proxy.get перехватывает обращение к любому свойству, включая несуществующие`;
