document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое паттерн 'наблюдатель' (Observer) реализованный через Proxy? Напиши рабочий пример.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function observable(obj) {
  const listeners = {};

  const proxy = new Proxy(obj, {
    set(target, prop, value, receiver) {
      const old = target[prop];
      Reflect.set(target, prop, value, receiver);
      if (listeners[prop]) {
        listeners[prop].forEach(fn => fn(value, old));
      }
      return true;
    }
  });

  proxy.on = function(prop, fn) {
    if (!listeners[prop]) listeners[prop] = [];
    listeners[prop].push(fn);
    return proxy;
  };

  return proxy;
}

const store = observable({ count: 0, user: null });

store.on('count', (newVal, oldVal) =>
  console.log(\`count: \${oldVal} -> \${newVal}\`)
);
store.on('user', (u) => console.log('user changed:', u?.name));

store.count = 1;                    // 'count: 0 -> 1'
store.count = 5;                    // 'count: 1 -> 5'
store.user = { name: 'Аня' };      // 'user changed: Аня'`;

document.getElementById('output').textContent = `store.on('count', fn) — подписаться на изменения
store.count = 1 => 'count: 0 -> 1'
store.count = 5 => 'count: 1 -> 5'
store.user = {name:'Аня'} => 'user changed: Аня'
Proxy.set запускает всех подписчиков при изменении`;
