document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как реализовать 'ленивую инициализацию' свойств объекта через Object.defineProperty с геттером?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function lazyLoad(obj, prop, factory) {
  // Свойство создаётся только при первом обращении
  Object.defineProperty(obj, prop, {
    get() {
      console.log(\`Инициализация \${prop}...\`);
      const value = factory();
      // Заменяем геттер на обычное значение:
      Object.defineProperty(this, prop, {
        value,
        writable: true,
        configurable: true
      });
      return value;
    },
    configurable: true
  });
}

const app = {};
lazyLoad(app, 'config', () => ({
  db: 'postgresql://localhost',
  port: 5432
}));

console.log('До обращения — config не создан');
console.log(app.config); // 'Инициализация config...' + объект
console.log(app.config); // Просто объект (уже инициализирован!)`;

document.getElementById('output').textContent = `До первого обращения — config не существует в памяти
app.config (первый раз) => 'Инициализация config...' + объект
app.config (второй раз) => просто объект (геттер заменён значением!)
Паттерн lazy load: создавать дорогие объекты только по требованию`;
