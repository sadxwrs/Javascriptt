document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое мемоизирующий Proxy? Реализуй Proxy кэширующий результаты вызовов методов объекта.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function memoProxy(obj) {
  const cache = new Map();

  return new Proxy(obj, {
    get(target, prop, receiver) {
      const value = Reflect.get(target, prop, receiver);

      if (typeof value !== 'function') return value;

      return function(...args) {
        const key = \`\${prop}:\${JSON.stringify(args)}\`;
        if (cache.has(key)) {
          console.log(\`Кеш: \${prop}(\${args})\`);
          return cache.get(key);
        }
        const result = value.apply(target, args);
        cache.set(key, result);
        return result;
      };
    }
  });
}

const calc = memoProxy({
  slowSquare(n) {
    console.log('Вычисляю...');
    return n * n;
  }
});

console.log(calc.slowSquare(5));  // 'Вычисляю...' => 25
console.log(calc.slowSquare(5));  // 'Кеш: slowSquare(5)' => 25
console.log(calc.slowSquare(10)); // 'Вычисляю...' => 100`;

document.getElementById('output').textContent = `calc.slowSquare(5)  => 'Вычисляю...' => 25 (первый вызов)
calc.slowSquare(5)  => 'Кеш: slowSquare(5)' => 25 (из кеша!)
calc.slowSquare(10) => 'Вычисляю...' => 100 (новые аргументы)
Proxy перехватывает get и оборачивает функции мемоизацией`;
