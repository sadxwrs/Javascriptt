document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как задать значение по умолчанию при деструктуризации?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const settings = { theme: 'dark', fontSize: 16 };

const {
  theme = 'light',       // есть в объекте => 'dark'
  fontSize = 14,         // есть => 16
  language = 'ru',       // нет => 'ru' (по умолчанию)
  notifications = true   // нет => true (по умолчанию)
} = settings;

console.log(theme);         // 'dark'
console.log(fontSize);      // 16
console.log(language);      // 'ru'
console.log(notifications); // true`;

document.getElementById('output').textContent = `theme         => 'dark'  (есть в объекте)
fontSize       => 16     (есть в объекте)
language       => 'ru'   (нет — используется дефолт)
notifications  => true   (нет — используется дефолт)
Дефолт применяется только при undefined`;
