document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое паттерн 'иммутабельный объект' через Proxy? Заблокируй все операции записи и удаления рекурсивно.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function immutable(obj) {
  if (obj === null || typeof obj !== 'object') return obj;

  return new Proxy(obj, {
    get(target, prop, receiver) {
      const value = Reflect.get(target, prop, receiver);
      // Рекурсивно оборачиваем вложенные объекты
      return typeof value === 'object' && value !== null
        ? immutable(value)
        : value;
    },
    set(target, prop) {
      throw new TypeError(\`Нельзя изменить '\${String(prop)}' — объект иммутабелен\`);
    },
    deleteProperty(target, prop) {
      throw new TypeError(\`Нельзя удалить '\${String(prop)}' — объект иммутабелен\`);
    }
  });
}

const state = immutable({ user: { name: 'Аня', age: 25 }, count: 0 });

console.log(state.user.name); // 'Аня'
console.log(state.count);     // 0

try { state.count = 1; } catch(e) { console.log(e.message); }
// 'Нельзя изменить count'
try { state.user.age = 30; } catch(e) { console.log(e.message); }
// 'Нельзя изменить age' (вложенный тоже!)`;

document.getElementById('output').textContent = `state.user.name => 'Аня'
state.count     => 0
state.count = 1 => TypeError: 'Нельзя изменить count'
state.user.age = 30 => TypeError: 'Нельзя изменить age' (рекурсивно!)
delete state.user => TypeError
Proxy блокирует set и deleteProperty на всех уровнях вложенности`;
