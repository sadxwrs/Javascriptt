document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>createObservable(obj, onChange)</code> через Proxy отслеживающий глубокие изменения вложенных объектов.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function createObservable(obj, onChange) {
  function makeProxy(target, path = '') {
    return new Proxy(target, {
      get(t, prop, receiver) {
        const value = Reflect.get(t, prop, receiver);
        if (value && typeof value === 'object') {
          const childPath = path ? \`\${path}.\${String(prop)}\` : String(prop);
          return makeProxy(value, childPath);
        }
        return value;
      },
      set(t, prop, value, receiver) {
        const fullPath = path ? \`\${path}.\${String(prop)}\` : String(prop);
        const old = t[prop];
        Reflect.set(t, prop, value, receiver);
        if (old !== value) onChange(fullPath, value, old);
        return true;
      }
    });
  }
  return makeProxy(obj);
}

const state = createObservable(
  { user: { name: 'Аня', address: { city: 'Москва' } }, count: 0 },
  (path, newVal, oldVal) => console.log(\`\${path}: \${oldVal} => \${newVal}\`)
);

state.count = 5;                // 'count: 0 => 5'
state.user.name = 'Боря';      // 'user.name: Аня => Боря'
state.user.address.city = 'Питер'; // 'user.address.city: Москва => Питер'`;

document.getElementById('output').textContent = `state.count = 5            => 'count: 0 => 5'
state.user.name = 'Боря'   => 'user.name: Аня => Боря'
state.user.address.city = 'Питер' => 'user.address.city: Москва => Питер'
Proxy рекурсивно оборачивает вложенные объекты при чтении`;
