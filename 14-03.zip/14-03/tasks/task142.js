document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>Object.assign()</code>? Объедини несколько объектов в один и покажи что происходит при совпадении ключей.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const target = { a: 1, b: 2 };
const src1   = { b: 99, c: 3 };
const src2   = { c: 100, d: 4 };

const result = Object.assign(target, src1, src2);

console.log(result); // { a:1, b:99, c:100, d:4 }
console.log(result === target); // true — мутирует target!

// При совпадении: правее = победитель
console.log(result.b); // 99 (из src1)
console.log(result.c); // 100 (из src2 перезаписал src1)

// Без мутации — spread:
const safe = { ...target, ...src1, ...src2 };
console.log(safe === target); // false (новый объект)`;

document.getElementById('output').textContent = `Object.assign(target, src1, src2) мутирует target!
result === target => true
При конфликтах: правее = победитель
result.b => 99 (src1)
result.c => 100 (src2 перезаписал src1)
Для безопасности без мутации: { ...target, ...src1, ...src2 }`;
