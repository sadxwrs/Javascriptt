document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое свойства-геттеры и сеттеры через <code>Object.defineProperty</code>? Напиши объект с вычисляемым полем <code>fullName</code>.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const person = { firstName: 'Иван', lastName: 'Петров' };

Object.defineProperty(person, 'fullName', {
  get() {
    return \`\${this.firstName} \${this.lastName}\`;
  },
  set(value) {
    const parts = value.trim().split(' ');
    this.firstName = parts[0] ?? '';
    this.lastName  = parts[1] ?? '';
  },
  enumerable: true,
  configurable: true
});

console.log(person.fullName);    // 'Иван Петров'

person.fullName = 'Мария Иванова';
console.log(person.firstName);   // 'Мария'
console.log(person.lastName);    // 'Иванова'
console.log(person.fullName);    // 'Мария Иванова'`;

document.getElementById('output').textContent = `person.fullName           => 'Иван Петров' (геттер)
person.fullName = 'Мария Иванова' (сеттер)
person.firstName          => 'Мария'
person.lastName           => 'Иванова'
person.fullName           => 'Мария Иванова'`;
