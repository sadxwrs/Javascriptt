document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию <code>classOf(value)</code> возвращающую точный тип через <code>Object.prototype.toString</code>.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function classOf(value) {
  return Object.prototype.toString.call(value).slice(8, -1);
}

console.log(classOf(42));           // 'Number'
console.log(classOf('hello'));      // 'String'
console.log(classOf(true));         // 'Boolean'
console.log(classOf(null));         // 'Null'
console.log(classOf(undefined));    // 'Undefined'
console.log(classOf([]));           // 'Array'
console.log(classOf({}));           // 'Object'
console.log(classOf(new Date()));   // 'Date'
console.log(classOf(/regex/));      // 'RegExp'
console.log(classOf(() => {}));     // 'Function'
console.log(classOf(new Map()));    // 'Map'
console.log(classOf(new Set()));    // 'Set'`;

document.getElementById('output').textContent = `classOf(42)        => 'Number'
classOf([])        => 'Array'
classOf(null)      => 'Null'
classOf(new Date()) => 'Date'
classOf(new Map()) => 'Map'
Object.prototype.toString.call(x).slice(8,-1) — надёжнее typeof`;
