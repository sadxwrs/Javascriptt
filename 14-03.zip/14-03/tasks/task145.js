document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>Object.keys</code>, <code>Object.values</code>, <code>Object.entries</code> — покажи разницу с <code>for...in</code> при наследовании.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const parent = { inherited: 'из прототипа' };
const child = Object.create(parent);
child.own1 = 'своё 1';
child.own2 = 'своё 2';

// for...in — обходит ВСЕ перечисляемые (включая inherited):
const forIn = [];
for (const k in child) forIn.push(k);
console.log(forIn); // ['own1', 'own2', 'inherited']

// Object.keys/values/entries — только СОБСТВЕННЫЕ:
console.log(Object.keys(child));    // ['own1', 'own2']
console.log(Object.values(child));  // ['своё 1', 'своё 2']
console.log(Object.entries(child)); // [['own1','своё 1'],['own2','своё 2']]

// Вывод: для большинства задач Object.keys лучше for...in`;

document.getElementById('output').textContent = `for...in => ['own1','own2','inherited'] (включая прототип!)
Object.keys(child) => ['own1','own2'] (только свои)
Object.values(child) => ['своё 1','своё 2']
Object.entries(child) => [['own1','своё 1'],['own2','своё 2']]
Object.keys — предпочтительнее for...in для собственных ключей`;
