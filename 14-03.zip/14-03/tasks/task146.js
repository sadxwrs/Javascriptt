document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй функцию <code>flattenObject(obj, sep='.')</code> которая разворачивает вложенный объект в плоский.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function flattenObject(obj, sep = '.', prefix = '') {
  return Object.entries(obj).reduce((acc, [key, val]) => {
    const fullKey = prefix ? \`\${prefix}\${sep}\${key}\` : key;
    if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
      Object.assign(acc, flattenObject(val, sep, fullKey));
    } else {
      acc[fullKey] = val;
    }
    return acc;
  }, {});
}

const nested = {
  user: { name: 'Аня', address: { city: 'Москва', zip: '101000' } },
  count: 42
};

console.log(flattenObject(nested));
// {
//   'user.name': 'Аня',
//   'user.address.city': 'Москва',
//   'user.address.zip': '101000',
//   'count': 42
// }`;

document.getElementById('output').textContent = `flattenObject(nested) =>
{
  'user.name': 'Аня',
  'user.address.city': 'Москва',
  'user.address.zip': '101000',
  'count': 42
}
Алгоритм: рекурсивный обход с накоплением пути`;
