document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй функцию <code>unflattenObject(obj, sep='.')</code> — обратную операцию к flattenObject.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function unflattenObject(obj, sep = '.') {
  const result = {};
  for (const [flatKey, value] of Object.entries(obj)) {
    const keys = flatKey.split(sep);
    let cur = result;
    for (let i = 0; i < keys.length - 1; i++) {
      if (!(keys[i] in cur) || typeof cur[keys[i]] !== 'object') {
        cur[keys[i]] = {};
      }
      cur = cur[keys[i]];
    }
    cur[keys[keys.length - 1]] = value;
  }
  return result;
}

const flat = {
  'user.name': 'Боря',
  'user.address.city': 'Питер',
  'count': 5
};

console.log(unflattenObject(flat));
// { user: { name:'Боря', address:{ city:'Питер' } }, count:5 }`;

document.getElementById('output').textContent = `unflattenObject({'user.name':'Боря','user.address.city':'Питер','count':5})
=> { user: { name:'Боря', address:{ city:'Питер' } }, count:5 }
Обратная операция к flattenObject`;
