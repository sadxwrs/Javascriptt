document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>Object.is()</code>? Чем он отличается от <code>===</code>?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Object.is — строгое равенство без двух исключений:

// Исключение 1: NaN
console.log(NaN === NaN);        // false (баг!)
console.log(Object.is(NaN, NaN)); // true (правильно!)

// Исключение 2: +0 и -0
console.log(+0 === -0);           // true (баг!)
console.log(Object.is(+0, -0));   // false (правильно!)

// Для всего остального — как ===:
console.log(Object.is(1, 1));     // true
console.log(Object.is('a', 'a')); // true
console.log(Object.is(null, null)); // true
console.log(Object.is(1, '1'));   // false
console.log(Object.is(null, undefined)); // false`;

document.getElementById('output').textContent = `NaN === NaN        => false (баг ===)
Object.is(NaN,NaN) => true (правильно!)
+0 === -0          => true (баг ===)
Object.is(+0,-0)   => false (правильно!)
Остальное: Object.is работает как ===`;
