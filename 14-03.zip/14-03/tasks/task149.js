document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию <code>diff(obj1, obj2)</code> возвращающую объект с различиями между двумя объектами.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function diff(obj1, obj2) {
  const result = {};
  const allKeys = new Set([...Object.keys(obj1), ...Object.keys(obj2)]);

  for (const key of allKeys) {
    const v1 = obj1[key];
    const v2 = obj2[key];
    if (v1 === v2) continue;

    if (v1 && v2 && typeof v1 === 'object' && typeof v2 === 'object') {
      const nested = diff(v1, v2);
      if (Object.keys(nested).length > 0) result[key] = nested;
    } else {
      result[key] = { from: v1, to: v2 };
    }
  }
  return result;
}

const a = { name: 'Аня', age: 25, city: 'Москва' };
const b = { name: 'Аня', age: 26, city: 'Питер',  role: 'admin' };

console.log(diff(a, b));
// {
//   age:  { from: 25, to: 26 },
//   city: { from: 'Москва', to: 'Питер' },
//   role: { from: undefined, to: 'admin' }
// }`;

document.getElementById('output').textContent = `diff(a, b) =>
{
  age:  { from:25, to:26 },
  city: { from:'Москва', to:'Питер' },
  role: { from:undefined, to:'admin' }
}
name — без изменений, в результат не попадает`;
