document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое spread-оператор ... для объектов? Объедини два объекта через него.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const defaults = { theme: 'light', lang: 'ru', fontSize: 14 };
const custom   = { theme: 'dark', fontSize: 18 };

// Объединение (custom перезаписывает defaults):
const merged = { ...defaults, ...custom };
console.log(merged);
// { theme:'dark', lang:'ru', fontSize:18 }

// Копирование:
const copy = { ...defaults };
copy.lang = 'en';
console.log(defaults.lang); // 'ru' — не изменился!

// Добавить поле:
const extended = { ...defaults, version: '1.0' };
console.log(extended.version); // '1.0'`;

document.getElementById('output').textContent = `{ ...defaults, ...custom } => { theme:'dark', lang:'ru', fontSize:18 }
Спред копирует первый уровень (поверхностно)
Поздний объект перезаписывает ранний при совпадении ключей`;
