document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй паттерн <code>Builder</code> для создания сложных объектов пошагово.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `class UserBuilder {
  constructor() {
    this._user = {};
  }

  setName(name) { this._user.name = name; return this; }
  setAge(age)   {
    if (age < 0 || age > 150) throw new RangeError('Некорректный возраст');
    this._user.age = age; return this;
  }
  setEmail(email) {
    if (!email.includes('@')) throw new Error('Некорректный email');
    this._user.email = email; return this;
  }
  setRole(role = 'user') { this._user.role = role; return this; }
  setAdmin() { this._user.role = 'admin'; return this; }

  build() {
    if (!this._user.name) throw new Error('name обязателен');
    return Object.freeze({ ...this._user });
  }
}

const user = new UserBuilder()
  .setName('Катя')
  .setAge(28)
  .setEmail('katya@mail.ru')
  .setAdmin()
  .build();

console.log(user); // { name:'Катя', age:28, email:'...', role:'admin' }`;

document.getElementById('output').textContent = `new UserBuilder().setName('Катя').setAge(28).setEmail('katya@mail.ru').setAdmin().build()
=> { name:'Катя', age:28, email:'katya@mail.ru', role:'admin' } (frozen)
Builder: пошаговое создание с валидацией
build() возвращает иммутабельный объект через Object.freeze`;
