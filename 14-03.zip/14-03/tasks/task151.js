document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>Object.fromEntries()</code>? Покажи как его использовать для трансформации объектов.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Трансформация 1: удвоить все числовые значения
const prices = { apple: 10, banana: 5, cherry: 20 };
const doubled = Object.fromEntries(
  Object.entries(prices).map(([k, v]) => [k, v * 2])
);
console.log(doubled); // { apple:20, banana:10, cherry:40 }

// Трансформация 2: фильтрация
const filtered = Object.fromEntries(
  Object.entries(prices).filter(([, v]) => v > 8)
);
console.log(filtered); // { apple:10, cherry:20 }

// Трансформация 3: из Map
const map = new Map([['x', 1], ['y', 2], ['z', 3]]);
console.log(Object.fromEntries(map)); // { x:1, y:2, z:3 }

// Трансформация 4: инверсия ключей и значений
const codes = { ru: 'Россия', us: 'США' };
const inverted = Object.fromEntries(
  Object.entries(codes).map(([k, v]) => [v, k])
);
console.log(inverted); // { Россия:'ru', США:'us' }`;

document.getElementById('output').textContent = `Удвоение: { apple:20, banana:10, cherry:40 }
Фильтрация: { apple:10, cherry:20 }
Из Map: { x:1, y:2, z:3 }
Инверсия: { Россия:'ru', США:'us' }
Паттерн: Object.fromEntries(Object.entries(obj).map/filter(...))`;
