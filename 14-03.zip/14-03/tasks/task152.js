document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию <code>groupBy(arr, key)</code> группирующую массив объектов по полю.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function groupBy(arr, key) {
  return arr.reduce((groups, item) => {
    const groupKey = typeof key === 'function' ? key(item) : item[key];
    if (!groups[groupKey]) groups[groupKey] = [];
    groups[groupKey].push(item);
    return groups;
  }, {});
}

const people = [
  { name: 'Аня',   role: 'dev' },
  { name: 'Боря',  role: 'qa'  },
  { name: 'Вася',  role: 'dev' },
  { name: 'Галя',  role: 'qa'  },
  { name: 'Дима',  role: 'dev' },
];

console.log(groupBy(people, 'role'));
// {
//   dev: [{ name:'Аня' }, { name:'Вася' }, { name:'Дима' }],
//   qa:  [{ name:'Боря' }, { name:'Галя' }]
// }

// Группировка по функции:
console.log(groupBy([1,2,3,4,5,6], n => n % 2 === 0 ? 'чётные' : 'нечётные'));`;

document.getElementById('output').textContent = `groupBy(people, 'role') =>
{ dev:[Аня,Вася,Дима], qa:[Боря,Галя] }
groupBy([1..6], n=>n%2===0?'чётные':'нечётные') =>
{ нечётные:[1,3,5], чётные:[2,4,6] }`;
