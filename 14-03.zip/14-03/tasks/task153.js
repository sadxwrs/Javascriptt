document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй паттерн <code>Singleton</code> через замыкание и через <code>Object.freeze</code>.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Способ 1: через замыкание
const DatabaseConnection = (() => {
  let instance = null;

  function createInstance() {
    return {
      host: 'localhost',
      port: 5432,
      connect() { return \`Подключен к \${this.host}:\${this.port}\`; }
    };
  }

  return {
    getInstance() {
      if (!instance) instance = createInstance();
      return instance;
    }
  };
})();

const db1 = DatabaseConnection.getInstance();
const db2 = DatabaseConnection.getInstance();
console.log(db1 === db2); // true (один экземпляр!)
console.log(db1.connect()); // 'Подключен к localhost:5432'

// Способ 2: через module (ES modules)
// export const config = Object.freeze({ host: 'localhost' });
// Импортируется одна копия на всё приложение`;

document.getElementById('output').textContent = `db1 === db2 => true (один экземпляр!)
db1.connect() => 'Подключен к localhost:5432'
Singleton: гарантирует создание только одного экземпляра
Вариант 1: замыкание + getInstance()
Вариант 2: ES-модуль (импортируется один раз)`;
