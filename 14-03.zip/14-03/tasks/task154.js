document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>Object.getOwnPropertyNames()</code>? Чем он отличается от <code>Object.keys()</code>?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const obj = {};

// Добавляем обычное свойство:
obj.visible = 'видимое';

// Добавляем НЕперечисляемое свойство:
Object.defineProperty(obj, 'hidden', {
  value: 'скрытое',
  enumerable: false
});

console.log(Object.keys(obj));
// ['visible'] — только перечисляемые

console.log(Object.getOwnPropertyNames(obj));
// ['visible', 'hidden'] — ВСЕ собственные

// Symbol-ключи не включаются ни в тот, ни в другой!
const sym = Symbol('s');
obj[sym] = 'символ';
console.log(Object.getOwnPropertyNames(obj)); // ['visible','hidden']

// Для Symbol-ключей:
console.log(Object.getOwnPropertySymbols(obj)); // [Symbol(s)]

// Все ключи включая Symbol:
console.log(Reflect.ownKeys(obj)); // ['visible','hidden',Symbol(s)]`;

document.getElementById('output').textContent = `Object.keys(obj) => ['visible'] (только перечисляемые)
Object.getOwnPropertyNames(obj) => ['visible','hidden'] (все строковые)
Object.getOwnPropertySymbols(obj) => [Symbol(s)]
Reflect.ownKeys(obj) => ['visible','hidden',Symbol(s)] — абсолютно всё`;
