document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй функцию <code>mixin(...sources)</code> добавляющую методы из нескольких источников в один объект.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function mixin(target, ...sources) {
  for (const source of sources) {
    for (const key of Object.getOwnPropertyNames(source)) {
      if (key === 'constructor') continue;
      Object.defineProperty(target, key,
        Object.getOwnPropertyDescriptor(source, key)
      );
    }
  }
  return target;
}

const Serializable = {
  serialize() { return JSON.stringify(this); },
  deserialize(json) { return Object.assign(this, JSON.parse(json)); }
};

const Validatable = {
  validate() { return Object.keys(this).every(k => this[k] !== null); }
};

class User {
  constructor(name, age) { this.name = name; this.age = age; }
}
mixin(User.prototype, Serializable, Validatable);

const u = new User('Вера', 25);
console.log(u.serialize());    // '{"name":"Вера","age":25}'
console.log(u.validate());     // true`;

document.getElementById('output').textContent = `u.serialize() => '{"name":"Вера","age":25}'
u.validate()  => true
mixin добавляет методы из нескольких источников без наследования
Копирует дескрипторы свойств через getOwnPropertyDescriptor`;
