document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое паттерн <code>Decorator</code> для объектов? Напиши функцию добавляющую логирование к методам объекта.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function withLogging(obj, label = 'obj') {
  return new Proxy(obj, {
    get(target, prop, receiver) {
      const value = Reflect.get(target, prop, receiver);
      if (typeof value !== 'function') return value;
      return function(...args) {
        console.log(\`[\${label}] \${String(prop)}(\${args.map(a => JSON.stringify(a)).join(', ')})\`);
        const result = value.apply(target, args);
        console.log(\`[\${label}] \${String(prop)} => \${JSON.stringify(result)}\`);
        return result;
      };
    }
  });
}

const calc = withLogging({
  add(a, b) { return a + b; },
  mul(a, b) { return a * b; }
}, 'Calculator');

calc.add(2, 3);
// '[Calculator] add(2, 3)'
// '[Calculator] add => 5'

calc.mul(4, 5);
// '[Calculator] mul(4, 5)'
// '[Calculator] mul => 20'`;

document.getElementById('output').textContent = `[Calculator] add(2, 3)
[Calculator] add => 5
[Calculator] mul(4, 5)
[Calculator] mul => 20
Proxy перехватывает get и оборачивает функции логированием`;
