document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>EventEmitter</code> — объект поддерживающий подписку на события и их генерацию.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `class EventEmitter {
  constructor() {
    this._events = {};
  }

  on(event, listener) {
    if (!this._events[event]) this._events[event] = [];
    this._events[event].push(listener);
    return this;
  }

  off(event, listener) {
    if (!this._events[event]) return this;
    this._events[event] = this._events[event].filter(l => l !== listener);
    return this;
  }

  once(event, listener) {
    const wrapper = (...args) => { listener(...args); this.off(event, wrapper); };
    return this.on(event, wrapper);
  }

  emit(event, ...args) {
    (this._events[event] || []).forEach(l => l(...args));
    return this;
  }
}

const emitter = new EventEmitter();
emitter.on('data', d => console.log('data:', d));
emitter.once('init', () => console.log('инициализация'));

emitter.emit('init');   // 'инициализация'
emitter.emit('init');   // тишина (once — только раз)
emitter.emit('data', 42); // 'data: 42'`;

document.getElementById('output').textContent = `emit('init') => 'инициализация'
emit('init') => тишина (once сработал один раз)
emit('data', 42) => 'data: 42'
on — постоянная подписка
once — одноразовая подписка
off — отписка`;
