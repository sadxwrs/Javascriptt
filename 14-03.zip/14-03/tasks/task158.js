document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое оператор <code>??</code> (nullish coalescing)? Чем он отличается от <code>||</code>?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// || возвращает правое при ЛЮБОМ falsy значении
// ?? возвращает правое только при null/undefined

const count = 0;
console.log(count || 10);  // 10  (0 — falsy!)
console.log(count ?? 10);  // 0   (0 — не null/undefined)

const name = '';
console.log(name || 'Аноним');  // 'Аноним' ('' — falsy)
console.log(name ?? 'Аноним');  // ''       ('' — не null/undefined)

const val = null;
console.log(val || 'дефолт'); // 'дефолт'
console.log(val ?? 'дефолт'); // 'дефолт'

// Практика:
function getConfig(options = {}) {
  return {
    timeout: options.timeout ?? 3000, // 0 — валидное значение!
    retries: options.retries ?? 3,
    debug:   options.debug   ?? false
  };
}
console.log(getConfig({ timeout: 0, retries: 0 }));
// { timeout: 0, retries: 0, debug: false }`;

document.getElementById('output').textContent = `|| реагирует на все falsy: 0, '', false, null, undefined
?? реагирует только на null и undefined
count=0: count||10 => 10, count??10 => 0
name='': name||'Аноним' => 'Аноним', name??'Аноним' => ''
getConfig({timeout:0}) => timeout:0 (не заменяется дефолтом!)`;
