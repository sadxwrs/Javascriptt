document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй паттерн <code>Strategy</code> через объекты: система скидок с разными стратегиями.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `const discountStrategies = {
  none:       (price) => price,
  student:    (price) => price * 0.8,
  senior:     (price) => price * 0.7,
  vip:        (price) => price * 0.5,
  'black-friday': (price) => Math.min(price * 0.5, price - 500)
};

function PriceCalculator(strategy = 'none') {
  this.strategy = strategy;

  this.calculate = function(basePrice) {
    const fn = discountStrategies[this.strategy];
    if (!fn) throw new Error(\`Неизвестная стратегия: \${this.strategy}\`);
    return Math.round(fn(basePrice));
  };

  this.setStrategy = function(s) {
    this.strategy = s;
    return this;
  };
}

const calc = new PriceCalculator();
console.log(calc.calculate(1000));              // 1000
console.log(calc.setStrategy('student').calculate(1000)); // 800
console.log(calc.setStrategy('vip').calculate(1000));     // 500
console.log(calc.setStrategy('black-friday').calculate(1000)); // 500`;

document.getElementById('output').textContent = `PriceCalculator('none').calculate(1000)     => 1000
setStrategy('student').calculate(1000)      => 800 (20% скидка)
setStrategy('vip').calculate(1000)          => 500 (50% скидка)
setStrategy('black-friday').calculate(1000) => 500
Стратегия заменяется в рантайме без изменения класса`;
