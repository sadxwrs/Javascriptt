document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое Object.keys(), Object.values(), Object.entries()? Напиши пример использования каждого.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const person = { name: 'Миша', age: 32, city: 'Уфа' };

console.log(Object.keys(person));
// ['name', 'age', 'city']

console.log(Object.values(person));
// ['Миша', 32, 'Уфа']

console.log(Object.entries(person));
// [['name','Миша'],['age',32],['city','Уфа']]

// Практика — подсчёт:
const prices = { a: 100, b: 200, c: 150 };
const total = Object.values(prices).reduce((s, v) => s + v, 0);
console.log(total); // 450`;

document.getElementById('output').textContent = `Object.keys(person)    => ['name','age','city']
Object.values(person)  => ['Миша',32,'Уфа']
Object.entries(person) => [['name','Миша'],['age',32],['city','Уфа']]
Object.values(prices).reduce(sum) => 450`;
