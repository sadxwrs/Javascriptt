document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>Object.assign</code> vs spread для вложенных объектов? Покажи ловушку.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const config = {
  db: { host: 'localhost', port: 5432 },
  app: { port: 3000 }
};

// Поверхностная копия через spread:
const copy1 = { ...config };
copy1.app.port = 9999; // мутирует оригинал!
console.log(config.app.port); // 9999 — ИЗМЕНИЛСЯ!

// Поверхностная копия через assign — то же самое:
const copy2 = Object.assign({}, config);
copy2.db.host = 'remotehost';
console.log(config.db.host); // 'remotehost' — ИЗМЕНИЛСЯ!

// Правильное решение для вложенных:
const deepCopy = JSON.parse(JSON.stringify(config));
// или structuredClone(config)
deepCopy.db.host = 'newhost';
console.log(config.db.host); // 'remotehost' — не изменился!`;

document.getElementById('output').textContent = `copy1 = {...config}; copy1.app.port=9999 => config.app.port=9999 (мутация!)
Object.assign({}, config) — та же ловушка с вложенными
Оба метода: первый уровень независим, вложенные — общие ссылки
Для вложенных: JSON.parse(JSON.stringify) или structuredClone`;
