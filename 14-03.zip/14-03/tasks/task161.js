document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй класс <code>ObservableArray</code> — массив уведомляющий об изменениях через Proxy.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function ObservableArray(onChange) {
  const arr = [];
  return new Proxy(arr, {
    set(target, prop, value, receiver) {
      const result = Reflect.set(target, prop, value, receiver);
      if (prop !== 'length') {
        onChange('set', prop, value);
      }
      return result;
    },
    get(target, prop, receiver) {
      const value = Reflect.get(target, prop, receiver);
      if (['push','pop','shift','unshift','splice'].includes(prop)) {
        return function(...args) {
          const result = value.apply(target, args);
          onChange(prop, args, target);
          return result;
        };
      }
      return value;
    }
  });
}

const arr = ObservableArray((method, args, state) => {
  console.log(\`[\${method}]\`, args, '=> длина:', state?.length ?? arr.length);
});

arr.push(1, 2, 3);  // '[push] [1,2,3] => длина: 3'
arr.pop();          // '[pop] [] => длина: 2'
arr[0] = 99;        // '[set] 0 99'`;

document.getElementById('output').textContent = `arr.push(1,2,3) => '[push] [1,2,3] => длина: 3'
arr.pop()        => '[pop] [] => длина: 2'
arr[0] = 99      => '[set] 0 99'
Proxy перехватывает мутирующие методы массива и прямую запись по индексу`;
