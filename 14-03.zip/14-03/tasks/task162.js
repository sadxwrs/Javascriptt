document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>structuredClone()</code>? Что он поддерживает что не поддерживает?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// structuredClone — нативная глубокая копия (ES2022+)

// Что ПОДДЕРЖИВАЕТ:
const original = {
  date:     new Date(2026, 2, 18),
  map:      new Map([['a', 1]]),
  set:      new Set([1, 2, 3]),
  arr:      [1, [2, [3]]],
  typed:    new Uint8Array([1, 2, 3]),
};
const clone = structuredClone(original);
console.log(clone.date instanceof Date);     // true
console.log(clone.map instanceof Map);       // true
console.log(clone.set instanceof Set);       // true

// Что НЕ ПОДДЕРЖИВАЕТ:
const withFn = { fn: () => 'hello', name: 'test' };
try {
  structuredClone(withFn);
} catch(e) {
  console.log(e.message); // fn — нельзя клонировать функции!
}
// Также не поддерживает: Symbol, DOM-узлы, прототипные методы`;

document.getElementById('output').textContent = `Поддерживает: Date, Map, Set, Array, TypedArray, RegExp, циклические ссылки
NE поддерживает: функции, Symbol, DOM-узлы
structuredClone({ fn: ()=>{} }) => DataCloneError!
Lучше JSON.parse/stringify для простых данных, structuredClone для сложных без функций`;
