document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй систему типов через Symbol: создай <code>Type</code> систему для runtime проверки типов.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `const Type = {
  String:   Symbol('String'),
  Number:   Symbol('Number'),
  Boolean:  Symbol('Boolean'),
  Array:    Symbol('Array'),
  Object:   Symbol('Object'),
  Any:      Symbol('Any'),
};

function typed(schema) {
  return new Proxy(schema, {
    get(target, prop) {
      return { type: target[prop], required: true };
    }
  });
}

function validate(obj, schema) {
  for (const [key, rule] of Object.entries(schema)) {
    const val = obj[key];
    if (rule.required && val === undefined)
      throw new Error(\`Поле '\${key}' обязательно\`);
    if (rule.type === Type.String  && typeof val !== 'string')
      throw new TypeError(\`'\${key}' должно быть строкой\`);
    if (rule.type === Type.Number  && typeof val !== 'number')
      throw new TypeError(\`'\${key}' должно быть числом\`);
  }
  return true;
}

const UserSchema = { name: { type: Type.String, required: true }, age: { type: Type.Number, required: true } };

console.log(validate({ name: 'Аня', age: 25 }, UserSchema));  // true
try { validate({ name: 123, age: 25 }, UserSchema); } catch(e) { console.log(e.message); }`;

document.getElementById('output').textContent = `validate({ name:'Аня', age:25 }, UserSchema) => true
validate({ name:123, age:25 }, UserSchema)   => TypeError: 'name' должно быть строкой
validate({ age:25 }, UserSchema)             => Error: 'name' обязательно
Symbol-типы уникальны => нельзя случайно подделать`;
