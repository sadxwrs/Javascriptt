document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое WeakRef и как его использовать для кеша не мешающего сборке мусора?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `class WeakCache {
  #cache = new Map();

  set(key, value) {
    this.#cache.set(key, new WeakRef(value));
  }

  get(key) {
    const ref = this.#cache.get(key);
    if (!ref) return undefined;
    const value = ref.deref();
    if (!value) {
      // Объект удалён GC — очистить запись
      this.#cache.delete(key);
      return undefined;
    }
    return value;
  }

  has(key) {
    return this.get(key) !== undefined;
  }
}

const cache = new WeakCache();
let bigObj = { data: new Array(10000).fill('x') };
cache.set('big', bigObj);

console.log(cache.has('big')); // true
console.log(cache.get('big').data.length); // 10000

bigObj = null; // GC может удалить
// После GC: cache.get('big') => undefined`;

document.getElementById('output').textContent = `cache.has('big') => true (объект жив)
cache.get('big').data.length => 10000
bigObj = null => GC может удалить объект
cache.get('big') => undefined (после GC)
WeakRef не мешает GC удалить объект`;
