document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй паттерн <code>Command</code>: история операций над объектом с возможностью отмены (<code>undo</code>).<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `class CommandHistory {
  #history = [];
  #target;

  constructor(target) { this.#target = target; }

  execute(command) {
    command.execute(this.#target);
    this.#history.push(command);
  }

  undo() {
    const cmd = this.#history.pop();
    if (cmd) cmd.undo(this.#target);
  }
}

const SetProperty = (prop, value) => {
  let prevValue;
  return {
    execute(obj) { prevValue = obj[prop]; obj[prop] = value; },
    undo(obj)    { obj[prop] = prevValue; }
  };
};

const user = { name: 'Аня', age: 25 };
const history = new CommandHistory(user);

history.execute(SetProperty('name', 'Боря'));
history.execute(SetProperty('age', 30));
console.log(user); // { name:'Боря', age:30 }

history.undo();
console.log(user); // { name:'Боря', age:25 } — age вернулся
history.undo();
console.log(user); // { name:'Аня', age:25 } — name вернулся`;

document.getElementById('output').textContent = `После execute (name='Боря', age=30): { name:'Боря', age:30 }
Undo age: { name:'Боря', age:25 }
Undo name: { name:'Аня', age:25 }
Command: execute + undo
CommandHistory хранит стек команд`;
