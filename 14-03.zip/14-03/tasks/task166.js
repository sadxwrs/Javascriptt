document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>Object.keys()</code> для <code>class</code>? Почему методы класса не перечисляются?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `class Animal {
  constructor(name) { this.name = name; }
  speak() { return \`\${this.name} говорит\`; }
  toString() { return \`Animal(\${this.name})\`; }
}

const cat = new Animal('Мурка');

// Object.keys — только собственные ПЕРЕЧИСЛЯЕМЫЕ:
console.log(Object.keys(cat)); // ['name']
// speak и toString не видны!

// Почему? Методы класса на прототипе с enumerable: false
const desc = Object.getOwnPropertyDescriptor(Animal.prototype, 'speak');
console.log(desc.enumerable); // false!

// Все свойства прототипа:
console.log(Object.getOwnPropertyNames(Animal.prototype));
// ['constructor', 'speak', 'toString']

// Сравни с функцией-конструктором:
function OldAnimal(name) { this.name = name; this.speak = () => 'привет'; }
const old = new OldAnimal('Рекс');
console.log(Object.keys(old)); // ['name', 'speak']`;

document.getElementById('output').textContent = `Object.keys(cat) => ['name'] (методы не перечисляются!)
Animal.prototype.speak: enumerable => false (так работают классы)
Object.getOwnPropertyNames(Animal.prototype) => ['constructor','speak','toString']
Функция-конструктор: методы через this — перечисляемые
Класс: методы на прототипе — неперечисляемые`;
