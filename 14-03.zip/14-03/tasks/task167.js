document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>Proxy</code> + <code>Symbol.toPrimitive</code>? Создай объект который ведёт себя как число и как строка одновременно.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function createDualType(numVal, strVal) {
  const obj = {
    [Symbol.toPrimitive](hint) {
      if (hint === 'number') return numVal;
      if (hint === 'string') return strVal;
      return numVal; // default — числовой
    }
  };

  return new Proxy(obj, {
    get(target, prop, receiver) {
      // Поддержка методов строки
      if (typeof strVal[prop] === 'function') {
        return strVal[prop].bind(strVal);
      }
      return Reflect.get(target, prop, receiver);
    }
  });
}

const dual = createDualType(42, 'hello');

console.log(+dual);           // 42
console.log(\`\${dual}\`);       // 'hello'
console.log(dual + 8);        // 50
console.log(dual.toUpperCase()); // 'HELLO'
console.log(dual.length);     // 5`;

document.getElementById('output').textContent = `+dual          => 42 (числовой контекст)
\`\${dual}\`       => 'hello' (строковый контекст)
dual + 8        => 50 (default = числовой)
dual.toUpperCase() => 'HELLO' (proxy делегирует к строке)
dual.length     => 5`;
