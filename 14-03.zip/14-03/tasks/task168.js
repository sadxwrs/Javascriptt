document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй безопасный доступ к вложенным свойствам через функцию <code>safe(obj)</code> возвращающую Proxy.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function safe(obj) {
  if (obj === null || obj === undefined) {
    // Возвращаем Proxy-пустышку
    return new Proxy({}, {
      get() { return safe(undefined); },
      // valueOf для извлечения реального значения
      apply() { return undefined; }
    });
  }

  return new Proxy(obj, {
    get(target, prop) {
      if (prop === '_value') return target;
      const value = target[prop];
      return (value === null || value === undefined)
        ? safe(value)
        : (typeof value === 'object' ? safe(value) : value);
    }
  });
}

const data = { user: { name: 'Аня', address: { city: 'Москва' } } };

console.log(safe(data).user.name);          // 'Аня'
console.log(safe(data).user.address.city); // 'Москва'
console.log(safe(data).missing.deep.path); // safe(undefined) — нет ошибки!
console.log(safe(null).any.path.ever);     // safe(undefined) — нет ошибки!`;

document.getElementById('output').textContent = `safe(data).user.name          => 'Аня'
safe(data).user.address.city => 'Москва'
safe(data).missing.deep.path => safe(undefined) (нет TypeError!)
safe(null).any.path.ever     => нет ошибки
Proxy перехватывает доступ к несуществующим свойствам`;
