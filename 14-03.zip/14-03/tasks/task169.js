document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>schema validator</code>: функцию <code>createSchema(rules)</code> для валидации объектов.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function createSchema(rules) {
  return {
    validate(obj) {
      const errors = [];
      for (const [field, rule] of Object.entries(rules)) {
        const val = obj[field];
        if (rule.required && (val === undefined || val === null))
          errors.push(\`'\${field}' обязательно\`);
        if (val !== undefined && rule.type && typeof val !== rule.type)
          errors.push(\`'\${field}': ожидался \${rule.type}, получен \${typeof val}\`);
        if (rule.min !== undefined && val < rule.min)
          errors.push(\`'\${field}' минимум: \${rule.min}\`);
        if (rule.max !== undefined && val > rule.max)
          errors.push(\`'\${field}' максимум: \${rule.max}\`);
        if (rule.pattern && !rule.pattern.test(val))
          errors.push(\`'\${field}' не соответствует паттерну\`);
      }
      return { valid: errors.length === 0, errors };
    }
  };
}

const UserSchema = createSchema({
  name:  { required: true, type: 'string' },
  age:   { required: true, type: 'number', min: 0, max: 120 },
  email: { required: false, pattern: /@/ }
});

console.log(UserSchema.validate({ name: 'Аня', age: 25 }));
// { valid: true, errors: [] }
console.log(UserSchema.validate({ name: 123, age: -5 }).errors);`;

document.getElementById('output').textContent = `validate({ name:'Аня', age:25 }) => { valid:true, errors:[] }
validate({ name:123, age:-5 }).errors =>
["'name': ожидался string, получен number", "'age' минимум: 0", "'name' обязательно" нет]`;
