document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как создать объект из массива пар [ключ, значение] с помощью Object.fromEntries()?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Из массива пар:
const pairs = [['name', 'Оля'], ['age', 24], ['city', 'Сочи']];
const obj = Object.fromEntries(pairs);
console.log(obj); // { name:'Оля', age:24, city:'Сочи' }

// Из Map:
const map = new Map([['x', 1], ['y', 2]]);
console.log(Object.fromEntries(map)); // { x:1, y:2 }

// Паттерн трансформации объекта:
const prices = { apple: 100, banana: 50 };
const doubled = Object.fromEntries(
  Object.entries(prices).map(([k, v]) => [k, v * 2])
);
console.log(doubled); // { apple:200, banana:100 }`;

document.getElementById('output').textContent = `Object.fromEntries([['name','Оля'],['age',24]]) => { name:'Оля', age:24 }
Object.fromEntries(map) => { x:1, y:2 }
Трансформация: entries => map => fromEntries => { apple:200, banana:100 }`;
