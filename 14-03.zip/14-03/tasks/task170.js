document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>Reflect.ownKeys()</code>? Покажи разницу между всеми методами получения ключей объекта.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const sym = Symbol('s');
const obj = {};
obj.enumProp = 'перечисляемое';
Object.defineProperty(obj, 'nonEnum', { value: 'неперечисляемое', enumerable: false });
obj[sym] = 'символьное';

// Сравниваем все методы:
console.log(Object.keys(obj));
// ['enumProp']
// Только собственные перечисляемые строковые

console.log(Object.getOwnPropertyNames(obj));
// ['enumProp', 'nonEnum']
// Все собственные строковые (включая неперечисляемые)

console.log(Object.getOwnPropertySymbols(obj));
// [Symbol(s)]
// Только Symbol-ключи

console.log(Reflect.ownKeys(obj));
// ['enumProp', 'nonEnum', Symbol(s)]
// ВСЕ собственные ключи без исключения`;

document.getElementById('output').textContent = `Object.keys:                ['enumProp']
Object.getOwnPropertyNames: ['enumProp','nonEnum']
Object.getOwnPropertySymbols: [Symbol(s)]
Reflect.ownKeys:             ['enumProp','nonEnum',Symbol(s)]
Reflect.ownKeys — самый полный: строки + Symbol + неперечисляемые`;
