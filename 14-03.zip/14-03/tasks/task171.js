document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>createEnum()</code> — функцию создающую иммутабельный перечислимый тип через Symbol и Proxy.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function createEnum(...values) {
  const enumObj = {};

  for (const val of values) {
    enumObj[val] = Symbol(val);
  }

  return new Proxy(Object.freeze(enumObj), {
    get(target, prop) {
      if (prop in target) return target[prop];
      throw new ReferenceError(\`'\${String(prop)}' не является значением этого Enum\`);
    },
    set() {
      throw new TypeError('Enum иммутабелен');
    }
  });
}

const Status = createEnum('PENDING', 'ACTIVE', 'BLOCKED', 'DELETED');

console.log(Status.PENDING);              // Symbol(PENDING)
console.log(Status.ACTIVE !== Status.PENDING); // true (Symbol уникальны)

try { Status.NEW = 'test'; } catch(e) { console.log(e.message); }
// 'Enum иммутабелен'

try { console.log(Status.UNKNOWN); } catch(e) { console.log(e.message); }
// "'UNKNOWN' не является значением этого Enum"`;

document.getElementById('output').textContent = `Status.PENDING  => Symbol(PENDING)
Status.ACTIVE !== Status.PENDING => true
Status.NEW = 'x' => TypeError: Enum иммутабелен
Status.UNKNOWN   => ReferenceError: 'UNKNOWN' не является значением этого Enum
Symbol гарантирует уникальность значений Enum`;
