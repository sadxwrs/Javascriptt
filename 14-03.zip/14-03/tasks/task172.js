document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>this</code> в стрелочных функциях внутри класса? Почему они не подходят для методов прототипа?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `class Timer {
  constructor() {
    this.count = 0;
    // Стрелочная как поле класса — this фиксирован:
    this.tick = () => {
      this.count++;
      console.log(this.count);
    };
  }

  // Обычный метод прототипа:
  reset() { this.count = 0; }
}

const t = new Timer();
t.tick(); // 1 (this === t)
const fn = t.tick;
fn(); // 2 (this всё ещё t — стрелочная!)

// Проблема стрелочных на прототипе:
class BadTimer {
  tick = () => this.count++; // копия для КАЖДОГО экземпляра!
}
// vs
class GoodTimer {
  tick() { this.count++; } // одна функция для всех
}

console.log(Object.keys(new BadTimer()));  // ['tick'] (поле экземпляра)
console.log(Object.keys(new GoodTimer())); // [] (метод на прототипе)`;

document.getElementById('output').textContent = `t.tick() => 1
const fn = t.tick; fn() => 2 (this сохранён!)
Стрелочная на прототипе: копия для каждого экземпляра (расход памяти)
Обычный метод: одна копия на прототипе
Object.keys(new BadTimer()) => ['tick'] (поле)
Object.keys(new GoodTimer()) => [] (метод на прототипе)`;
