document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>deepProxy(obj, handler)</code> — Proxy применяющий ловушки рекурсивно ко всем вложенным объектам.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function deepProxy(obj, handler) {
  if (obj === null || typeof obj !== 'object') return obj;

  const deepHandler = {
    ...handler,
    get(target, prop, receiver) {
      const value = handler.get
        ? handler.get(target, prop, receiver)
        : Reflect.get(target, prop, receiver);
      // Рекурсивно оборачиваем вложенные объекты
      if (value && typeof value === 'object') {
        return deepProxy(value, handler);
      }
      return value;
    }
  };
  return new Proxy(obj, deepHandler);
}

const log = [];
const state = deepProxy(
  { user: { name: 'Аня', scores: [10, 20] } },
  {
    set(target, prop, value, receiver) {
      log.push(\`SET \${String(prop)} = \${JSON.stringify(value)}\`);
      return Reflect.set(target, prop, value, receiver);
    }
  }
);

state.user.name = 'Боря';    // SET name = "Боря"
state.user.scores[0] = 99;  // SET 0 = 99
console.log(log);`;

document.getElementById('output').textContent = `state.user.name = 'Боря' => log: ['SET name = "Боря"']
state.user.scores[0] = 99 => log: ['SET name = "Боря"', 'SET 0 = 99']
Proxy применяется рекурсивно при каждом get вложенного объекта`;
