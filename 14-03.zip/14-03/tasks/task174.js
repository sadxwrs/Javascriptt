document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>Object.isFrozen()</code>, <code>Object.isSealed()</code>, <code>Object.isExtensible()</code>?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const a = { x: 1 };
const b = Object.seal({ x: 1 });
const c = Object.freeze({ x: 1 });
const d = Object.preventExtensions({ x: 1 });

// isExtensible: можно ли добавлять новые свойства?
console.log(Object.isExtensible(a)); // true
console.log(Object.isExtensible(b)); // false (seal запрещает)
console.log(Object.isExtensible(c)); // false (freeze запрещает)
console.log(Object.isExtensible(d)); // false

// isSealed: нельзя добавлять/удалять?
console.log(Object.isSealed(a)); // false
console.log(Object.isSealed(b)); // true
console.log(Object.isSealed(c)); // true (freeze сильнее)

// isFrozen: нельзя ничего (включая изменение)?
console.log(Object.isFrozen(a)); // false
console.log(Object.isFrozen(b)); // false (seal разрешает менять)
console.log(Object.isFrozen(c)); // true`;

document.getElementById('output').textContent = `isExtensible(обычный) => true
isExtensible(sealed)  => false
isExtensible(frozen)  => false
isFrozen(sealed) => false (seal разрешает изменение значений)
isFrozen(frozen) => true
Градация: freeze > seal > preventExtensions`;
