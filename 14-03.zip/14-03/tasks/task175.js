document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй паттерн <code>Memento</code>: сохранение и восстановление состояния объекта.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `class Memento {
  #snapshots = [];
  #current;

  constructor(initialState) {
    this.#current = structuredClone(initialState);
  }

  get state() { return structuredClone(this.#current); }

  set state(newState) {
    this.#snapshots.push(structuredClone(this.#current));
    this.#current = structuredClone(newState);
  }

  undo() {
    if (!this.#snapshots.length) return false;
    this.#current = this.#snapshots.pop();
    return true;
  }

  get canUndo() { return this.#snapshots.length > 0; }
}

const m = new Memento({ text: '', cursor: 0 });
m.state = { text: 'Привет', cursor: 6 };
m.state = { text: 'Привет мир', cursor: 10 };

console.log(m.state.text); // 'Привет мир'
m.undo();
console.log(m.state.text); // 'Привет'
m.undo();
console.log(m.state.text); // ''`;

document.getElementById('output').textContent = `m.state.text => 'Привет мир'
m.undo()
m.state.text => 'Привет'
m.undo()
m.state.text => '' (начальное)
Memento: snapshots хранят историю состояний для undo`;
