document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>Symbol.toStringTag</code>? Как использовать его для кастомного вывода типа объекта?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Symbol.toStringTag меняет тег в Object.prototype.toString

class LinkedList {
  get [Symbol.toStringTag]() { return 'LinkedList'; }
}

class Queue {
  get [Symbol.toStringTag]() { return 'Queue'; }
}

const ll = new LinkedList();
const q  = new Queue();

console.log(Object.prototype.toString.call(ll)); // '[object LinkedList]'
console.log(Object.prototype.toString.call(q));  // '[object Queue]'

// Без кастомного тега:
class Plain {}
console.log(Object.prototype.toString.call(new Plain())); // '[object Object]'

// Встроенные тоже используют Symbol.toStringTag:
console.log(Object.prototype.toString.call(new Map()));  // '[object Map]'
console.log(Object.prototype.toString.call(new Set()));  // '[object Set]'
console.log(Object.prototype.toString.call(Promise.resolve())); // '[object Promise]'`;

document.getElementById('output').textContent = `toString(new LinkedList()) => '[object LinkedList]'
toString(new Queue())      => '[object Queue]'
toString(new Plain())      => '[object Object]' (нет тега)
toString(new Map())        => '[object Map]' (встроенный тег)
Symbol.toStringTag — инструмент для идентификации кастомных типов`;
