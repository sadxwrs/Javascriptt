document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>throttle(fn, delay)</code> и <code>debounce(fn, delay)</code> для методов объекта.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function throttle(fn, delay) {
  let lastCall = 0;
  return function(...args) {
    const now = Date.now();
    if (now - lastCall >= delay) {
      lastCall = now;
      return fn.apply(this, args);
    }
  };
}

function debounce(fn, delay) {
  let timer;
  return function(...args) {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), delay);
  };
}

const api = {
  data: [],
  // Не чаще раза в 200мс:
  fetch: throttle(function() {
    console.log('fetch:', Date.now());
    return 'данные';
  }, 200),
  // Только после 300мс паузы:
  search: debounce(function(q) {
    console.log('search:', q);
  }, 300)
};

api.fetch(); // выполнится
api.fetch(); // проигнорируется (слишком быстро)
api.search('JS'); api.search('JS P'); api.search('JS Pro');
// Только последний через 300мс: 'search: JS Pro'`;

document.getElementById('output').textContent = `api.fetch() x2 быстро => только первый выполнится
api.search('JS'); api.search('JS P'); api.search('JS Pro');
=> только последний: 'search: JS Pro' (через 300мс)
throttle: не чаще чем раз в delay мс
debounce: только после delay мс паузы`;
