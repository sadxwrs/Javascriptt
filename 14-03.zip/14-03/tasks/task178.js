document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>createStore(reducer, initialState)</code> — простой Redux-подобный стор.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function createStore(reducer, initialState) {
  let state = initialState;
  const listeners = [];

  return {
    getState() { return state; },

    dispatch(action) {
      state = reducer(state, action);
      listeners.forEach(l => l(state));
      return action;
    },

    subscribe(listener) {
      listeners.push(listener);
      return () => {
        const idx = listeners.indexOf(listener);
        if (idx > -1) listeners.splice(idx, 1);
      };
    }
  };
}

function counterReducer(state = { count: 0 }, action) {
  switch (action.type) {
    case 'INCREMENT': return { ...state, count: state.count + (action.by ?? 1) };
    case 'DECREMENT': return { ...state, count: state.count - 1 };
    case 'RESET':     return { count: 0 };
    default:          return state;
  }
}

const store = createStore(counterReducer, { count: 0 });
const unsub = store.subscribe(s => console.log('state:', s.count));

store.dispatch({ type: 'INCREMENT' });      // state: 1
store.dispatch({ type: 'INCREMENT', by: 4 }); // state: 5
store.dispatch({ type: 'DECREMENT' });     // state: 4
unsub(); // отписались
store.dispatch({ type: 'RESET' }); // тишина (нет подписчиков)`;

document.getElementById('output').textContent = `dispatch(INCREMENT)       => state: 1
dispatch(INCREMENT, by:4) => state: 5
dispatch(DECREMENT)       => state: 4
unsub() — отписались
dispatch(RESET)           => тишина (нет подписчиков)`;
