document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>Object.setPrototypeOf()</code>? Когда его использование оправдано и когда нет?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `const canSwim = { swim() { return \`\${this.name} плывёт\`; } };
const canFly  = { fly()  { return \`\${this.name} летит\`;  } };

const duck = { name: 'Дональд' };

// Установить прототип (после создания):
Object.setPrototypeOf(duck, canSwim);
console.log(duck.swim()); // 'Дональд плывёт'

// Заменить прототип:
Object.setPrototypeOf(duck, canFly);
console.log(duck.fly()); // 'Дональд летит'
// console.log(duck.swim()); // TypeError (prototip заменён!)

// ПРЕДУПРЕЖДЕНИЕ: setPrototypeOf медленная операция!
// Движок JS оптимизирует объекты под конкретный прототип.
// Смена прототипа ломает оптимизацию — избегай в горячих путях!

// Лучше: Object.create(proto) при создании
const betterDuck = Object.create(canSwim);
betterDuck.name = 'Скрудж';
console.log(betterDuck.swim()); // 'Скрудж плывёт'`;

document.getElementById('output').textContent = `Object.setPrototypeOf(duck, canSwim) => duck.swim() = 'Дональд плывёт'
После замены прототипа: duck.fly() = 'Дональд летит'
duck.swim() => TypeError (прототип заменён!)
Предупреждение: setPrototypeOf медленная операция, ломает JIT-оптимизации
Лучше: Object.create(proto) при создании объекта`;
