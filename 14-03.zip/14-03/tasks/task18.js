document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что делает Object.freeze()? Напиши пример — покажи что объект нельзя изменить после заморозки.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const config = Object.freeze({ host: 'localhost', port: 3000 });

// Попытки изменить — молча игнорируются (в strict mode — ошибка):
config.port = 8080;
console.log(config.port); // 3000 — не изменился!

config.newProp = 'test';
console.log(config.newProp); // undefined — не добавилось!

delete config.host;
console.log(config.host); // 'localhost' — не удалилось!

console.log(Object.isFrozen(config)); // true`;

document.getElementById('output').textContent = `config.port = 8080 => игнорируется
config.port        => 3000 (не изменился)
config.newProp     => undefined (не добавилось)
delete config.host => игнорируется
Object.isFrozen(config) => true`;
