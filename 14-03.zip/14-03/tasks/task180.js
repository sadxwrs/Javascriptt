document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>pipe(...fns)</code> и <code>compose(...fns)</code> для трансформации объектов.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// pipe: применяет функции слева направо
const pipe = (...fns) => x => fns.reduce((v, f) => f(v), x);

// compose: применяет функции справа налево
const compose = (...fns) => x => fns.reduceRight((v, f) => f(v), x);

// Трансформации объекта:
const addTimestamp   = obj => ({ ...obj, createdAt: new Date().toISOString() });
const normalizeEmail = obj => ({ ...obj, email: obj.email?.toLowerCase() });
const setRole        = role => obj => ({ ...obj, role });
const removePassword = ({ password, ...rest }) => rest;

const processUser = pipe(
  normalizeEmail,
  setRole('user'),
  addTimestamp,
  removePassword
);

const raw = { name: 'Аня', email: 'ANYA@MAIL.RU', password: 'secret' };
const processed = processUser(raw);

console.log(processed.email);     // 'anya@mail.ru'
console.log(processed.role);      // 'user'
console.log('password' in processed); // false
console.log('createdAt' in processed); // true`;

document.getElementById('output').textContent = `processed.email     => 'anya@mail.ru' (нормализован)
processed.role       => 'user'
'password' in processed => false (удалён)
'createdAt' in processed => true
pipe(f,g,h)(x) = h(g(f(x))) — слева направо`;
