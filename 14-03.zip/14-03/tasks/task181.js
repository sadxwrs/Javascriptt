document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое дескриптор доступа (accessor descriptor) vs дескриптор данных (data descriptor)?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Data descriptor: value + writable
const obj = {};
Object.defineProperty(obj, 'data', {
  value:      42,
  writable:   true,
  enumerable: true,
  configurable: true
});

// Accessor descriptor: get + set (без value и writable!)
Object.defineProperty(obj, 'doubled', {
  get() { return obj.data * 2; },
  set(v) { obj.data = v / 2; },
  enumerable: true,
  configurable: true
});

console.log(obj.doubled); // 84
obj.doubled = 100;
console.log(obj.data);    // 50

// Нельзя смешивать value и get в одном дескрипторе:
try {
  Object.defineProperty(obj, 'bad', { value: 1, get() { return 2; } });
} catch(e) {
  console.log(e.message); // Invalid property descriptor
}`;

document.getElementById('output').textContent = `obj.doubled => 84 (42 * 2)
obj.doubled = 100 => obj.data = 50
Data descriptor: value + writable
Accessor descriptor: get + set (без value!)
Смешивать нельзя => TypeError: Invalid property descriptor`;
