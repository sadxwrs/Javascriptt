document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>createPubSub()</code> — систему публикации/подписки для объектов.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function createPubSub() {
  const subs = {};

  return {
    subscribe(topic, fn) {
      if (!subs[topic]) subs[topic] = new Set();
      subs[topic].add(fn);
      return () => subs[topic].delete(fn); // отписка
    },

    publish(topic, data) {
      (subs[topic] || new Set()).forEach(fn => fn(data));
    },

    once(topic, fn) {
      const wrapper = (data) => { fn(data); unsub(); };
      const unsub = this.subscribe(topic, wrapper);
      return unsub;
    },

    topics() { return Object.keys(subs); }
  };
}

const bus = createPubSub();

const unsub = bus.subscribe('user:login', u => console.log('Вход:', u.name));
bus.once('app:init', () => console.log('Инициализация!'));

bus.publish('user:login', { name: 'Аня' }); // 'Вход: Аня'
bus.publish('app:init');  // 'Инициализация!'
bus.publish('app:init');  // тишина (once)
unsub();
bus.publish('user:login', { name: 'Боря' }); // тишина (отписались)`;

document.getElementById('output').textContent = `publish('user:login', {name:'Аня'}) => 'Вход: Аня'
publish('app:init') => 'Инициализация!'
publish('app:init') => тишина (once)
unsub(); publish('user:login',...) => тишина (отписались)
PubSub: паттерн отделения издателей от подписчиков`;
