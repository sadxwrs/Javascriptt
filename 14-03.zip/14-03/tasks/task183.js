document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>createFSM(states)</code> — конечный автомат (Finite State Machine) через объекты.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function createFSM(config) {
  let current = config.initial;

  return {
    get state() { return current; },

    send(event) {
      const stateConfig = config.states[current];
      const next = stateConfig?.on?.[event];
      if (!next) {
        console.log(\`Нет перехода '\${event}' из '\${current}'\`);
        return false;
      }
      console.log(\`\${current} --[\${event}]--> \${next}\`);
      current = next;
      config.states[current]?.entry?.();
      return true;
    }
  };
}

const trafficLight = createFSM({
  initial: 'red',
  states: {
    red:    { on: { GO: 'green'  }, entry: () => console.log('🔴 Стоп') },
    green:  { on: { SLOW: 'yellow' }, entry: () => console.log('🟢 Едем') },
    yellow: { on: { STOP: 'red'  }, entry: () => console.log('🟡 Осторожно') }
  }
});

trafficLight.send('GO');   // red --[GO]--> green, 🟢 Едем
trafficLight.send('SLOW'); // green --[SLOW]--> yellow, 🟡 Осторожно
trafficLight.send('GO');   // Нет перехода 'GO' из 'yellow'`;

document.getElementById('output').textContent = `send('GO')   => 'red --[GO]--> green', '🟢 Едем'
send('SLOW') => 'green --[SLOW]--> yellow', '🟡 Осторожно'
send('GO')   => 'Нет перехода GO из yellow'
FSM: строгие переходы между состояниями`;
