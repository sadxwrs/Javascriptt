document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>toString()</code> и <code>valueOf()</code> в прототипной цепочке? Как они наследуются?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Object.prototype содержит toString и valueOf
// Все объекты наследуют их

const base = {
  value: 100,
  toString() { return \`Base(\${this.value})\`; },
  valueOf()  { return this.value; }
};

const child = Object.create(base);
child.value = 200;

// child наследует toString и valueOf:
console.log(String(child));   // 'Base(200)' (this = child!)
console.log(+child);          // 200
console.log(child + 50);      // 250

// Переопределение в child:
child.toString = function() { return \`Child(\${this.value})\`; };
console.log(String(child));   // 'Child(200)' (переопределено)
console.log(String(base));    // 'Base(100)' (base не изменился)

// Цепочка: child -> base -> Object.prototype -> null`;

document.getElementById('output').textContent = `String(child) => 'Base(200)' (this = child, наследует toString)
+child        => 200 (наследует valueOf)
child + 50    => 250
После переопределения: String(child) => 'Child(200)'
String(base)  => 'Base(100)' (не изменился)`;
