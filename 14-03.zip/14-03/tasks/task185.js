document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию <code>safeGet(obj, path, defaultValue)</code> безопасно читающую вложенные свойства.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function safeGet(obj, path, defaultValue = undefined) {
  if (!path) return obj ?? defaultValue;
  const keys = Array.isArray(path) ? path : path.split('.');
  let current = obj;
  for (const key of keys) {
    if (current === null || current === undefined) {
      return defaultValue;
    }
    current = current[key];
  }
  return current === undefined ? defaultValue : current;
}

const data = {
  user: { name: 'Аня', scores: [85, 92], address: null }
};

console.log(safeGet(data, 'user.name'));          // 'Аня'
console.log(safeGet(data, 'user.scores.0'));       // 85
console.log(safeGet(data, 'user.address.city', 'N/A')); // 'N/A'
console.log(safeGet(data, 'missing.deep', 'дефолт')); // 'дефолт'
console.log(safeGet(null, 'anything', 0));         // 0`;

document.getElementById('output').textContent = `safeGet(data, 'user.name')          => 'Аня'
safeGet(data, 'user.scores.0')       => 85
safeGet(data, 'user.address.city', 'N/A') => 'N/A' (address=null)
safeGet(data, 'missing.deep', 'дефолт') => 'дефолт'
safeGet(null, 'anything', 0)         => 0`;
