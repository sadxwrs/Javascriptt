document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>createLens(key)</code> — функциональную линзу для иммутабельного обновления объектов.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Линза (lens) — пара get/set для конкретного пути
function createLens(key) {
  return {
    get: obj => obj[key],
    set: (obj, value) => ({ ...obj, [key]: value })
  };
}

function composeLens(outer, inner) {
  return {
    get: obj => inner.get(outer.get(obj)),
    set: (obj, value) => outer.set(obj, inner.set(outer.get(obj), value))
  };
}

const nameLens    = createLens('name');
const addressLens = createLens('address');
const cityLens    = createLens('city');
const addressCityLens = composeLens(addressLens, cityLens);

const user = { name: 'Аня', address: { city: 'Москва', zip: '101000' } };

// Чтение:
console.log(nameLens.get(user));         // 'Аня'
console.log(addressCityLens.get(user));  // 'Москва'

// Иммутабельное обновление:
const updated = addressCityLens.set(user, 'Питер');
console.log(updated.address.city); // 'Питер'
console.log(user.address.city);    // 'Москва' (не изменился!)`;

document.getElementById('output').textContent = `nameLens.get(user)        => 'Аня'
addressCityLens.get(user) => 'Москва'
addressCityLens.set(user, 'Питер') => новый объект
updated.address.city => 'Питер'
user.address.city    => 'Москва' (иммутабельно!)`;
