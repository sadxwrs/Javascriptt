document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>Object.preventExtensions()</code>? Чем отличается от <code>seal</code> и <code>freeze</code>?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const obj = { x: 1, y: 2 };
Object.preventExtensions(obj);

// Нельзя ДОБАВЛЯТЬ новые свойства:
obj.z = 3;
console.log(obj.z); // undefined (не добавилось!)

// Можно ИЗМЕНЯТЬ существующие:
obj.x = 99;
console.log(obj.x); // 99

// Можно УДАЛЯТЬ:
delete obj.y;
console.log(obj.y); // undefined (удалено)

// Сравнение трёх методов:
//                    | preventExtensions | seal  | freeze
// Добавить свойство | ❌                | ❌    | ❌
// Изменить значение  | ✅                | ✅    | ❌
// Удалить свойство  | ✅                | ❌    | ❌

console.log(Object.isExtensible(obj)); // false`;

document.getElementById('output').textContent = `preventExtensions: нельзя добавлять, можно менять и удалять
seal:              нельзя добавлять и удалять, можно менять
freeze:            нельзя ничего
obj.z = 3 => не добавилось
obj.x = 99 => изменилось!
delete obj.y => удалилось!`;
