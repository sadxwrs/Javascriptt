document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>createTypedObject(schema)</code> — объект с автовалидацией через Proxy.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function createTypedObject(schema) {
  const data = {};

  return new Proxy(data, {
    set(target, prop, value) {
      const rule = schema[prop];
      if (!rule) throw new Error(\`Поле '\${prop}' не в схеме\`);
      if (typeof value !== rule.type)
        throw new TypeError(\`'\${prop}': ожидался \${rule.type}\`);
      if (rule.min !== undefined && value < rule.min)
        throw new RangeError(\`'\${prop}' минимум: \${rule.min}\`);
      if (rule.max !== undefined && value > rule.max)
        throw new RangeError(\`'\${prop}' максимум: \${rule.max}\`);
      return Reflect.set(target, prop, value);
    }
  });
}

const user = createTypedObject({
  name: { type: 'string' },
  age:  { type: 'number', min: 0, max: 120 }
});

user.name = 'Катя';  // OK
user.age  = 25;      // OK
console.log(user.name, user.age); // 'Катя' 25

try { user.age = -5; } catch(e) { console.log(e.message); }
// "'age' минимум: 0"
try { user.name = 123; } catch(e) { console.log(e.message); }
// "'name': ожидался string"`;

document.getElementById('output').textContent = `user.name = 'Катя' => OK
user.age = 25 => OK
user.age = -5  => RangeError: 'age' минимум: 0
user.name = 123 => TypeError: 'name' ожидался string
Proxy валидирует при каждом присваивании`;
