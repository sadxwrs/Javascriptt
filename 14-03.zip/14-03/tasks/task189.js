document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>createChain(obj)</code> — обёртку для цепочки операций с объектом и извлечения результата.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function createChain(obj) {
  let value = typeof obj === 'object' ? { ...obj } : obj;

  const chain = {
    map(fn) {
      value = fn(value);
      return chain;
    },
    filter(fn) {
      if (typeof value === 'object' && !Array.isArray(value)) {
        value = Object.fromEntries(
          Object.entries(value).filter(([k, v]) => fn(v, k))
        );
      }
      return chain;
    },
    tap(fn) {
      fn(value);
      return chain;
    },
    value() { return value; }
  };
  return chain;
}

const result = createChain({ a: 1, b: -2, c: 3, d: -4 })
  .filter(v => v > 0)                    // { a:1, c:3 }
  .map(obj => Object.fromEntries(
    Object.entries(obj).map(([k,v]) => [k, v * 10])
  ))                                      // { a:10, c:30 }
  .tap(v => console.log('tap:', v))       // 'tap: {a:10,c:30}'
  .value();

console.log(result); // { a:10, c:30 }`;

document.getElementById('output').textContent = `chain
.filter(v>0)      => { a:1, c:3 }
.map(v*10)        => { a:10, c:30 }
.tap(console.log) => 'tap: {a:10,c:30}'
.value()          => { a:10, c:30 }`;
