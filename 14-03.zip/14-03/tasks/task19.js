document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что делает Object.seal()? Чем отличается от Object.freeze()?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const obj = Object.seal({ name: 'Тест', value: 42 });

// seal: можно ИЗМЕНЯТЬ существующие свойства:
obj.value = 100;
console.log(obj.value); // 100

// seal: НЕЛЬЗЯ добавлять новые:
obj.newProp = 'x';
console.log(obj.newProp); // undefined

// seal: НЕЛЬЗЯ удалять:
delete obj.name;
console.log(obj.name); // 'Тест'

console.log(Object.isSealed(obj)); // true

// Итог:
// freeze: нельзя ничего (полная заморозка)
// seal:   можно менять значения, нельзя добавлять/удалять`;

document.getElementById('output').textContent = `seal: МОЖНО менять значения: obj.value=100 => 100
seal: НЕЛЬЗЯ добавлять: obj.newProp='x' => undefined
seal: НЕЛЬЗЯ удалять: delete obj.name => 'Тест' сохранился
freeze vs seal: freeze блокирует всё, seal разрешает изменение значений`;
