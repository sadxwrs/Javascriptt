document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>Abstract Type Conversion</code> в спецификации ECMA-262? Как он связан с ToPrimitive?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// ECMA-262 описывает абстрактные операции для преобразований

// ToPrimitive(input, preferredType?) — главная:
// 1. Если уже примитив — вернуть как есть
// 2. Вызвать Symbol.toPrimitive(hint) если есть
// 3. Иначе по preferredType:
//    'number': сначала valueOf(), потом toString()
//    'string': сначала toString(), потом valueOf()
//    'default': как 'number'

const obj = {
  [Symbol.toPrimitive](hint) {
    console.log('hint:', hint);
    return hint === 'string' ? 'строка' : 42;
  }
};

// ToNumber(input) — используется при +obj:
+obj; // hint: number => 42

// ToString(input) — используется при \${obj}:
\`\${obj}\`; // hint: string => 'строка'

// ToBoolean(input) — объекты ВСЕГДА truthy:
if (obj) console.log('объект truthy'); // выведет
if ({})  console.log('{} truthy');      // выведет`;

document.getElementById('output').textContent = `ToPrimitive: вызывает Symbol.toPrimitive(hint) или valueOf/toString
+obj    => hint:'number' => 42
\`\${obj}\` => hint:'string' => 'строка'
ToBoolean: объекты ВСЕГДА truthy (включая new Boolean(false)!)
Три операции: ToPrimitive, ToNumber, ToString, ToBoolean`;
