document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>deepWatch(obj, callback)</code> — глубокое наблюдение за объектом через WeakMap и Proxy.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function deepWatch(obj, callback) {
  const proxyMap = new WeakMap();

  function wrap(target, path) {
    if (proxyMap.has(target)) return proxyMap.get(target);
    const proxy = new Proxy(target, {
      get(t, prop, receiver) {
        const val = Reflect.get(t, prop, receiver);
        if (val && typeof val === 'object') {
          return wrap(val, \`\${path}.\${String(prop)}\`);
        }
        return val;
      },
      set(t, prop, value, receiver) {
        const old = t[prop];
        Reflect.set(t, prop, value, receiver);
        if (old !== value) {
          callback(\`\${path}.\${String(prop)}\`, value, old);
        }
        return true;
      }
    });
    proxyMap.set(target, proxy);
    return proxy;
  }
  return wrap(obj, 'root');
}

const state = deepWatch({ a: { b: { c: 1 } } }, (path, n, o) =>
  console.log(\`\${path}: \${o} => \${n}\`)
);

state.a.b.c = 42;  // 'root.a.b.c: 1 => 42'
state.a.b.c = 42;  // тишина (значение не изменилось)`;

document.getElementById('output').textContent = `state.a.b.c = 42 => 'root.a.b.c: 1 => 42'
state.a.b.c = 42 => тишина (значение не изменилось)
WeakMap кеширует прокси чтобы не создавать дубликаты
Callback получает: путь, новое значение, старое значение`;
