document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>createImmutableRecord(obj)</code> — Record-тип: только чтение, но с методом <code>with()</code> для создания новой версии.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function createImmutableRecord(obj) {
  const frozen = Object.freeze({ ...obj });

  return new Proxy(frozen, {
    get(target, prop, receiver) {
      if (prop === 'with') {
        return (updates) => createImmutableRecord({ ...target, ...updates });
      }
      if (prop === 'toObject') {
        return () => ({ ...target });
      }
      return Reflect.get(target, prop, receiver);
    },
    set() {
      throw new TypeError('Record иммутабелен. Используй .with(updates)');
    }
  });
}

const record = createImmutableRecord({ name: 'Аня', age: 25, city: 'Москва' });

console.log(record.name); // 'Аня'
const updated = record.with({ age: 26, city: 'Питер' });
console.log(updated.name); // 'Аня'
console.log(updated.age);  // 26
console.log(record.age);   // 25 (не изменился!)

try { record.name = 'Боря'; } catch(e) { console.log(e.message); }`;

document.getElementById('output').textContent = `record.name => 'Аня'
record.with({age:26, city:'Питер'}) => новый Record
updated.age  => 26
record.age   => 25 (не изменился!)
record.name = 'Боря' => TypeError: Record иммутабелен`;
