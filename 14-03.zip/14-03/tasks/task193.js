document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>createDependencyContainer()</code> — простой IoC-контейнер для инъекции зависимостей.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function createContainer() {
  const registry = new Map();
  const singletons = new Map();

  return {
    register(name, factory, { singleton = false } = {}) {
      registry.set(name, { factory, singleton });
      return this;
    },

    resolve(name) {
      const entry = registry.get(name);
      if (!entry) throw new Error(\`Зависимость '\${name}' не зарегистрирована\`);

      if (entry.singleton) {
        if (!singletons.has(name)) singletons.set(name, entry.factory(this));
        return singletons.get(name);
      }
      return entry.factory(this);
    }
  };
}

const container = createContainer();

container
  .register('config', () => ({ host: 'localhost', port: 5432 }), { singleton: true })
  .register('logger', () => ({ log: (m) => console.log('[LOG]', m) }))
  .register('db', (c) => ({ config: c.resolve('config'), query: (q) => q }));

const db1 = container.resolve('db');
const db2 = container.resolve('db');
console.log(db1 === db2); // false (не singleton)

const cfg1 = container.resolve('config');
const cfg2 = container.resolve('config');
console.log(cfg1 === cfg2); // true (singleton!)`;

document.getElementById('output').textContent = `db1 === db2   => false (db — не singleton, новые каждый раз)
cfg1 === cfg2 => true  (config — singleton, один экземпляр)
container.resolve('db').config === container.resolve('config') => true
IoC: зависимости передаются снаружи, а не создаются внутри`;
