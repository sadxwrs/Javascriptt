document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>[[Prototype]]</code> и как он связан с <code>__proto__</code> и <code>Object.getPrototypeOf()</code>?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// [[Prototype]] — внутренний слот объекта (не прямо доступен)
// __proto__ — устаревший аксессор к [[Prototype]]
// Object.getPrototypeOf() — официальный способ читать [[Prototype]]
// Object.setPrototypeOf() — официальный способ менять [[Prototype]]

function Dog(name) { this.name = name; }
Dog.prototype.bark = function() { return \`\${this.name}: Гав!\`; };

const dog = new Dog('Рекс');

// Три способа прочитать прототип:
console.log(dog.__proto__ === Dog.prototype);               // true
console.log(Object.getPrototypeOf(dog) === Dog.prototype);  // true
console.log(dog.__proto__ === Object.getPrototypeOf(dog));  // true

// [[Prototype]] — это именно то, где JS ищет методы:
dog.bark(); // найдено в Dog.prototype => 'Рекс: Гав!'

// Цепочка:
// dog => Dog.prototype => Object.prototype => null
console.log(Object.getPrototypeOf(Dog.prototype) === Object.prototype); // true
console.log(Object.getPrototypeOf(Object.prototype)); // null`;

document.getElementById('output').textContent = `dog.__proto__ === Dog.prototype => true
Object.getPrototypeOf(dog) === Dog.prototype => true
dog.bark() => 'Рекс: Гав!' (найдено в Dog.prototype)
Цепочка: dog => Dog.prototype => Object.prototype => null
__proto__ — устаревший, предпочтительнее Object.getPrototypeOf()`;
