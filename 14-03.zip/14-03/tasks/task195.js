document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>createProtectedObject(obj, allowedKeys)</code> — объект разрешающий доступ только к белому списку ключей.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function createProtectedObject(obj, allowedKeys) {
  const allowed = new Set(allowedKeys);

  return new Proxy(obj, {
    get(target, prop, receiver) {
      if (typeof prop === 'symbol') return Reflect.get(target, prop, receiver);
      if (!allowed.has(prop)) {
        throw new Error(\`Доступ к '\${prop}' запрещён\`);
      }
      return Reflect.get(target, prop, receiver);
    },
    set(target, prop, value, receiver) {
      if (!allowed.has(prop)) {
        throw new Error(\`Запись '\${prop}' запрещена\`);
      }
      return Reflect.set(target, prop, value, receiver);
    },
    has(target, prop) {
      return allowed.has(prop) && Reflect.has(target, prop);
    }
  });
}

const user = createProtectedObject(
  { name: 'Аня', age: 25, password: 'secret' },
  ['name', 'age']
);

console.log(user.name);  // 'Аня'
console.log(user.age);   // 25
try { console.log(user.password); } catch(e) { console.log(e.message); }
// 'Доступ к password запрещён'`;

document.getElementById('output').textContent = `user.name => 'Аня' (разрешено)
user.age  => 25 (разрешено)
user.password => Error: 'Доступ к password запрещён'
user.secret = 'x' => Error: 'Запись secret запрещена'
'name' in user => true, 'password' in user => false`;
