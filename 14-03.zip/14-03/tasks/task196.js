document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>lazy(fn)</code> — ленивое вычисление значения, которое вычисляется один раз при первом обращении.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function lazy(fn) {
  let computed = false;
  let cachedValue;

  return new Proxy({}, {
    get(target, prop) {
      if (prop === 'value') {
        if (!computed) {
          console.log('Вычисляю...');
          cachedValue = fn();
          computed = true;
        }
        return cachedValue;
      }
      if (prop === 'reset') {
        return () => { computed = false; cachedValue = undefined; };
      }
    }
  });
}

const expensive = lazy(() => {
  // Имитация дорогой операции
  let sum = 0;
  for (let i = 0; i < 1000000; i++) sum += i;
  return sum;
});

console.log('До обращения — не вычислено');
console.log(expensive.value); // 'Вычисляю...' => 499999500000
console.log(expensive.value); // просто => 499999500000 (кеш!)
console.log(expensive.value); // просто => 499999500000 (кеш!)`;

document.getElementById('output').textContent = `До обращения — ничего не вычислено
expensive.value (1й раз) => 'Вычисляю...' => 499999500000
expensive.value (2й раз) => 499999500000 (из кеша, без 'Вычисляю!')
expensive.value (3й раз) => 499999500000 (кеш)
Proxy.get перехватывает обращение к .value`;
