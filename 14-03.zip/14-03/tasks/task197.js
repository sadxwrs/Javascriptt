document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>createVersionedObject(obj)</code> — объект хранящий историю всех версий свойств.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function createVersionedObject(obj) {
  const history = {}; // { prop: [v1, v2, v3, ...] }

  const proxy = new Proxy({ ...obj }, {
    set(target, prop, value, receiver) {
      if (!history[prop]) history[prop] = [target[prop]];
      Reflect.set(target, prop, value, receiver);
      history[prop].push(value);
      return true;
    }
  });

  proxy.getHistory = (prop) => [...(history[prop] || [])];
  proxy.rollback   = (prop, steps = 1) => {
    const h = history[prop];
    if (!h || h.length <= steps) return;
    h.splice(h.length - steps);
    proxy[prop] = h[h.length - 1];
  };

  return proxy;
}

const doc = createVersionedObject({ title: 'Черновик', status: 'draft' });
doc.title = 'Введение';
doc.title = 'Введение в JS';
doc.title = 'Глава 1';

console.log(doc.title);           // 'Глава 1'
console.log(doc.getHistory('title')); // ['Черновик','Введение','Введение в JS','Глава 1']
doc.rollback('title', 2);
console.log(doc.title);           // 'Введение'`;

document.getElementById('output').textContent = `doc.title => 'Глава 1'
doc.getHistory('title') => ['Черновик','Введение','Введение в JS','Глава 1']
doc.rollback('title', 2) — откатиться на 2 версии назад
doc.title => 'Введение'
историю версий хранит в замыкании`;
