document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое <code>Object.fromEntries(Object.entries(obj))</code>? Напиши 5 практических паттернов трансформации объектов.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `const products = { apple: 100, banana: 50, cherry: 200, grape: 80 };

// 1. Умножить все значения:
const doubled = Object.fromEntries(Object.entries(products).map(([k,v])=>[k,v*2]));
console.log(doubled); // { apple:200, banana:100, cherry:400, grape:160 }

// 2. Фильтрация по значению:
const expensive = Object.fromEntries(Object.entries(products).filter(([,v])=>v>80));
console.log(expensive); // { apple:100, cherry:200 }

// 3. Переименование ключей:
const renamed = Object.fromEntries(Object.entries(products).map(([k,v])=>[k.toUpperCase(),v]));
console.log(renamed); // { APPLE:100, BANANA:50, CHERRY:200, GRAPE:80 }

// 4. Инверсия:
const inv = Object.fromEntries(Object.entries(products).map(([k,v])=>[v,k]));
console.log(inv); // { 100:'apple', 50:'banana', 200:'cherry', 80:'grape' }

// 5. Накопление статистики:
const stats = Object.fromEntries(Object.entries(products).map(([k,v])=>[k,{price:v,tag:v>100?'дорого':'доступно'}]));
console.log(stats.cherry); // { price:200, tag:'дорого' }`;

document.getElementById('output').textContent = `1. Умножить: { apple:200, banana:100, cherry:400, grape:160 }
2. Фильтр >80: { apple:100, cherry:200 }
3. UPPER ключи: { APPLE:100, BANANA:50, ... }
4. Инверсия: { 100:'apple', 50:'banana', ... }
5. Статистика: cherry => { price:200, tag:'дорого' }`;
