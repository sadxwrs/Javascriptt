document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>createAuditLog(obj)</code> — объект автоматически фиксирующий все изменения с временными метками.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function createAuditLog(obj) {
  const log = [];

  const proxy = new Proxy({ ...obj }, {
    set(target, prop, value, receiver) {
      const old = target[prop];
      if (old !== value) {
        log.push({
          prop,
          from:      old,
          to:        value,
          timestamp: new Date().toISOString(),
          type:      old === undefined ? 'CREATE' : 'UPDATE'
        });
      }
      return Reflect.set(target, prop, value, receiver);
    },
    deleteProperty(target, prop) {
      if (prop in target) {
        log.push({ prop, from: target[prop], to: undefined, timestamp: new Date().toISOString(), type: 'DELETE' });
      }
      return Reflect.deleteProperty(target, prop);
    }
  });

  proxy.getLog   = () => [...log];
  proxy.clearLog = () => { log.length = 0; };

  return proxy;
}

const user = createAuditLog({ name: 'Аня', age: 25 });
user.age  = 26;
user.city = 'Москва';
delete user.age;

console.log(user.getLog().map(e => \`\${e.type} \${e.prop}: \${e.from}=>\${e.to}\`));
// ['UPDATE age: 25=>26', 'CREATE city: undefined=>Москва', 'DELETE age: 26=>undefined']`;

document.getElementById('output').textContent = `user.age = 26      => log: UPDATE age: 25=>26
user.city='Москва' => log: CREATE city: undefined=>Москва
delete user.age    => log: DELETE age: 26=>undefined
getLog() => все изменения с типом и timestamp
Proxy перехватывает set и deleteProperty`;
