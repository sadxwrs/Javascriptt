document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как получить доступ к свойству объекта через точку и через квадратные скобки? В чём разница?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const user = { name: 'Борис', 'favorite color': 'синий' };

// Через точку (только для валидных идентификаторов):
console.log(user.name);    // 'Борис'

// Через квадратные скобки (любые ключи + динамические):
console.log(user['name']); // 'Борис'
console.log(user['favorite color']); // 'синий'

// Динамический ключ:
const key = 'name';
console.log(user[key]);    // 'Борис'`;

document.getElementById('output').textContent = `user.name            => 'Борис'
user['name']         => 'Борис'
user['favorite color']=> 'синий'
user[key] (key='name')=> 'Борис'
Разница: [] поддерживает динамические и нестандартные ключи`;
