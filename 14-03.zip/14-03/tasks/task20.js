document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию pick(obj, keys) возвращающую новый объект только с указанными ключами.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function pick(obj, keys) {
  return Object.fromEntries(
    keys
      .filter(key => key in obj)
      .map(key => [key, obj[key]])
  );
}

const user = { id: 1, name: 'Рома', email: 'r@mail.ru', password: 'secret', age: 25 };

console.log(pick(user, ['id', 'name', 'email']));
// { id:1, name:'Рома', email:'r@mail.ru' }

console.log(pick(user, ['name', 'age']));
// { name:'Рома', age:25 }

console.log(pick(user, ['name', 'missing']));
// { name:'Рома' } — несуществующие ключи игнорируются`;

document.getElementById('output').textContent = `pick(user, ['id','name','email']) => { id:1, name:'Рома', email:'r@mail.ru' }
pick(user, ['name','age'])        => { name:'Рома', age:25 }
pick(user, ['name','missing'])    => { name:'Рома' } (missing игнорируется)`;
