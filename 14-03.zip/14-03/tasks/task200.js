document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй <code>createReactiveSystem()</code> — мини-систему реактивности аналог Vue 2: данные, вычисляемые свойства и watch.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function createReactiveSystem() {
  const watchers = {};
  const computed = {};

  function reactive(data) {
    return new Proxy(data, {
      set(t, prop, value, r) {
        Reflect.set(t, prop, value, r);
        (watchers[prop] || []).forEach(fn => fn(value));
        // Пересчитать зависимые computed:
        Object.keys(computed).forEach(key => {
          if (computed[key].deps.includes(prop)) {
            computed[key].value = computed[key].fn(proxy);
          }
        });
        return true;
      }
    });
  }

  const proxy = reactive({ count: 0, name: 'Аня' });

  return {
    data: proxy,
    watch(prop, fn) { if (!watchers[prop]) watchers[prop]=[]; watchers[prop].push(fn); },
    computed(key, deps, fn) { computed[key] = { deps, fn, value: fn(proxy) }; },
    getComputed(key) { return computed[key]?.value; }
  };
}

const sys = createReactiveSystem();
sys.watch('count', v => console.log('count изменился:', v));
sys.computed('doubled', ['count'], d => d.count * 2);

sys.data.count = 5;  // 'count изменился: 5'
console.log(sys.getComputed('doubled')); // 10
sys.data.count = 10; // 'count изменился: 10'
console.log(sys.getComputed('doubled')); // 20`;

document.getElementById('output').textContent = `sys.data.count = 5  => 'count изменился: 5'
sys.getComputed('doubled') => 10
sys.data.count = 10 => 'count изменился: 10'
sys.getComputed('doubled') => 20
Мини-Vue: reactive данные + watch + computed через Proxy`;
