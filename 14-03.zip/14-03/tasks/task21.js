document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию omit(obj, keys) возвращающую объект без указанных ключей.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function omit(obj, keys) {
  const excluded = new Set(keys);
  return Object.fromEntries(
    Object.entries(obj).filter(([k]) => !excluded.has(k))
  );
}

const user = { id: 1, name: 'Света', password: 'secret', token: 'abc123', age: 28 };

console.log(omit(user, ['password', 'token']));
// { id:1, name:'Света', age:28 }

console.log(omit(user, ['id']));
// { name:'Света', password:'secret', token:'abc123', age:28 }`;

document.getElementById('output').textContent = `omit(user, ['password','token']) => { id:1, name:'Света', age:28 }
omit(user, ['id'])               => { name:'Света', password:'secret', token:'abc123', age:28 }
omit — противоположность pick`;
