document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое Object.defineProperty()? Как создать свойство только для чтения?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const user = { name: 'Таня' };

Object.defineProperty(user, 'id', {
  value: 42,
  writable: false,     // только для чтения
  enumerable: true,    // видно в for...in
  configurable: false  // нельзя переопределить
});

console.log(user.id); // 42

user.id = 100; // молча игнорируется (в strict — ошибка)
console.log(user.id); // 42

const desc = Object.getOwnPropertyDescriptor(user, 'id');
console.log(desc);
// { value:42, writable:false, enumerable:true, configurable:false }`;

document.getElementById('output').textContent = `user.id => 42 (только для чтения)
user.id = 100 => игнорируется
Dескриптор: { value:42, writable:false, enumerable:true, configurable:false }`;
