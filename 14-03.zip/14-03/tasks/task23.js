document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое дескрипторы свойств (writable, enumerable, configurable)? Как их посмотреть?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `const obj = { x: 10 };

// Посмотреть дескриптор:
console.log(Object.getOwnPropertyDescriptor(obj, 'x'));
// { value:10, writable:true, enumerable:true, configurable:true }

// writable: можно ли изменять значение
// enumerable: видно ли в for...in / Object.keys
// configurable: можно ли переопределить/удалить дескриптор

// Все дескрипторы объекта:
console.log(Object.getOwnPropertyDescriptors(obj));

// Создать не перечисляемое свойство:
Object.defineProperty(obj, 'hidden', {
  value: 'секрет',
  enumerable: false
});
console.log(Object.keys(obj));  // ['x'] — hidden не видно!
console.log(obj.hidden);         // 'секрет'`;

document.getElementById('output').textContent = `Дескриптор: { value, writable, enumerable, configurable }
writable:     можно ли изменять значение
enumerable:   видно ли в for...in/Object.keys
configurable: можно ли удалить/переопределить
Object.keys(obj) => ['x'] (hidden с enumerable:false не виден)`;
