document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй функцию deepFreeze(obj) рекурсивно замораживающую все вложенные объекты.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function deepFreeze(obj) {
  if (obj === null || typeof obj !== 'object') return obj;
  Object.freeze(obj);
  Object.keys(obj).forEach(key => deepFreeze(obj[key]));
  return obj;
}

const config = deepFreeze({
  db: { host: 'localhost', port: 5432 },
  app: { name: 'MyApp', version: '1.0' }
});

config.db.host = 'newhost';
console.log(config.db.host); // 'localhost' — не изменился!

config.db.newProp = 'x';
console.log(config.db.newProp); // undefined

console.log(Object.isFrozen(config));    // true
console.log(Object.isFrozen(config.db)); // true`;

document.getElementById('output').textContent = `config.db.host = 'newhost' => игнорируется
config.db.host => 'localhost' (глубоко заморожен!)
Object.isFrozen(config)    => true
Object.isFrozen(config.db) => true
Обычный freeze замораживает только первый уровень`;
