document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое геттеры и сеттеры (get/set) в объектах? Напиши объект с вычисляемым свойством через геттер.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `const user = {
  firstName: 'Иван',
  lastName:  'Петров',
  birthYear: 2000,

  get fullName() {
    return \`\${this.firstName} \${this.lastName}\`;
  },
  set fullName(value) {
    [this.firstName, this.lastName] = value.split(' ');
  },
  get age() {
    return new Date().getFullYear() - this.birthYear;
  }
};

console.log(user.fullName);      // 'Иван Петров'
user.fullName = 'Сергей Смирнов';
console.log(user.firstName);     // 'Сергей'
console.log(user.lastName);      // 'Смирнов'
console.log(user.age);           // ~25`;

document.getElementById('output').textContent = `user.fullName => 'Иван Петров' (геттер вычисляет на лету)
user.fullName = 'Сергей Смирнов' => сеттер разбивает строку
user.firstName => 'Сергей'
user.age => текущий год - 2000`;
