document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Почему при присваивании объекта переменной копируется ссылка, а не сам объект?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Объекты хранятся в куче (heap), переменные хранят ССЫЛКИ
const a = { x: 1 };
const b = a; // b указывает на тот же объект!

b.x = 99;
console.log(a.x); // 99 — изменился!
console.log(a === b); // true — одна и та же ссылка

// Примитивы копируются по значению:
let n1 = 5;
let n2 = n1; // копия значения
n2 = 100;
console.log(n1); // 5 — не изменился`;

document.getElementById('output').textContent = `b = a => b указывает на тот же объект
b.x = 99 => a.x тоже = 99
a === b => true (одна ссылка)
Примитивы: n2 = n1; n2=100 => n1=5 (копия значения)`;
