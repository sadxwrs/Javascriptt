document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что произойдёт если изменить свойство объекта через вторую переменную ссылающуюся на тот же объект?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const original = { name: 'Юля', scores: [85, 92, 78] };
const alias = original; // та же ссылка!

alias.name = 'Света';
console.log(original.name); // 'Света' — изменилось!

alias.scores.push(100);
console.log(original.scores); // [85,92,78,100] — изменилось!

// Проверяем:
console.log(original === alias); // true`;

document.getElementById('output').textContent = `alias.name = 'Света' => original.name = 'Света'
alias.scores.push(100) => original.scores = [85,92,78,100]
original === alias => true (одна и та же ссылка!)`;
