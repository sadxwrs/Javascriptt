document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как сделать поверхностную копию объекта через Object.assign()?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const original = { name: 'Женя', age: 30, address: { city: 'Минск' } };

const copy = Object.assign({}, original);

copy.name = 'Костя';
console.log(original.name); // 'Женя' — не изменился

// Но вложенный объект — всё ещё ссылка!
copy.address.city = 'Киев';
console.log(original.address.city); // 'Киев' — изменился!

// Object.assign можно объединять несколько источников:
const merged = Object.assign({}, { a: 1 }, { b: 2 }, { c: 3 });
console.log(merged); // { a:1, b:2, c:3 }`;

document.getElementById('output').textContent = `Object.assign({}, obj) — поверхностная копия
copy.name = 'Костя' => original.name = 'Женя' (не изменился)
copy.address.city = 'Киев' => original.address.city тоже 'Киев' (вложенный — ссылка!)
Object.assign({}, {a:1}, {b:2}) => { a:1, b:2 }`;
