document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как сделать поверхностную копию объекта через spread-оператор {...obj}?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const original = { x: 1, y: 2, nested: { z: 3 } };

const copy = { ...original };

copy.x = 99;
console.log(original.x); // 1 — не изменился

// Вложенный объект — всё ещё та же ссылка:
copy.nested.z = 999;
console.log(original.nested.z); // 999 — изменился!

// Spread удобно для добавления/замены полей:
const updated = { ...original, x: 100, newField: 'test' };
console.log(updated); // { x:100, y:2, nested:{z:999}, newField:'test' }`;

document.getElementById('output').textContent = `{ ...original } — поверхностная копия
copy.x = 99 => original.x = 1 (не изменился)
copy.nested.z = 999 => original.nested.z = 999 (вложенный — ссылка!)
{ ...original, x:100 } => заменяет x на 100`;
