document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Добавь новое свойство email в уже существующий объект.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const user = { name: 'Вера', age: 28 };

// Через точку:
user.email = 'vera@mail.ru';
console.log(user.email); // 'vera@mail.ru'

// Через квадратные скобки:
user['phone'] = '+7-999-000';
console.log(user.phone); // '+7-999-000'

console.log(user);
// { name:'Вера', age:28, email:'vera@mail.ru', phone:'+7-999-000' }`;

document.getElementById('output').textContent = `user.email = 'vera@mail.ru'  => добавлено
user['phone'] = '+7-999-000' => добавлено
user => { name:'Вера', age:28, email:'vera@mail.ru', phone:'+7-999-000' }`;
