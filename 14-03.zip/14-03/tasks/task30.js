document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Чем поверхностное копирование отличается от глубокого? Покажи на примере вложенного объекта.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const obj = { a: 1, b: { c: 2, d: { e: 3 } } };

// Поверхностная копия (первый уровень независим, вложенное — нет):
const shallow = { ...obj };
shallow.a = 99;
shallow.b.c = 99;
console.log(obj.a);   // 1   — независим
console.log(obj.b.c); // 99  — изменился!

// Глубокая копия (все уровни независимы):
const deep = JSON.parse(JSON.stringify(obj));
deep.b.c = 1000;
console.log(obj.b.c); // 99 — не изменился!`;

document.getElementById('output').textContent = `Поверхностная: первый уровень независим, вложенные объекты — общие ссылки
shallow.a = 99 => obj.a = 1 (независим)
shallow.b.c = 99 => obj.b.c = 99 (изменился!)
Глубокая: все уровни независимы
deep.b.c = 1000 => obj.b.c = 99 (не изменился)`;
