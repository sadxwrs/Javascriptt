document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как сравнить два объекта на равенство? Почему obj1 === obj2 не всегда работает как ожидается?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const a = { x: 1, y: 2 };
const b = { x: 1, y: 2 };
const c = a;

console.log(a === b); // false (разные объекты в памяти!)
console.log(a === c); // true  (одна и та же ссылка)

// Сравнение по содержимому (поверхностное):
console.log(JSON.stringify(a) === JSON.stringify(b)); // true

// Или своя функция:
function shallowEq(x, y) {
  const ka = Object.keys(x), kb = Object.keys(y);
  if (ka.length !== kb.length) return false;
  return ka.every(k => x[k] === y[k]);
}
console.log(shallowEq(a, b)); // true`;

document.getElementById('output').textContent = `a === b => false (разные объекты в памяти!)
a === c => true  (одна ссылка)
JSON.stringify(a) === JSON.stringify(b) => true
shallowEq(a, b) => true`;
