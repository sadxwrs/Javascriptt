document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию shallowEqual(a, b) сравнивающую объекты по значениям первого уровня.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function shallowEqual(a, b) {
  if (a === b) return true;
  if (typeof a !== 'object' || typeof b !== 'object') return false;
  if (a === null || b === null) return false;

  const keysA = Object.keys(a);
  const keysB = Object.keys(b);

  if (keysA.length !== keysB.length) return false;

  return keysA.every(key => Object.hasOwn(b, key) && a[key] === b[key]);
}

console.log(shallowEqual({ a:1, b:2 }, { a:1, b:2 })); // true
console.log(shallowEqual({ a:1 }, { a:1, b:2 }));       // false
console.log(shallowEqual({ a:{} }, { a:{} }));           // false (разные ссылки!)`;

document.getElementById('output').textContent = `shallowEqual({a:1,b:2}, {a:1,b:2}) => true
shallowEqual({a:1}, {a:1,b:2})     => false (разное кол-во ключей)
shallowEqual({a:{}}, {a:{}})        => false (вложенные объекты — разные ссылки)
Первый уровень — точное сравнение через ===`;
