document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как сделать глубокую копию объекта через JSON.parse(JSON.stringify(obj))? Каковы ограничения?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const original = {
  name: 'Тест',
  nested: { a: 1, b: [1, 2, 3] }
};

const deep = JSON.parse(JSON.stringify(original));
deep.nested.a = 999;
console.log(original.nested.a); // 1 — не изменился!

// ОГРАНИЧЕНИЯ:
const withFn = {
  fn: () => 'hello',      // функции
  u: undefined,           // undefined
  d: new Date(),          // Date -> строка!
  r: /regex/,             // RegExp -> {}
  s: Symbol('id'),        // Symbol -> пропадёт
};
const copy = JSON.parse(JSON.stringify(withFn));
console.log(copy.fn);  // undefined (функция исчезла!)
console.log(copy.d);   // строка, не Date!
console.log(copy.r);   // {} (RegExp стал пустым объектом!)`;

document.getElementById('output').textContent = `Работает: JSON.parse(JSON.stringify(obj)) => глубокая копия
original.nested.a = 1 (не изменился)
ОГРАНИЧЕНИЯ: функции исчезают, undefined исчезает, Date -> строка, RegExp -> {}, Symbol исчезает, не работает с циклическими ссылками`;
