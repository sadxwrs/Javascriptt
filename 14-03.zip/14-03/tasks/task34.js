document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как сделать глубокую копию объекта через structuredClone()? Чем он лучше JSON-метода?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const original = {
  name: 'Данные',
  nested: { arr: [1, 2, 3] },
  date: new Date(2026, 2, 18),
  map: new Map([['a', 1]]),
  set: new Set([1, 2, 3]),
};

const clone = structuredClone(original);
clone.nested.arr.push(99);
console.log(original.nested.arr); // [1,2,3] — не изменился!

// Date сохраняется как Date!
console.log(clone.date instanceof Date); // true
console.log(clone.map instanceof Map);   // true
console.log(clone.set instanceof Set);   // true

// Циклические ссылки тоже обрабатывает!
const cyclic = { a: 1 };
cyclic.self = cyclic;
const c = structuredClone(cyclic); // не ошибка!`;

document.getElementById('output').textContent = `structuredClone() — нативная глубокая копия
original.nested.arr => [1,2,3] (не изменился)
Date сохраняется как Date (в отличие от JSON!)
Map и Set тоже поддерживаются
Обрабатывает циклические ссылки без ошибок`;
