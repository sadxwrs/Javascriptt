document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши рекурсивную функцию deepClone(obj) для глубокого копирования без использования JSON.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function deepClone(obj) {
  if (obj === null || typeof obj !== 'object') return obj;
  if (obj instanceof Date)   return new Date(obj);
  if (obj instanceof RegExp) return new RegExp(obj);
  if (Array.isArray(obj)) {
    return obj.map(item => deepClone(item));
  }
  const clone = {};
  for (const key in obj) {
    if (Object.hasOwn(obj, key)) {
      clone[key] = deepClone(obj[key]);
    }
  }
  return clone;
}

const obj = { a: 1, b: { c: [1, 2, { d: 3 }] }, date: new Date(2026, 0, 1) };
const clone = deepClone(obj);
clone.b.c[2].d = 999;
console.log(obj.b.c[2].d); // 3 — не изменился!
console.log(clone.date instanceof Date); // true`;

document.getElementById('output').textContent = `deepClone рекурсивно обходит все уровни
clone.b.c[2].d = 999 => obj.b.c[2].d = 3 (не изменился!)
Date клонируется как Date
Обработаны: null, примитивы, Date, RegExp, Array, Object`;
