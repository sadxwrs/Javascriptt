document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое циклическая ссылка в объекте? Как structuredClone с ней справляется?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Циклическая ссылка: объект ссылается на себя
const a = { name: 'A' };
const b = { name: 'B', ref: a };
a.ref = b; // a -> b -> a -> b... (цикл!)

// JSON.stringify — выбросит ошибку:
try {
  JSON.stringify(a);
} catch(e) {
  console.log(e.message); // Converting circular structure to JSON
}

// structuredClone — обрабатывает корректно:
const clone = structuredClone(a);
console.log(clone.name);           // 'A'
console.log(clone.ref.name);       // 'B'
console.log(clone.ref.ref === clone); // true (цикл сохранён!)`;

document.getElementById('output').textContent = `Циклическая ссылка: a.ref = b; b.ref = a (бесконечный цикл)
JSON.stringify => TypeError: Converting circular structure to JSON
structuredClone => справляется корректно!
clone.ref.ref === clone => true (структура цикла сохранена)`;
