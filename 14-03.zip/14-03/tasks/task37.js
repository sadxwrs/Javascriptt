document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй deepEqual(a, b) рекурсивно сравнивающий объекты любой вложенности включая массивы.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function deepEqual(a, b) {
  if (a === b) return true;
  if (a === null || b === null) return false;
  if (typeof a !== 'object' || typeof b !== 'object') return false;
  if (Array.isArray(a) !== Array.isArray(b)) return false;

  const keysA = Object.keys(a);
  const keysB = Object.keys(b);
  if (keysA.length !== keysB.length) return false;

  return keysA.every(key =>
    Object.hasOwn(b, key) && deepEqual(a[key], b[key])
  );
}

console.log(deepEqual({a:1,b:{c:2}}, {a:1,b:{c:2}}));  // true
console.log(deepEqual([1,[2,3]], [1,[2,3]]));             // true
console.log(deepEqual({a:1,b:{c:2}}, {a:1,b:{c:9}}));  // false
console.log(deepEqual({a:1}, {a:1,b:2}));               // false`;

document.getElementById('output').textContent = `deepEqual({a:1,b:{c:2}}, {a:1,b:{c:2}}) => true
deepEqual([1,[2,3]], [1,[2,3]])           => true
deepEqual({a:1,b:{c:2}}, {a:1,b:{c:9}})  => false
deepEqual({a:1}, {a:1,b:2})              => false`;
