document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй deepMerge(target, source) глубоко объединяющий два объекта без мутации.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function deepMerge(target, source) {
  const result = { ...target };
  for (const key of Object.keys(source)) {
    if (
      source[key] !== null &&
      typeof source[key] === 'object' &&
      !Array.isArray(source[key]) &&
      typeof result[key] === 'object' &&
      result[key] !== null
    ) {
      result[key] = deepMerge(result[key], source[key]);
    } else {
      result[key] = source[key];
    }
  }
  return result;
}

const a = { x: 1, nested: { a: 1, b: 2 } };
const b = { y: 2, nested: { b: 99, c: 3 } };
console.log(deepMerge(a, b));
// { x:1, y:2, nested:{ a:1, b:99, c:3 } }
console.log(a.nested.b); // 2 — исходник не изменился!`;

document.getElementById('output').textContent = `deepMerge(a, b) => { x:1, y:2, nested:{ a:1, b:99, c:3 } }
a.nested.b => 2 (исходник не изменился!)
Глубокие объекты мержатся рекурсивно, массивы перезаписываются`;
