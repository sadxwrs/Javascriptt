document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что происходит при копировании объекта содержащего функции, Symbol-ключи или прототипные свойства?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `const sym = Symbol('key');
const original = {
  name: 'Тест',
  fn: () => 'hello',
  [sym]: 'symbol-value'
};
Object.setPrototypeOf(original, { inherited: true });

// spread / Object.assign:
const copy = { ...original };
console.log(copy.name);       // 'Тест'
console.log(copy.fn());       // 'hello'  (функция копируется!)
console.log(copy[sym]);       // undefined (Symbol-ключи НЕ копируются!)
console.log(copy.inherited);  // undefined (прототипные НЕ копируются!)

// Symbol-ключи через assign тоже не копируются!
// Для копирования Symbol-ключей:
const withSym = Object.assign({}, original,
  Object.fromEntries(Object.getOwnPropertySymbols(original)
    .map(s => [s, original[s]])));
console.log(withSym[sym]); // 'symbol-value'`;

document.getElementById('output').textContent = `{ ...obj }: функции копируются, Symbol-ключи НЕ копируются, прототипные НЕ копируются
Object.getOwnPropertySymbols() — получить Symbol-ключи
Для полного копирования нужны дополнительные шаги`;
