document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Удали свойство из объекта с помощью оператора delete.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const user = { name: 'Глеб', age: 30, password: 'secret' };

console.log(user.password); // 'secret'

delete user.password;

console.log(user.password); // undefined
console.log('password' in user); // false
console.log(user); // { name:'Глеб', age:30 }`;

document.getElementById('output').textContent = `До delete: user.password => 'secret'
После delete: user.password => undefined
'password' in user => false
user => { name:'Глеб', age:30 }`;
