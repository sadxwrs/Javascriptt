document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй immutableSet(obj, path, value) возвращающий новый объект с изменённым вложенным свойством по пути 'a.b.c'.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function immutableSet(obj, path, value) {
  const keys = path.split('.');
  if (keys.length === 1) {
    return { ...obj, [keys[0]]: value };
  }
  const [first, ...rest] = keys;
  return {
    ...obj,
    [first]: immutableSet(obj[first] ?? {}, rest.join('.'), value)
  };
}

const state = { user: { name: 'Ваня', address: { city: 'Москва' } } };

const next = immutableSet(state, 'user.address.city', 'Питер');
console.log(next.user.address.city);  // 'Питер'
console.log(state.user.address.city); // 'Москва' — не изменился!
console.log(state === next);          // false (новый объект)
console.log(state.user === next.user);// false (тоже новый)`;

document.getElementById('output').textContent = `immutableSet(state, 'user.address.city', 'Питер')
=> next.user.address.city = 'Питер'
=> state.user.address.city = 'Москва' (не изменился!)
=> state === next => false
Каждый уровень по пути — новый объект (иммутабельность)`;
