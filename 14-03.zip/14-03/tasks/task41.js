document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое сборка мусора (garbage collection) в JavaScript?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Сборка мусора (GC) — автоматическое освобождение памяти
// от объектов, которые больше не используются.

// Пример: создание и потеря ссылки
let obj = { data: 'большой массив данных' };
// obj сейчас достижим — в памяти

obj = null;
// Теперь на объект нет ссылок
// Сборщик мусора может освободить память

// JS использует алгоритм mark-and-sweep
// Разработчику не нужно освобождать память вручную
console.log('GC работает автоматически — не нужен delete/free');`;

document.getElementById('output').textContent = `GC — автоматическое управление памятью в JS
Объект удаляется, когда на него нет доступных ссылок
Алгоритм: mark-and-sweep (метка и сборка)
Разработчик не вызывает GC вручную — он сам знает когда`;
