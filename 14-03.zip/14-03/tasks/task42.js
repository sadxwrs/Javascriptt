document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое 'достижимость' объекта? Как JS определяет можно ли удалить объект из памяти?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Достижимый объект — до него можно добраться из 'корней'
// Корни: глобальные переменные, стек вызовов, встроенные объекты

let user = { name: 'Аня' }; // достижим через user
let admin = user;            // достижим через admin тоже

user = null; // убрали одну ссылку — но объект ещё достижим через admin!
// GC НЕ удалит объект

admin = null; // последняя ссылка удалена — объект НЕ достижим
// Теперь GC МОЖЕТ удалить объект

console.log('Объект удаляется только когда нет ни одной ссылки');`;

document.getElementById('output').textContent = `Достижимость: объект достижим, если до него есть путь из корней
Корни: глобальные переменные, стек вызовов
user=null, admin=user => объект ещё живёт (через admin)
user=null, admin=null => объект недостижим => GC удалит`;
