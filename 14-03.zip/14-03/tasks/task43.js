document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое алгоритм 'mark-and-sweep'? Опиши его работу.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Mark-and-Sweep (пометить и подмести) — основной алгоритм GC

// Фаза 1: MARK (пометка)
// - Начинаем с корней (global, stack)
// - Помечаем все достижимые объекты
// - Рекурсивно обходим все ссылки

// Фаза 2: SWEEP (очистка)
// - Удаляем все НЕпомеченные объекты
// - Освобождаем их память

// Пример:
function example() {
  const a = { ref: null };
  const b = { name: 'B' };
  a.ref = b;
  // После выхода из функции:
  // a и b больше не достижимы из корней
  // GC пометит их как мусор и удалит
}
example();
console.log('Mark: помечаем достижимые, Sweep: удаляем остальные');`;

document.getElementById('output').textContent = `Mark-and-Sweep:
1. MARK: начать с корней, пометить все достижимые объекты (рекурсивно)
2. SWEEP: удалить все непомеченные объекты
После выхода из функции — локальные объекты теряют достижимость => GC удалит`;
