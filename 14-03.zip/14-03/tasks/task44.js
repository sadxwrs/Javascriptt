document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое корни (roots) в контексте сборки мусора? Приведи примеры.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// КОРНИ — объекты, которые всегда считаются достижимыми

// 1. Глобальные переменные:
const globalObj = { always: 'accessible' };

// 2. Текущий стек вызовов (локальные переменные функций):
function foo() {
  const local = { x: 1 }; // корень пока foo выполняется
  return local;
}

// 3. Вложенные функции (замыкания):
function makeCounter() {
  let count = 0; // удерживается замыканием — корень!
  return () => ++count;
}
const counter = makeCounter(); // count жив пока жив counter

// 4. Встроенные объекты: window, document и т.д.
console.log('Корни: глобальные, стек, замыкания, встроенные');`;

document.getElementById('output').textContent = `Корни (roots) — всегда достижимы, GC их не удаляет:
1. Глобальные переменные (window, глобальные const/let/var)
2. Стек вызовов (локальные переменные выполняемых функций)
3. Замыкания (переменные, захваченные функциями)
4. Встроенные объекты (document, navigator и т.д.)`;
