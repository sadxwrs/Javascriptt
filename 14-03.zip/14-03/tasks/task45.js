document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое утечка памяти в JS? Приведи пример когда объект не удаляется хотя больше не нужен.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Утечка памяти — когда объект больше не нужен,
// но остаётся достижимым => GC не удалит

// Пример 1: случайное глобальное состояние
function leaky() {
  leaked = { bigData: new Array(100000) }; // без let/const/var!
}
leaky();
// leaked теперь глобальная! Никогда не будет удалена.

// Пример 2: забытый обработчик событий
const btn = document.createElement('button');
const heavyObj = { data: new Array(10000) };
btn.addEventListener('click', () => console.log(heavyObj));
// heavyObj удерживается listener-ом, даже если btn удалён

// Пример 3: растущий кеш без ограничений
const cache = {};
function addToCache(key, value) {
  cache[key] = value; // кеш растёт бесконечно!
}`;

document.getElementById('output').textContent = `Утечка памяти: объект не нужен, но остаётся достижимым
Пример 1: глобальная переменная без объявления (leaked = ...)
Пример 2: EventListener удерживает замыкание с объектом
Пример 3: неограниченный кеш (объекты накапливаются)
Решения: removeEventListener, WeakMap для кешей, ограничение кеша`;
