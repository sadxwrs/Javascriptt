document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как замыкания могут привести к утечкам памяти? Напиши пример и объясни почему это происходит.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function createLeak() {
  const bigArray = new Array(1000000).fill('data');

  // Этот обработчик захватывает bigArray через замыкание
  document.body.addEventListener('click', function handler() {
    console.log(bigArray[0]); // bigArray живёт пока живёт handler!
  });

  // handler НЕ удаляется => bigArray НЕ освобождается!
}
createLeak(); // bigArray занимает память вечно

// Исправление: сохранить ссылку и удалить listener:
function createFixed() {
  const bigArray = new Array(1000000).fill('data');
  function handler() { console.log(bigArray[0]); }
  document.body.addEventListener('click', handler);
  return () => document.body.removeEventListener('click', handler);
  // Вызови returned функцию когда listener больше не нужен
}`;

document.getElementById('output').textContent = `Замыкание handler захватывает bigArray
Пока listener жив — bigArray не освобождается (утечка!)
Исправление: сохранить ссылку на handler => вызвать removeEventListener
Правило: всегда удаляй event listeners когда они больше не нужны`;
