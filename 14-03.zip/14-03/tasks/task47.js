document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое WeakRef? Когда он полезен в контексте управления памятью?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// WeakRef — слабая ссылка, не препятствующая GC

let obj = { name: 'Важный объект', data: new Array(10000) };
const ref = new WeakRef(obj); // слабая ссылка

console.log(ref.deref()?.name); // 'Важный объект'

// Если obj станет недостижим — GC может удалить его
obj = null;

// deref() вернёт undefined если объект уже удалён GC:
const value = ref.deref();
if (value) {
  console.log('Объект жив:', value.name);
} else {
  console.log('Объект удалён GC');
}

// Используется для: кешей, которые не мешают GC
const cache = new Map();
function getCached(key, createFn) {
  const ref = cache.get(key);
  const cached = ref?.deref();
  if (cached) return cached;
  const newVal = createFn();
  cache.set(key, new WeakRef(newVal));
  return newVal;
}`;

document.getElementById('output').textContent = `WeakRef — слабая ссылка, не мешает GC удалить объект
ref.deref() => объект или undefined (если уже удалён)
Используется для: кешей без утечек памяти
Отличие от WeakMap: WeakRef держит ссылку на конкретный объект`;
