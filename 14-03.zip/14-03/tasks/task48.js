document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое FinalizationRegistry? Как использовать его для отслеживания удаления объектов?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// FinalizationRegistry — вызывает callback когда объект удалён GC

const registry = new FinalizationRegistry((heldValue) => {
  console.log(\`Объект удалён GC. Метка: \${heldValue}\`);
});

function createTracked(name) {
  let obj = { data: name, big: new Array(10000) };
  registry.register(obj, name); // зарегистрировать с меткой
  return obj;
}

let user = createTracked('Пользователь-1');
console.log(user.data); // 'Пользователь-1'

user = null; // объект теряет ссылку
// Когда GC соберёт мусор:
// => 'Объект удалён GC. Метка: Пользователь-1'

// Используется для: очистки ресурсов (файлы, соединения)
// ВАЖНО: callback вызывается не сразу и не гарантированно!`;

document.getElementById('output').textContent = `FinalizationRegistry вызывает callback после удаления объекта GC
registry.register(obj, 'метка') — зарегистрировать
Callback получает 'метку' (не сам объект — уже удалён!)
Важно: вызов не гарантирован и не мгновенен
Используется для: очистки внешних ресурсов`;
