document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как глобальные переменные влияют на сборку мусора? Почему злоупотребление глобальным состоянием опасно для памяти?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Глобальные переменные — это КОРНИ.
// Всё, на что они ссылаются, НИКОГДА не удалит GC!

// Опасный паттерн 1: случайная глобальная переменная
function whoops() {
  accidentally = { huge: new Array(1000000) }; // без var/let/const!
  // accidentally стал глобальным => память никогда не освободится
}

// Опасный паттерн 2: накопление в глобальном массиве
const events = []; // глобальный
function logEvent(e) {
  events.push({ ...e, timestamp: Date.now() }); // растёт бесконечно!
}

// Безопасный паттерн: ограничение размера
const MAX = 100;
function logEventSafe(e) {
  events.push(e);
  if (events.length > MAX) events.shift(); // удаляем старые
}

console.log('Глобальные = корни = GC не удалит никогда');`;

document.getElementById('output').textContent = `Глобальные переменные — корни => GC их никогда не удалит
Опасность 1: случайная глобальная без var/let/const
Опасность 2: неограниченный глобальный массив/кеш
Решение: использовать WeakMap, ограничивать размер кешей, избегать глобального состояния`;
