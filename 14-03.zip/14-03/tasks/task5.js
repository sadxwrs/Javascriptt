document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как проверить существует ли свойство в объекте? Покажи два способа.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const user = { name: 'Дина', age: undefined };

// Способ 1: оператор in (проверяет сам ключ)
console.log('name' in user);  // true
console.log('age' in user);   // true  (ключ есть, значение undefined)
console.log('email' in user); // false

// Способ 2: !== undefined (НЕ надёжно!)
console.log(user.name !== undefined);  // true
console.log(user.age !== undefined);   // false (ключ есть, но значение undefined!)
console.log(user.email !== undefined); // false`;

document.getElementById('output').textContent = `'name' in user  => true
'age' in user   => true  (ключ есть, даже если значение undefined)
'email' in user => false
Важно: 'in' надёжнее, чем проверка !== undefined`;
