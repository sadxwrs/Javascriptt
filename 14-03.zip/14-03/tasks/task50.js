document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как утечки через DOM-ссылки происходят в браузере? Как их обнаружить и устранить?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Утечка: JS хранит ссылку на DOM-элемент
// который уже удалён из документа

const detachedNodes = [];

function createLeak() {
  const div = document.createElement('div');
  div.innerHTML = '<span>Данные</span>';
  document.body.appendChild(div);

  detachedNodes.push(div); // сохранили ссылку!

  document.body.removeChild(div); // удалили из DOM
  // Но div ещё в detachedNodes => утечка!
}

// Исправление 1: использовать WeakMap вместо массива:
const weakCache = new WeakMap();

// Исправление 2: обнуление ссылки:
function fixed() {
  const div = document.createElement('div');
  document.body.appendChild(div);
  // ... работаем ...
  document.body.removeChild(div);
  // div = null; // явно обнулить
}

// Обнаружение: Chrome DevTools => Memory => Heap snapshot
// Искать: Detached HTMLElement`;

document.getElementById('output').textContent = `Утечка: JS-переменная хранит ссылку на удалённый DOM-элемент
detachedNodes.push(div) + removeChild(div) => утечка!
Исправление 1: WeakMap вместо обычного массива (слабые ссылки)
Исправление 2: явно обнулять ссылки (div = null)
Обнаружение: Chrome DevTools > Memory > Heap snapshot > Detached HTMLElement`;
