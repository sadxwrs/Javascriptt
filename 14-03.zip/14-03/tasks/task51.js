document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Добавь метод sayHi() в объект user, который выводит 'Привет, я ' + this.name.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const user = {
  name: 'Надя',
  age: 28,

  sayHi() {
    console.log('Привет, я ' + this.name);
  },

  // Полная форма:
  sayAge: function() {
    console.log(\`Мне \${this.age} лет\`);
  }
};

user.sayHi();  // 'Привет, я Надя'
user.sayAge(); // 'Мне 28 лет'`;

document.getElementById('output').textContent = `user.sayHi()  => 'Привет, я Надя'
user.sayAge() => 'Мне 28 лет'
this внутри метода — это объект, которому принадлежит метод`;
