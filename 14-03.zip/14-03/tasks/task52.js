document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое this в методе объекта? Что оно содержит?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const cat = {
  name: 'Мурзик',
  color: 'рыжий',

  describe() {
    console.log(this);           // сам объект cat
    console.log(this.name);      // 'Мурзик'
    console.log(this === cat);   // true
  }
};

cat.describe();

// this определяется В МОМЕНТ ВЫЗОВА, не в момент объявления
const fn = cat.describe;
// fn(); // this === undefined (strict mode) или window`;

document.getElementById('output').textContent = `this в методе объекта — это сам объект (cat)
this.name => 'Мурзик'
this === cat => true
ВАЖНО: this определяется в момент вызова (не объявления!)`;
