document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое shorthand-методы объекта? Перепиши { greet: function() {} } коротко.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Длинная форма:
const obj1 = {
  greet: function() { return 'hello'; },
  add:   function(a, b) { return a + b; }
};

// Shorthand (короткая форма — рекомендуется):
const obj2 = {
  greet() { return 'hello'; },
  add(a, b) { return a + b; },

  // Async и generator тоже поддерживаются:
  async fetchData() { /* ... */ },
  *gen() { yield 1; yield 2; }
};

console.log(obj2.greet()); // 'hello'
console.log(obj2.add(2, 3)); // 5`;

document.getElementById('output').textContent = `{ greet: function() {} } => { greet() {} } (shorthand)
obj2.greet() => 'hello'
obj2.add(2,3) => 5
Shorthand поддерживает async и generator методы`;
