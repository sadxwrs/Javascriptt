document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что вернёт this внутри обычной функции вызванной без объекта (в строгом режиме и без него)?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `'use strict';

// В строгом режиме (use strict):
function strictFn() {
  console.log(this); // undefined
}
strictFn();

// Без строгого режима:
function looseFn() {
  // this === window (в браузере) или global (в Node.js)
  console.log(typeof this); // 'object' (window)
}
looseFn();

// Стрелочные функции:
const arrow = () => {
  console.log(this); // this из окружающего контекста
};

console.log('strict: undefined, без strict: window/global');`;

document.getElementById('output').textContent = `Строгий режим (use strict): this === undefined
Без strict: this === window (браузер) или global (Node.js)
Стрелочная функция: this наследуется из внешнего контекста
Это частая причина ошибок!`;
