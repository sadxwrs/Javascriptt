document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое 'потеря контекста'? Покажи пример когда метод объекта теряет this при передаче как callback.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const timer = {
  name: 'Таймер',
  start() {
    console.log('Запуск от: ' + this.name);
  }
};

timer.start(); // 'Запуск от: Таймер' — OK

// Потеря контекста при передаче как callback:
const fn = timer.start;
fn(); // 'Запуск от: undefined' — this потерян!

// В setTimeout:
setTimeout(timer.start, 100);
// 'Запуск от: undefined' — this снова потерян!

// Причина: функция вызывается без объекта перед точкой
console.log('Метод теряет this, когда вызывается без объекта');`;

document.getElementById('output').textContent = `timer.start()       => 'Запуск от: Таймер' (OK)
const fn = timer.start; fn() => 'Запуск от: undefined' (потеря!)
setTimeout(timer.start) => 'Запуск от: undefined' (потеря!)
Причина: функция вызывается без obj.method() — без объекта перед точкой`;
