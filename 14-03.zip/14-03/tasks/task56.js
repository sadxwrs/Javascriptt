document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как исправить потерю контекста через .bind()? Напиши пример.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const user = {
  name: 'Сашa',
  greet() {
    console.log('Привет от ' + this.name);
  }
};

// Потеря контекста:
const fn = user.greet;
fn(); // 'Привет от undefined'

// Исправление через bind:
const boundFn = user.greet.bind(user);
boundFn(); // 'Привет от Саша'

// В setTimeout:
setTimeout(user.greet.bind(user), 100);
// => 'Привет от Саша'

// bind создаёт НОВУЮ функцию с фиксированным this:
console.log(typeof boundFn); // 'function'
console.log(user.greet === boundFn); // false`;

document.getElementById('output').textContent = `fn = user.greet; fn() => 'Привет от undefined' (потеря)
boundFn = user.greet.bind(user); boundFn() => 'Привет от Саша'
bind создаёт новую функцию с фиксированным this
setTimeout(user.greet.bind(user), 100) => работает корректно`;
