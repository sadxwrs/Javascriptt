document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как использовать стрелочную функцию чтобы сохранить this в методе?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const timer = {
  name: 'Отчёт',
  seconds: 0,

  start() {
    // Стрелочная функция берёт this из start()
    setInterval(() => {
      this.seconds++;
      console.log(\`\${this.name}: \${this.seconds}с\`);
    }, 1000);
  }
};

timer.start();
// 'Отчёт: 1с'
// 'Отчёт: 2с' ...

// Обычная функция здесь НЕ работает:
const broken = {
  name: 'Сломан',
  start() {
    setInterval(function() {
      console.log(this.name); // undefined — потеря this!
    }, 1000);
  }
};`;

document.getElementById('output').textContent = `Стрелочная функция => нет своего this => берёт из внешнего контекста
() => { this.seconds++ } — this === timer (из start())
Обычная function внутри setInterval => this теряется
Правило: для callback внутри методов используй стрелочные функции`;
