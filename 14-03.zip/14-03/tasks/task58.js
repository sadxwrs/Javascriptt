document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что делает call()? Вызови функцию с явным this через call().<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function introduce(greeting, punctuation) {
  console.log(\`\${greeting}, я \${this.name}\${punctuation}\`);
}

const alice = { name: 'Алиса' };
const bob   = { name: 'Боб' };

introduce.call(alice, 'Привет', '!'); // 'Привет, я Алиса!'
introduce.call(bob,   'Здравствуй', '.'); // 'Здравствуй, я Боб.'

// Заимствование метода:
const arr = [3, 1, 4, 1, 5];
const max = Math.max.call(null, ...arr);
console.log(max); // 5

// call(thisArg, arg1, arg2, ...)`;

document.getElementById('output').textContent = `introduce.call(alice, 'Привет', '!') => 'Привет, я Алиса!'
introduce.call(bob, 'Здравствуй', '.') => 'Здравствуй, я Боб.'
call(thisArg, arg1, arg2...) — аргументы перечисляются через запятую
Можно заимствовать методы из других объектов`;
