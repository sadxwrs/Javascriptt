document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Чем apply() отличается от call()? Напиши пример передачи массива аргументов.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function sum(a, b, c) {
  return a + b + c;
}

// call — аргументы через запятую:
console.log(sum.call(null, 1, 2, 3)); // 6

// apply — аргументы массивом:
console.log(sum.apply(null, [1, 2, 3])); // 6

const numbers = [5, 2, 8, 1, 9];

// apply удобен когда аргументы уже в массиве:
console.log(Math.max.apply(null, numbers)); // 9
console.log(Math.min.apply(null, numbers)); // 1

// Современная альтернатива — spread:
console.log(Math.max(...numbers)); // 9`;

document.getElementById('output').textContent = `call(ctx, a, b, c) — аргументы через запятую
apply(ctx, [a, b, c]) — аргументы массивом
sум.call(null, 1,2,3) => 6
Math.max.apply(null, [5,2,8,1,9]) => 9
Современная альтернатива: Math.max(...numbers)`;
