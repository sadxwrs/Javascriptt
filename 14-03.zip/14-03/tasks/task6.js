document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое оператор in? Напиши пример проверки наличия ключа.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const car = { brand: 'Toyota', model: 'Camry', year: 2023 };

console.log('brand' in car);    // true
console.log('color' in car);    // false
console.log('year' in car);     // true

// Работает и с числовыми ключами:
const arr = [10, 20, 30];
console.log(0 in arr); // true  (индекс существует)
console.log(5 in arr); // false (индекса нет)`;

document.getElementById('output').textContent = `'brand' in car => true
'color' in car => false
'year' in car  => true
0 in [10,20,30] => true
5 in [10,20,30] => false`;
