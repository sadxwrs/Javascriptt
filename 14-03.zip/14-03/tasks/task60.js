document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое bind()? Как создать 'привязанную' функцию и когда это полезно?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function multiply(factor) {
  return this.value * factor;
}

const obj = { value: 5 };

// Привязка this:
const multiplyByFive = multiply.bind(obj);
console.log(multiplyByFive(3)); // 15
console.log(multiplyByFive(10)); // 50

// Частичное применение (partial application):
const double = multiply.bind({ value: 2 });
console.log(double(7)); // 14

// Практика: обработчик событий
const btn = { label: 'Кнопка' };
function onClick() { console.log('Нажата: ' + this.label); }
const handler = onClick.bind(btn);
handler(); // 'Нажата: Кнопка'`;

document.getElementById('output').textContent = `bind(obj) => новая функция с зафиксированным this
multiplyByFive(3) => 15 (this.value = 5)
bind полезен для: event handlers, setTimeout, колбэков
bind также поддерживает partial application (фиксация аргументов)`;
