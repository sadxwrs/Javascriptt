document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что произойдёт если вызвать bind() дважды подряд на одной функции?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function greet() {
  return \`Привет от \${this.name}\`;
}

const a = { name: 'Аня' };
const b = { name: 'Боря' };

const boundA = greet.bind(a);
console.log(boundA()); // 'Привет от Аня'

// Второй bind НЕ перезапишет первый!
const boundAB = boundA.bind(b);
console.log(boundAB()); // 'Привет от Аня' — всё ещё Аня!

// Причина: bind возвращает обёртку с жёстко заданным this
// Повторный bind создаёт новую обёртку, но внутри всё равно
// вызывается оригинал с первым this

console.log('Первый bind побеждает — повторный bind бесполезен');`;

document.getElementById('output').textContent = `boundA = greet.bind(a) => 'Привет от Аня'
boundAB = boundA.bind(b) => 'Привет от Аня' (НЕ Боря!)
Первый bind побеждает — повторный не может изменить this
Причина: bind создаёт обёртку, второй bind обёртывает обёртку`;
