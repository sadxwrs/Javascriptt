document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как работает цепочка методов (method chaining)? Напиши объект с цепочкой методов возвращающих this.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `class QueryBuilder {
  constructor() {
    this.query = [];
  }

  select(fields) {
    this.query.push(\`SELECT \${fields}\`);
    return this; // возвращаем this для chaining
  }

  from(table) {
    this.query.push(\`FROM \${table}\`);
    return this;
  }

  where(condition) {
    this.query.push(\`WHERE \${condition}\`);
    return this;
  }

  build() {
    return this.query.join(' ');
  }
}

const sql = new QueryBuilder()
  .select('*')
  .from('users')
  .where('age > 18')
  .build();

console.log(sql);
// 'SELECT * FROM users WHERE age > 18'`;

document.getElementById('output').textContent = `new QueryBuilder().select('*').from('users').where('age>18').build()
=> 'SELECT * FROM users WHERE age > 18'
Ключ цепочки: каждый метод возвращает this
Применяется в: jQuery, Sequelize, Lodash и многих библиотеках`;
