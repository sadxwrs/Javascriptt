document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши метод toString() для объекта user возвращающий читаемое представление.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `class User {
  constructor(name, age, role) {
    this.name = name;
    this.age = age;
    this.role = role;
  }

  toString() {
    return \`User(\${this.name}, age:\${this.age}, role:\${this.role})\`;
  }

  valueOf() {
    return this.age; // числовой контекст
  }
}

const user = new User('Зина', 25, 'admin');

console.log(String(user)); // 'User(Зина, age:25, role:admin)'
console.log(\`\${user}\`);    // 'User(Зина, age:25, role:admin)'
console.log(user + 0);     // 25 (valueOf для числового контекста)
console.log(user + '');    // 'User(Зина, age:25, role:admin)'`;

document.getElementById('output').textContent = `String(user) => 'User(Зина, age:25, role:admin)'
\`\${user}\`    => 'User(Зина, age:25, role:admin)'
user + 0     => 25 (valueOf — числовой контекст)
user + ''    => 'User(Зина, age:25, role:admin)' (toString — строковый)`;
