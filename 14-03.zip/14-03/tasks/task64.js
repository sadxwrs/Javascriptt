document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое 'мягкое связывание' (soft binding)? Реализуй функцию softBind(fn, ctx).<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// softBind: привязывает this к ctx,
// НО позволяет переопределить через call/apply/явный вызов с объектом

Function.prototype.softBind = function(ctx) {
  const fn = this;
  return function(...args) {
    // Если this === undefined или global — используем ctx
    const thisArg = (!this || this === globalThis) ? ctx : this;
    return fn.apply(thisArg, args);
  };
};

const obj1 = { name: 'Объект 1' };
const obj2 = { name: 'Объект 2' };

function greet() { return this.name; }

const soft = greet.softBind(obj1);
console.log(soft());            // 'Объект 1' (дефолт ctx)
console.log(soft.call(obj2));   // 'Объект 2' (можно переопределить!)
obj2.greet = soft;
console.log(obj2.greet());      // 'Объект 2'`;

document.getElementById('output').textContent = `softBind(ctx): использует ctx только если this === undefined/global
soft()          => 'Объект 1' (ctx по умолчанию)
soft.call(obj2) => 'Объект 2' (можно переопределить через call!)
Отличие от bind: bind жёсткий, softBind — гибкий`;
