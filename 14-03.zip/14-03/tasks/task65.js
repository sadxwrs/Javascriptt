document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое явное, неявное и автоматическое связывание this? Опиши приоритет каждого вида.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function show() { return this?.name ?? 'undefined'; }

const a = { name: 'A', show };
const b = { name: 'B' };

// 1. АВТОМАТИЧЕСКОЕ (default binding) — наименьший приоритет:
show(); // undefined (strict) или window

// 2. НЕЯВНОЕ (implicit binding) — через объект:
a.show(); // 'A'

// 3. ЯВНОЕ (explicit binding) — через call/apply/bind:
show.call(b);     // 'B'
show.apply(b);    // 'B'
show.bind(b)();   // 'B'

// 4. new binding — наивысший приоритет:
function Ctor() { this.name = 'new'; }
const inst = new Ctor();
console.log(inst.name); // 'new'

// ПРИОРИТЕТ: new > явное > неявное > автоматическое`;

document.getElementById('output').textContent = `Приоритет (высший к низшему):
1. new binding: new Fn() => this = новый объект
2. Явное: call/apply/bind => this = указанный объект
3. Неявное: obj.method() => this = obj
4. Автоматическое: fn() => this = undefined (strict) / global`;
