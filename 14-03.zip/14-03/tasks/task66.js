document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй свой аналог Function.prototype.bind как полифил.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `Function.prototype.myBind = function(thisArg, ...partialArgs) {
  const fn = this;

  if (typeof fn !== 'function') {
    throw new TypeError('myBind должен вызываться на функции');
  }

  return function bound(...args) {
    // Если вызван через new — this = новый объект, игнорируем thisArg
    if (new.target) {
      return new fn(...partialArgs, ...args);
    }
    return fn.apply(thisArg, [...partialArgs, ...args]);
  };
};

function greet(greeting, punct) {
  return \`\${greeting}, \${this.name}\${punct}\`;
}

const user = { name: 'Яна' };
const boundHi = greet.myBind(user, 'Привет');
console.log(boundHi('!'));  // 'Привет, Яна!'
console.log(boundHi('.')); // 'Привет, Яна.'`;

document.getElementById('output').textContent = `greet.myBind(user, 'Привет') => частично применённая функция
boundHi('!') => 'Привет, Яна!'
boundHi('.') => 'Привет, Яна.'
Полифил учитывает: partial application, вызов через new`;
