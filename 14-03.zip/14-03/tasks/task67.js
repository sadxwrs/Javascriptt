document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что происходит с this при деструктуризации метода из объекта? Как это исправить?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `const user = {
  name: 'Паша',
  greet() { return \`Привет, \${this.name}\`; }
};

// Деструктуризация — теряет контекст!
const { greet } = user;
greet(); // 'Привет, undefined' — this потерян!

// Исправление 1: bind при деструктуризации
const { greet: boundGreet } = {
  greet: user.greet.bind(user)
};
boundGreet(); // 'Привет, Паша'

// Исправление 2: стрелочная функция в объекте
const user2 = {
  name: 'Паша',
  greet: function() { return \`Привет, \${this.name}\`; }
};
const { greet: g2 } = user2;
// Всё равно теряет контекст — нужен bind!

// Исправление 3 (классы): class fields
class User {
  name = 'Паша';
  greet = () => \`Привет, \${this.name}\`; // стрелочная — сохраняет this
}
const { greet: g3 } = new User();
console.log(g3()); // 'Привет, Паша'`;

document.getElementById('output').textContent = `const { greet } = user => greet() теряет this!
Исправление 1: greet: user.greet.bind(user)
Исправление 2: class field стрелочная функция: greet = () => ...
Стрелочный class field захватывает this навсегда при создании`;
