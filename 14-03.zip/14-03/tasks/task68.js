document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Объясни почему setTimeout(obj.method, 1000) теряет контекст и покажи три способа исправить.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `const counter = {
  count: 0,
  tick() {
    this.count++;
    console.log(this.count);
  }
};

// ПРОБЛЕМА: потеря контекста
// setTimeout(counter.tick, 1000); // this === window/undefined

// Способ 1: стрелочная обёртка
setTimeout(() => counter.tick(), 0);

// Способ 2: bind
setTimeout(counter.tick.bind(counter), 0);

// Способ 3: сохранить ссылку
const tick = counter.tick.bind(counter);
setTimeout(tick, 0);

// Все три способа выведут: 1`;

document.getElementById('output').textContent = `setTimeout(obj.method, 1000) => метод вызывается без obj => this теряется
Способ 1: () => obj.method() — стрелочная обёртка
Способ 2: obj.method.bind(obj) — жёсткая привязка
Способ 3: const fn = obj.method.bind(obj); setTimeout(fn, 1000)
Все три выведут: 1`;
