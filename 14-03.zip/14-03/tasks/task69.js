document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое функция-конструктор? Напиши конструктор User(name, age).<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Функция-конструктор — обычная функция, вызываемая через new
// Соглашение: имя с заглавной буквы

function User(name, age) {
  // new автоматически создаёт this = {}
  this.name = name;
  this.age = age;
  this.isAdmin = false;

  this.greet = function() {
    return \`Привет, я \${this.name}, мне \${this.age}\`;
  };
  // new автоматически возвращает this
}

const alice = new User('Алиса', 28);
const bob   = new User('Боб',   35);

console.log(alice.name);    // 'Алиса'
console.log(alice.greet()); // 'Привет, я Алиса, мне 28'
console.log(bob.age);       // 35
console.log(alice instanceof User); // true`;

document.getElementById('output').textContent = `new User('Алиса', 28) => { name:'Алиса', age:28, isAdmin:false }
alice.greet() => 'Привет, я Алиса, мне 28'
alice instanceof User => true
new создаёт пустой объект, присваивает this, возвращает его`;
