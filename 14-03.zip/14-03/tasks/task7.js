document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Перебери все ключи объекта с помощью цикла for...in.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const product = { name: 'Ноутбук', price: 50000, inStock: true };

for (const key in product) {
  console.log(\`\${key}: \${product[key]}\`);
}
// name: Ноутбук
// price: 50000
// inStock: true

// Только собственные ключи (без прототипных):
for (const key in product) {
  if (Object.hasOwn(product, key)) {
    console.log(key);
  }
}`;

document.getElementById('output').textContent = `for...in выводит:
name: Ноутбук
price: 50000
inStock: true
Внимание: for...in обходит и унаследованные ключи — используй hasOwn для фильтрации`;
