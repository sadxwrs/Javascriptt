document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что делает оператор new шаг за шагом?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `function Animal(type, sound) {
  this.type  = type;
  this.sound = sound;
}

// Что делает new Animal('кот', 'мяу'):
// Шаг 1: создаёт пустой объект: let obj = {}
// Шаг 2: устанавливает прототип: obj.__proto__ = Animal.prototype
// Шаг 3: вызывает конструктор с this = obj: Animal.call(obj, 'кот', 'мяу')
// Шаг 4: возвращает obj (если конструктор не вернул другой объект)

const cat = new Animal('кот', 'мяу');
console.log(cat.type);  // 'кот'
console.log(cat.sound); // 'мяу'
console.log(cat instanceof Animal); // true
console.log(Object.getPrototypeOf(cat) === Animal.prototype); // true`;

document.getElementById('output').textContent = `new Fn() шаг за шагом:
1. Создать пустой объект: obj = {}
2. Установить прототип: obj.__proto__ = Fn.prototype
3. Вызвать Fn с this = obj
4. Вернуть obj (если Fn не вернула объект явно)
cat instanceof Animal => true`;
