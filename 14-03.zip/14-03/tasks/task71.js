document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Почему имя конструктора принято писать с заглавной буквы?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Соглашение: PascalCase для конструкторов
// Это сигнал: 'вызывай меня через new!'

function user(name) { this.name = name; } // плохо — непонятно
function User(name) { this.name = name; } // хорошо

// Без new конструктор создаёт глобальные переменные!
user('Тест'); // this === window => window.name = 'Тест'!

// new.target помогает защититься:
function SafeUser(name) {
  if (!new.target) {
    throw new Error('Используй new!');
  }
  this.name = name;
}

// new SafeUser('Аня') — OK
// SafeUser('Аня')     — ошибка
console.log('Заглавная буква = соглашение: вызывай через new');`;

document.getElementById('output').textContent = `Заглавная буква — соглашение, сигнализирующее 'вызывай через new'
user('Тест') без new => this = window => глобальное загрязнение!
new.target !== undefined — функция вызвана через new
new.target === undefined — функция вызвана напрямую`;
