document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что вернёт new User('Иван', 25)? Что будет в созданном объекте?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `function User(name, age) {
  this.name = name;
  this.age  = age;
  this.role = 'user';
}

const ivan = new User('Иван', 25);

console.log(ivan);        // { name:'Иван', age:25, role:'user' }
console.log(ivan.name);   // 'Иван'
console.log(ivan.age);    // 25
console.log(ivan.role);   // 'user'

// Тип:
console.log(typeof ivan);          // 'object'
console.log(ivan instanceof User); // true
console.log(ivan.constructor === User); // true`;

document.getElementById('output').textContent = `new User('Иван', 25) => { name:'Иван', age:25, role:'user' }
typeof ivan => 'object'
ivan instanceof User => true
ivan.constructor === User => true
new всегда возвращает объект (не примитив)`;
