document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое new.target? Как проверить что функция вызвана через new?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `function User(name) {
  // new.target содержит функцию если вызвана через new
  // new.target === undefined если вызвана без new
  console.log(new.target);

  if (!new.target) {
    // Автоисправление: вызвать себя через new
    return new User(name);
  }

  this.name = name;
}

const a = new User('Аня');  // new.target === User
console.log(a.name); // 'Аня'

const b = User('Боря');     // new.target === undefined => автоисправление
console.log(b.name); // 'Боря'`;

document.getElementById('output').textContent = `new User('Аня'):  new.target === User (функция)
User('Боря'):     new.target === undefined
Автоисправление: if (!new.target) return new User(name)
ISPOльзуется для защиты конструкторов от вызова без new`;
