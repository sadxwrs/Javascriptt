document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что происходит если конструктор явно возвращает объект? А если примитив?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Конструктор возвращает ОБЪЕКТ — new вернёт этот объект:
function ReturnObj(name) {
  this.name = name;
  return { custom: true, value: 42 }; // объект!
}
const o = new ReturnObj('Тест');
console.log(o); // { custom:true, value:42 } — this проигнорирован!

// Конструктор возвращает ПРИМИТИВ — new вернёт this:
function ReturnPrimitive(name) {
  this.name = name;
  return 42; // примитив — игнорируется!
}
const p = new ReturnPrimitive('Тест');
console.log(p); // { name:'Тест' } — примитив проигнорирован`;

document.getElementById('output').textContent = `return объект => new вернёт этот объект (this игнорируется)
return примитив => new вернёт this (примитив игнорируется)
new ReturnObj('Тест')       => { custom:true, value:42 }
new ReturnPrimitive('Тест') => { name:'Тест' }`;
