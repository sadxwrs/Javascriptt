document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши конструктор Counter() с методами increment(), decrement() и геттером value.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function Counter(initial = 0) {
  let _count = initial; // приватная переменная

  this.increment = function(step = 1) {
    _count += step;
    return this; // chaining
  };

  this.decrement = function(step = 1) {
    _count -= step;
    return this;
  };

  this.reset = function() {
    _count = initial;
    return this;
  };

  Object.defineProperty(this, 'value', {
    get() { return _count; }
  });
}

const c = new Counter(10);
console.log(c.value);               // 10
c.increment().increment().decrement();
console.log(c.value);               // 11
c.reset();
console.log(c.value);               // 10`;

document.getElementById('output').textContent = `new Counter(10).value => 10
increment().increment().decrement() — chaining
value => 11
reset() => value = 10
_count — приватная переменная (через замыкание)`;
