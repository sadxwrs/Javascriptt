document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое prototype функции-конструктора? Как добавить метод через прототип?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function Animal(name) {
  this.name = name;
}

// Добавляем метод в прототип:
Animal.prototype.speak = function() {
  return \`\${this.name} говорит: \`;
};

Animal.prototype.toString = function() {
  return \`Animal(\${this.name})\`;
};

const cat = new Animal('Мурка');
const dog = new Animal('Рекс');

console.log(cat.speak()); // 'Мурка говорит: '
console.log(dog.speak()); // 'Рекс говорит: '

// Метод один на всех — экономия памяти!
console.log(cat.speak === dog.speak); // true (один объект-функция!)

// Все экземпляры делят прототип:
console.log(Object.getPrototypeOf(cat) === Animal.prototype); // true`;

document.getElementById('output').textContent = `Animal.prototype.speak = fn — один метод для всех экземпляров
cat.speak === dog.speak => true (одна функция в памяти!)
В отличие от this.method = fn — создаёт копию для КАЖДОГО экземпляра
Object.getPrototypeOf(cat) === Animal.prototype => true`;
