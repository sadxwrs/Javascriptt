document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> В чём разница между добавлением метода через this.method и через Constructor.prototype.method?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function UserA(name) {
  this.name = name;
  this.greet = function() { // копия для КАЖДОГО экземпляра
    return \`Привет от \${this.name}\`;
  };
}

function UserB(name) {
  this.name = name;
}
UserB.prototype.greet = function() { // одна для ВСЕХ
  return \`Привет от \${this.name}\`;
};

const a1 = new UserA('Аня');
const a2 = new UserA('Боря');
const b1 = new UserB('Аня');
const b2 = new UserB('Боря');

console.log(a1.greet === a2.greet); // false (разные копии!)
console.log(b1.greet === b2.greet); // true  (одна функция!)

// Память: UserA создаёт N функций, UserB — 1 функцию
console.log('prototype — экономия памяти');`;

document.getElementById('output').textContent = `this.method = fn: копия функции для КАЖДОГО экземпляра
Prototype.method = fn: одна функция для ВСЕХ экземпляров
a1.greet === a2.greet => false (разные копии — расход памяти)
b1.greet === b2.greet => true (одна функция — экономия!)
Правило: методы на прототипе, данные через this`;
