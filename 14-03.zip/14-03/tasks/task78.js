document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое instanceof? Как проверить принадлежит ли объект конструктору?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function Animal(name) { this.name = name; }
function Dog(name, breed) {
  Animal.call(this, name);
  this.breed = breed;
}
Dog.prototype = Object.create(Animal.prototype);

const rex = new Dog('Рекс', 'Лабрадор');

console.log(rex instanceof Dog);    // true
console.log(rex instanceof Animal); // true  (по цепочке прототипов!)
console.log(rex instanceof Object); // true  (все объекты — Object)

// instanceof проверяет цепочку прототипов:
// rex.__proto__ === Dog.prototype? => true
// rex.__proto__.__proto__ === Animal.prototype? => true

console.log(Array.isArray([]));        // true
console.log([] instanceof Array);      // true
console.log([] instanceof Object);     // true`;

document.getElementById('output').textContent = `rex instanceof Dog    => true
rex instanceof Animal => true (по цепочке прототипов!)
rex instanceof Object => true (все объекты наследуют Object)
instanceof проверяет: есть ли Constructor.prototype в цепочке прототипов`;
