document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши конструктор Stack() с методами push, pop, peek, isEmpty.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function Stack() {
  const items = []; // приватный массив

  this.push = function(item) {
    items.push(item);
    return this;
  };

  this.pop = function() {
    if (this.isEmpty()) throw new Error('Stack is empty');
    return items.pop();
  };

  this.peek = function() {
    if (this.isEmpty()) return undefined;
    return items[items.length - 1];
  };

  this.isEmpty = function() {
    return items.length === 0;
  };

  this.size = function() { return items.length; };
}

const s = new Stack();
s.push(1).push(2).push(3);
console.log(s.peek());  // 3
console.log(s.pop());   // 3
console.log(s.size());  // 2
console.log(s.isEmpty()); // false`;

document.getElementById('output').textContent = `s.push(1).push(2).push(3)
s.peek() => 3 (верхний элемент, не удаляет)
s.pop()  => 3 (удаляет верхний)
s.size() => 2
s.isEmpty() => false
STACK: LIFO (Last In First Out)`;
