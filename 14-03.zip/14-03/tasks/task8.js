document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое вычисляемые свойства (computed properties)? Напиши пример с переменной в качестве ключа.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const field = 'name';
const prefix = 'user';

const obj = {
  [field]: 'Елена',           // переменная как ключ
  [\`\${prefix}Age\`]: 30,       // шаблонная строка как ключ
  [1 + 1]: 'два',             // выражение как ключ
};

console.log(obj.name);     // 'Елена'
console.log(obj.userAge);  // 30
console.log(obj[2]);       // 'два'`;

document.getElementById('output').textContent = `obj[field]       => 'Елена'
obj.userAge      => 30
obj[2]           => 'два'
Вычисляемые свойства: [выражение] вычисляется в момент создания объекта`;
