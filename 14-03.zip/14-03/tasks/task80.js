document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое constructor свойство объекта? Откуда оно берётся?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function User(name) {
  this.name = name;
}

const u = new User('Тест');

// constructor — свойство прототипа, указывает на конструктор
console.log(u.constructor);          // [Function: User]
console.log(u.constructor === User); // true

// Откуда берётся? Из User.prototype:
console.log(User.prototype.constructor === User); // true

// Опасность: замена прототипа ломает constructor!
User.prototype = { greet() {} }; // заменили!
const u2 = new User('Тест2');
console.log(u2.constructor === User);   // false!
console.log(u2.constructor === Object); // true (унаследовано!)

// Исправление: явно восстановить
User.prototype = { greet() {}, constructor: User };`;

document.getElementById('output').textContent = `u.constructor === User => true (из User.prototype)
User.prototype.constructor === User => true
Опасность: User.prototype = {} сбрасывает constructor!
После замены: u2.constructor === Object (унаследованный)
Исправление: явно указать constructor: User`;
