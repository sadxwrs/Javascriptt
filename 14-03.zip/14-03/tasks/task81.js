document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй собственный аналог оператора new как функцию myNew(Constructor, ...args).<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function myNew(Constructor, ...args) {
  // Шаг 1: создать объект с прототипом конструктора
  const obj = Object.create(Constructor.prototype);

  // Шаг 2: вызвать конструктор с this = obj
  const result = Constructor.apply(obj, args);

  // Шаг 3: вернуть объект (или результат если он объект)
  return (result !== null && typeof result === 'object')
    ? result
    : obj;
}

function Person(name, age) {
  this.name = name;
  this.age  = age;
}
Person.prototype.greet = function() {
  return \`Привет, я \${this.name}\`;
};

const p = myNew(Person, 'Катя', 25);
console.log(p.name);            // 'Катя'
console.log(p.greet());         // 'Привет, я Катя'
console.log(p instanceof Person); // true`;

document.getElementById('output').textContent = `myNew(Person, 'Катя', 25)
=> p.name = 'Катя'
=> p.greet() = 'Привет, я Катя'
=> p instanceof Person = true
Шаги: Object.create(proto) => Constructor.apply(obj, args) => вернуть obj`;
