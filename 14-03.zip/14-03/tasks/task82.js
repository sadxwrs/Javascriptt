document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое абстрактный фабричный метод в контексте конструкторов JS? Напиши пример.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// Фабричный метод: конструктор решает какой подтип создать

function Shape(type, ...args) {
  // Фабрика — создаём нужный подтип
  if (new.target === Shape) {
    if (type === 'circle')    return new Circle(args[0]);
    if (type === 'rectangle') return new Rectangle(args[0], args[1]);
    throw new Error(\`Неизвестная фигура: \${type}\`);
  }
}

function Circle(r) {
  this.type = 'circle';
  this.area = () => Math.PI * r ** 2;
}

function Rectangle(w, h) {
  this.type = 'rectangle';
  this.area = () => w * h;
}

const c = new Shape('circle', 5);
const r = new Shape('rectangle', 4, 6);

console.log(c.type);         // 'circle'
console.log(c.area().toFixed(2)); // '78.54'
console.log(r.area());       // 24`;

document.getElementById('output').textContent = `new Shape('circle', 5)       => Circle {type:'circle', area:fn}
new Shape('rectangle', 4, 6) => Rectangle {type:'rectangle', area:fn}
c.area().toFixed(2) => '78.54' (π * 25)
r.area()            => 24 (4 * 6)
Фабрика инкапсулирует логику создания нужного подтипа`;
