document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши конструктор LinkedList() с методами append, prepend, delete, find.<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function LinkedList() {
  let head = null;
  let size = 0;

  function Node(val) { this.val = val; this.next = null; }

  this.append = function(val) {
    const node = new Node(val);
    if (!head) { head = node; }
    else { let cur = head; while (cur.next) cur = cur.next; cur.next = node; }
    size++; return this;
  };

  this.prepend = function(val) {
    const node = new Node(val);
    node.next = head; head = node; size++; return this;
  };

  this.delete = function(val) {
    if (!head) return;
    if (head.val === val) { head = head.next; size--; return; }
    let cur = head;
    while (cur.next && cur.next.val !== val) cur = cur.next;
    if (cur.next) { cur.next = cur.next.next; size--; }
  };

  this.find = function(val) {
    let cur = head;
    while (cur) { if (cur.val === val) return cur; cur = cur.next; }
    return null;
  };

  this.toArray = function() {
    const arr = []; let cur = head;
    while (cur) { arr.push(cur.val); cur = cur.next; }
    return arr;
  };

  Object.defineProperty(this, 'length', { get: () => size });
}

const ll = new LinkedList();
ll.append(1).append(2).append(3).prepend(0);
console.log(ll.toArray()); // [0,1,2,3]
ll.delete(2);
console.log(ll.toArray()); // [0,1,3]
console.log(ll.find(1));   // Node {val:1}`;

document.getElementById('output').textContent = `ll.append(1).append(2).append(3).prepend(0)
ll.toArray() => [0,1,2,3]
ll.delete(2) => удаляет узел со значением 2
ll.toArray() => [0,1,3]
ll.find(1)   => Node {val:1, next:...}`;
