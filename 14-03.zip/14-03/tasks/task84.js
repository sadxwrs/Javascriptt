document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое опциональная цепочка ?. ? Зачем она нужна?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// ?. — безопасный доступ к свойствам которые могут не существовать

const user = { name: 'Лёша', address: null };

// Без ?. — ошибка если address === null:
// console.log(user.address.city); // TypeError!

// С ?. — возвращает undefined вместо ошибки:
console.log(user.address?.city); // undefined (не ошибка!)
console.log(user.name?.toUpperCase()); // 'ЛЁША'

// Цепочка:
const company = {
  ceo: { name: 'Шеф', contact: { email: 'ceo@corp.com' } }
};
console.log(company.ceo?.contact?.email);   // 'ceo@corp.com'
console.log(company.cto?.contact?.email);   // undefined (cto нет)`;

document.getElementById('output').textContent = `user.address?.city => undefined (не TypeError!)
user.name?.toUpperCase() => 'ЛЁША'
company.ceo?.contact?.email => 'ceo@corp.com'
company.cto?.contact?.email => undefined (cto не существует)
?. защищает от TypeError при доступе к null/undefined`;
