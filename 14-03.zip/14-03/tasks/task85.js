document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Чем user?.address?.city лучше user && user.address && user.address.city?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const user1 = { name: 'Аня', address: { city: 'Москва' } };
const user2 = null;
const user3 = { name: 'Боря', address: null };

// Старый способ (многословно):
const city1 = user1 && user1.address && user1.address.city;
const city2 = user2 && user2.address && user2.address.city;
const city3 = user3 && user3.address && user3.address.city;

console.log(city1); // 'Москва'
console.log(city2); // null
console.log(city3); // null

// Новый способ (кратко и читаемо):
console.log(user1?.address?.city); // 'Москва'
console.log(user2?.address?.city); // undefined
console.log(user3?.address?.city); // undefined

// Разница: && возвращает первое falsy, ?. всегда undefined`;

document.getElementById('output').textContent = `user && user.address && user.address.city — многословно
user?.address?.city — компактно и читаемо
Разница: && вернёт null/false/0 при falsy
?. всегда возвращает undefined при обрыве цепочки`;
