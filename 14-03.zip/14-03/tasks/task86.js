document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что вернёт null?.property? А undefined?.method()?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `console.log(null?.property);       // undefined (не TypeError)
console.log(undefined?.property);   // undefined
console.log(null?.method());        // undefined (метод не вызван)
console.log(undefined?.method());   // undefined

// ?. останавливает вычисление при null/undefined:
let count = 0;
null?.increment(count++); // count++ НЕ выполнится!
console.log(count); // 0 (не изменился!)

// Только null и undefined вызывают «короткое замыкание»:
console.log(0?.toString()); // '0' (0 — не null/undefined!)
console.log('')?.length;    // 0 (пустая строка — не null!)`;

document.getElementById('output').textContent = `null?.property      => undefined
undefined?.property => undefined
null?.method()      => undefined (метод не вызывается!)
null?.increment(count++) => count++ НЕ выполняется (короткое замыкание)
0?.toString() => '0' (0 не является null/undefined)`;
