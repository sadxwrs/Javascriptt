document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как использовать ?. для вызова метода который может не существовать?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const user1 = {
  name: 'Аня',
  greet() { return \`Привет, \${this.name}\`; }
};
const user2 = { name: 'Боря' }; // нет метода greet

// Без ?. — ошибка если метод не существует:
// user2.greet(); // TypeError: user2.greet is not a function

// С ?. — безопасный вызов:
console.log(user1.greet?.());  // 'Привет, Аня'
console.log(user2.greet?.());  // undefined (не ошибка!)

// Практика: опциональный callback
function process(data, onSuccess, onError) {
  try {
    const result = data.value * 2;
    onSuccess?.(result);   // callback может не передаваться
  } catch(e) {
    onError?.(e);           // тоже опциональный
  }
}
process({ value: 5 }, v => console.log('Результат:', v));
// 'Результат: 10'`;

document.getElementById('output').textContent = `user1.greet?.() => 'Привет, Аня'
user2.greet?.() => undefined (не TypeError!)
onSuccess?.() — безопасный вызов колбэка
Синтаксис: obj.method?.() — с точкой перед ()`;
