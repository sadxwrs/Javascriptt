document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как использовать ?. для доступа к элементу массива: arr?.[0]?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const arr1 = [10, 20, 30];
const arr2 = null;
const arr3 = undefined;

console.log(arr1?.[0]);  // 10
console.log(arr2?.[0]);  // undefined (не ошибка!)
console.log(arr3?.[0]);  // undefined

// Вложенные массивы:
const matrix = [[1, 2], [3, 4], null];
console.log(matrix[0]?.[1]);  // 2
console.log(matrix[2]?.[0]);  // undefined (строка null)

// Динамический ключ:
const key = 'name';
const obj = null;
console.log(obj?.[key]); // undefined

const data = { name: 'Тест' };
console.log(data?.[key]); // 'Тест'`;

document.getElementById('output').textContent = `arr1?.[0] => 10
arr2?.[0] => undefined (arr2 = null)
matrix[0]?.[1] => 2
matrix[2]?.[0] => undefined (строка null)
obj?.[key]     => undefined (obj = null)
Синтаксис: arr?.[index] — с квадратными скобками`;
