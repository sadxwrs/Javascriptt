document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Можно ли использовать ?. слева от оператора присваивания? Что произойдёт?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const user = { address: { city: 'Москва' } };

// ?. НЕЛЬЗЯ использовать слева от =:
// user?.address?.city = 'Питер'; // SyntaxError!

// Причина: нельзя присваивать к undefined

// Правильно: сначала проверить, потом присвоить
if (user?.address) {
  user.address.city = 'Питер';
}
console.log(user.address.city); // 'Питер'

// Или через логику:
const updateCity = (u, city) => {
  if (u?.address) u.address.city = city;
};
updateCity(user, 'Сочи');
console.log(user.address.city); // 'Сочи'

updateCity(null, 'Сочи'); // ничего не происходит, не ошибка`;

document.getElementById('output').textContent = `user?.address?.city = 'Питер' => SyntaxError!
?. нельзя использовать слева от оператора присваивания
Правильно: сначала проверить через ?., потом присваивать
if (user?.address) { user.address.city = 'Питер' }`;
