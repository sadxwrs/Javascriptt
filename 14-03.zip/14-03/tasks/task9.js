document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое shorthand-свойства объекта? Перепиши {name: name, age: age} в короткой форме.<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const name = 'Иван';
const age = 25;
const city = 'Москва';

// Длинная форма:
const user1 = { name: name, age: age, city: city };

// Shorthand (короткая форма):
const user2 = { name, age, city };

console.log(user1); // { name:'Иван', age:25, city:'Москва' }
console.log(user2); // { name:'Иван', age:25, city:'Москва' }
console.log(JSON.stringify(user1) === JSON.stringify(user2)); // true`;

document.getElementById('output').textContent = `{ name: name, age: age } === { name, age } (shorthand)
user2 => { name:'Иван', age:25, city:'Москва' }
Shorthand работает когда имя переменной совпадает с именем ключа`;
