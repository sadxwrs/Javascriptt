document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Объедини ?. с оператором ??: верни значение по умолчанию если цепочка обрывается.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `const users = [
  { name: 'Аня', address: { city: 'Москва', zip: '101000' } },
  { name: 'Боря', address: null },
  { name: 'Вася' },
  null
];

users.forEach((user, i) => {
  const city = user?.address?.city ?? 'Город неизвестен';
  const zip  = user?.address?.zip  ?? 'Индекс неизвестен';
  const name = user?.name ?? 'Аноним';
  console.log(\`\${i}: \${name} — \${city} (\${zip})\`);
});
// 0: Аня — Москва (101000)
// 1: Боря — Город неизвестен (Индекс неизвестен)
// 2: Вася — Город неизвестен (Индекс неизвестен)
// 3: Аноним — Город неизвестен (Индекс неизвестен)`;

document.getElementById('output').textContent = `user?.address?.city ?? 'Город неизвестен'
0: Аня — Москва (101000)
1: Боря — Город неизвестен (Индекс неизвестен)
2: Вася — Город неизвестен (Индекс неизвестен)
3: Аноним — Город неизвестен (Индекс неизвестен)
?? возвращает правую часть только при null/undefined (не при 0 или '')`;
