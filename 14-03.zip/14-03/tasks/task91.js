document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое 'короткое замыкание' в ?. ? Что если первый элемент цепочки null?<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// Короткое замыкание: при null/undefined всё правее НЕ вычисляется

let sideEffect = 0;
const obj = null;

// Всё правое НЕ вычисляется:
obj?.method(sideEffect++); // sideEffect++ не выполнится!
console.log(sideEffect); // 0

obj?.a.b.c.d.e; // вся цепочка игнорируется
console.log('Нет ошибки!');

// Важно: ?. на первом элементе — вся правая часть пропускается
const fn = null;
fn?.(); // undefined, функция не вызвана

// ?. НЕ защищает правые части цепочки от ошибок:
const a = { b: null };
// a?.b.c — ошибка! a?.b = null, null.c = TypeError!
// Нужно: a?.b?.c`;

document.getElementById('output').textContent = `Короткое замыкание: при null/undefined всё правее НЕ выполняется
obj?.method(sideEffect++) => sideEffect++ НЕ выполняется
console.log(sideEffect) => 0 (не изменился)
a?.b.c — ОШИБКА если b = null! Нужно a?.b?.c
?. защищает только то место где стоит, не всю цепочку`;
