document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Напиши функцию getDeep(obj, path) безопасно извлекающую значение по пути 'a.b.c'.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `function getDeep(obj, path) {
  return path.split('.').reduce((current, key) => {
    return current?.[key];
  }, obj);
}

const data = {
  user: {
    profile: {
      name: 'Маша',
      scores: [95, 87, 92]
    }
  }
};

console.log(getDeep(data, 'user.profile.name'));    // 'Маша'
console.log(getDeep(data, 'user.profile.scores.0')); // 95
console.log(getDeep(data, 'user.profile.age'));      // undefined
console.log(getDeep(data, 'user.missing.deep'));     // undefined
console.log(getDeep(null, 'user.name'));             // undefined`;

document.getElementById('output').textContent = `getDeep(data, 'user.profile.name')    => 'Маша'
getDeep(data, 'user.profile.scores.0') => 95
getDeep(data, 'user.profile.age')      => undefined (нет поля)
getDeep(data, 'user.missing.deep')     => undefined (нет пути)
getDeep(null, 'user.name')             => undefined (не ошибка)`;
