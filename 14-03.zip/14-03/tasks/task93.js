document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Когда ?. может скрыть баги? Приведи пример чрезмерного использования.<br><span class="diff-badge diff-medium">Среднее</span>`;

document.getElementById('solutionCode').textContent = `// ?. может замаскировать реальные ошибки!

// Плохо: слишком много ?. скрывает что именно сломалось
function processUser(user) {
  // Если user всегда должен иметь name — зачем ?. ?
  const name = user?.name?.toUpperCase()?.trim();
  // Если name undefined — баг замаскирован!
  sendEmail(name); // отправит undefined как имя!
}

// Лучше: явная проверка где нужно
function processUserBetter(user) {
  if (!user) throw new Error('user обязателен');
  if (!user.name) throw new Error('user.name обязателен');
  const name = user.name.toUpperCase().trim(); // без ?.!
  sendEmail(name);
}

function sendEmail(to) { console.log('Отправка:', to); }

// Правило: используй ?. только там где null/undefined — ожидаемо!`;

document.getElementById('output').textContent = `Проблема: user?.name?.trim() вернёт undefined молча — баг замаскирован!
Отправка: undefined — некорректно, но без ошибки
Правило: ?. только там где null/undefined является нормальным значением
Где данные ОБЯЗАНЫ быть — лучше явная проверка + throw`;
