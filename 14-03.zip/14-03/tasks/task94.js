document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Реализуй полифил для ?. как функцию optChain(obj, ...keys).<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `function optChain(obj, ...keys) {
  let current = obj;
  for (const key of keys) {
    if (current === null || current === undefined) {
      return undefined;
    }
    // Поддержка вызова методов: ключ вида 'method()'
    if (typeof key === 'string' && key.endsWith('()')) {
      const methodName = key.slice(0, -2);
      if (typeof current[methodName] !== 'function') return undefined;
      current = current[methodName]();
    } else {
      current = current[key];
    }
  }
  return current;
}

const data = { user: { name: 'Тест', greet() { return 'Привет'; } } };

console.log(optChain(data, 'user', 'name'));     // 'Тест'
console.log(optChain(data, 'user', 'greet()')); // 'Привет'
console.log(optChain(null, 'user', 'name'));     // undefined
console.log(optChain(data, 'missing', 'name')); // undefined`;

document.getElementById('output').textContent = `optChain(data, 'user', 'name')     => 'Тест'
optChain(data, 'user', 'greet()')  => 'Привет' (вызов метода)
optChain(null, 'user', 'name')     => undefined
optChain(data, 'missing', 'name')  => undefined
При null/undefined на любом шаге — сразу возврат undefined`;
