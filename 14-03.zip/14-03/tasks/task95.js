document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Как ?. работает с Proxy? Какие ловушки задействуются при обращении через ?. ?<br><span class="diff-badge diff-hard">Сложное</span>`;

document.getElementById('solutionCode').textContent = `// ?. задействует ловушку 'get' Proxy

const handler = {
  get(target, prop, receiver) {
    console.log(\`GET: \${String(prop)}\`);
    return Reflect.get(target, prop, receiver);
  }
};

const obj = new Proxy({ name: 'Тест', inner: null }, handler);

// Обычный доступ:
console.log(obj.name); // GET: name => 'Тест'

// ?. тоже вызывает get:
console.log(obj?.name); // GET: name => 'Тест'

// При null внутри — get вызывается до null:
// obj.inner?.missing:
// 1. GET: inner => null
// 2. null?.missing => undefined (get больше не вызывается!)
console.log(obj.inner?.missing); // GET: inner, затем undefined`;

document.getElementById('output').textContent = `?. задействует ловушку get Proxy
obj?.name => GET: name => 'Тест'
obj.inner?.missing => GET: inner => null, затем цепочка обрывается
Proxy.get вызывается при обращении к каждому свойству через ?.`;
