document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое Symbol? Как создать Symbol?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Symbol — уникальный примитивный тип, введён в ES6

// Создание (без new!):
const s1 = Symbol();
const s2 = Symbol('описание'); // описание — для отладки
const s3 = Symbol('id');

console.log(typeof s1);  // 'symbol'
console.log(s2.description); // 'описание'

// Каждый Symbol уникален:
console.log(s2 === s3); // false (разные, хоть описание одинаково!)
console.log(Symbol('x') === Symbol('x')); // false

// Symbol нельзя создать через new:
// new Symbol(); // TypeError

// toString:
console.log(s2.toString()); // 'Symbol(описание)'`;

document.getElementById('output').textContent = `Symbol() — уникальный примитивный тип
Symbol('описание').description => 'описание'
Symbol('x') === Symbol('x') => false (каждый уникален!)
typeof Symbol() => 'symbol'
new Symbol() => TypeError (нельзя через new)`;
