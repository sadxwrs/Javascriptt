document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Почему каждый Symbol уникален? Что вернёт Symbol('id') === Symbol('id')?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Symbol всегда создаёт НОВЫЙ уникальный идентификатор
// Описание — лишь метка для отладки, не значение!

console.log(Symbol('id') === Symbol('id')); // false!

const id1 = Symbol('id');
const id2 = Symbol('id');
console.log(id1 === id2); // false (разные объекты в памяти!)

// Это полезно для уникальных ключей:
const KEY_A = Symbol('key');
const KEY_B = Symbol('key');

const obj = {};
obj[KEY_A] = 'значение A';
obj[KEY_B] = 'значение B';

console.log(obj[KEY_A]); // 'значение A'
console.log(obj[KEY_B]); // 'значение B'
// Хотя описание одинаковое — ключи разные!`;

document.getElementById('output').textContent = `Symbol('id') === Symbol('id') => false!
Каждый Symbol() создаёт новый уникальный идентификатор
Описание — только для отладки, не влияет на уникальность
obj[Symbol('key')] и obj[Symbol('key')] — два РАЗНЫХ свойства`;
