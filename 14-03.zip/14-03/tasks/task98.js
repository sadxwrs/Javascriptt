document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое описание (description) Symbol? Как его получить?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `const s = Symbol('мой символ');

// Получить описание:
console.log(s.description); // 'мой символ'
console.log(s.toString());  // 'Symbol(мой символ)'

// Symbol без описания:
const anon = Symbol();
console.log(anon.description); // undefined
console.log(anon.toString());  // 'Symbol()'

// Symbol нельзя преобразовать в строку неявно:
// console.log('Symbol: ' + s); // TypeError!
console.log(\`Symbol: \${String(s)}\`); // 'Symbol: Symbol(мой символ)'

// Шаблонная строка тоже не работает:
// console.log(\`\${s}\`); // TypeError`;

document.getElementById('output').textContent = `Symbol('мой символ').description => 'мой символ'
Symbol().description             => undefined
s.toString()                     => 'Symbol(мой символ)'
'str' + s => TypeError! (неявное преобразование запрещено)
Работает только явное: String(s)`;
