document.getElementById('taskText').innerHTML = `<strong>Условие:</strong> Что такое глобальный реестр Symbol? Как создать Symbol через Symbol.for()?<br><span class="diff-badge diff-easy">Лёгкое</span>`;

document.getElementById('solutionCode').textContent = `// Symbol.for(key) — глобальный реестр символов
// Возвращает СУЩЕСТВУЮЩИЙ Symbol если key уже был, или создаёт новый

const s1 = Symbol.for('userId');
const s2 = Symbol.for('userId');

console.log(s1 === s2); // true! (одинаковые из реестра)

// Получить ключ по Symbol:
console.log(Symbol.keyFor(s1)); // 'userId'

// Обычный Symbol НЕ в реестре:
const local = Symbol('userId');
console.log(Symbol.keyFor(local)); // undefined (не в реестре!)

console.log(local === s1); // false`;

document.getElementById('output').textContent = `Symbol.for('userId') === Symbol.for('userId') => true (реестр!)
Symbol('userId') === Symbol.for('userId') => false
Symbol.keyFor(s1) => 'userId'
Symbol.keyFor(Symbol()) => undefined (не в глобальном реестре)
Глобальный реестр — удобен для shared-символов между модулями`;
